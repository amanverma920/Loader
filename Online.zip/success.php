<?php
session_start();

// Check if the user came from a successful payment
if (!isset($_SESSION['generated_key'])) {
    header("Location: index.php");
    exit();
}

// Database Configuration
$servername = "localhost";
$dbname = "androidengine_api";
$username = "androidengine_api";
$password = "androidengine_api";

// Database Connection
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// Get key details from session
$key = $_SESSION['generated_key'];
$game = $_SESSION['game'];
$duration = $_SESSION['duration'];
$devices = $_SESSION['devices'];
$price = $_SESSION['price'];
$customer_name = $_SESSION['customer_name'];
$customer_email = $_SESSION['customer_email'];
$customer_phone = $_SESSION['customer_phone'];
$customer_location = $_SESSION['customer_location'];
$coordinates = $_SESSION['coordinates'];

// Clear the session after displaying
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation | MAFIA-HACKER</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --neon-blue: #0ff0fc;
            --neon-pink: #ff2a6d;
            --neon-purple: #d300c5;
            --neon-green: #00ff9d;
            --dark-bg: #0d0c1d;
            --darker-bg: #070611;
            --panel-bg: rgba(15, 15, 35, 0.8);
            --text-primary: #e0e0ff;
            --text-secondary: #a0a0c0;
            --glow: 0 0 10px rgba(0, 255, 157, 0.7);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background-color: var(--dark-bg);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-image: 
                radial-gradient(circle at 20% 30%, rgba(255, 42, 109, 0.15) 0%, transparent 25%),
                radial-gradient(circle at 80% 70%, rgba(0, 255, 157, 0.15) 0%, transparent 25%),
                linear-gradient(to bottom, var(--darker-bg), var(--dark-bg));
            overflow-x: hidden;
        }

        .cyber-container {
            width: 100%;
            max-width: 600px;
            background: var(--panel-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 0 30px rgba(0, 255, 157, 0.2);
            border: 1px solid rgba(0, 255, 157, 0.2);
            position: relative;
            overflow: hidden;
            z-index: 1;
            backdrop-filter: blur(10px);
            animation: fadeIn 0.8s ease-out, scanlines 8s linear infinite;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes scanlines {
            0% { background-position: 0 0; }
            100% { background-position: 0 20px; }
        }

        .cyber-header {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 20px;
        }

        .cyber-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 25%;
            width: 50%;
            height: 2px;
            background: linear-gradient(to right, transparent, var(--neon-green), transparent);
            box-shadow: var(--glow);
        }

        .cyber-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 15px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 20px rgba(0, 255, 157, 0.5);
            border: 2px solid var(--neon-green);
            position: relative;
            overflow: hidden;
        }

        .cyber-logo::before {
            content: '';
            position: absolute;
            width: 150%;
            height: 150%;
            background: conic-gradient(
                transparent 0deg,
                var(--neon-green) 60deg,
                transparent 120deg,
                var(--neon-pink) 180deg,
                transparent 240deg,
                var(--neon-blue) 300deg,
                transparent 360deg
            );
            animation: rotate 4s linear infinite;
        }

        .cyber-logo img {
            width: 60%;
            height: 60%;
            object-fit: contain;
            z-index: 1;
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .cyber-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.2rem;
            margin-bottom: 10px;
            background: linear-gradient(90deg, var(--neon-green), var(--neon-blue));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            text-shadow: 0 0 10px rgba(0, 255, 157, 0.5);
        }

        .cyber-subtitle {
            font-size: 1rem;
            opacity: 0.8;
            letter-spacing: 1px;
            color: var(--text-secondary);
        }

        .success-icon {
            font-size: 5rem;
            color: var(--neon-green);
            margin: 20px 0;
            animation: bounce 1s infinite alternate, pulse 2s infinite;
            text-shadow: 0 0 20px rgba(0, 255, 157, 0.7);
        }

        @keyframes bounce {
            from { transform: translateY(0); }
            to { transform: translateY(-15px); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }

        .order-details {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid rgba(0, 255, 157, 0.2);
            position: relative;
            overflow: hidden;
        }

        .order-details::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--neon-blue), var(--neon-pink));
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(0, 255, 157, 0.1);
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: 600;
            color: var(--neon-blue);
            letter-spacing: 1px;
        }

        .detail-value {
            font-weight: 700;
            color: var(--text-primary);
        }

        .key-container {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
            text-align: center;
            border: 1px dashed var(--neon-green);
            position: relative;
            overflow: hidden;
        }

        .key-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--neon-pink), var(--neon-purple));
        }

        .key-label {
            font-size: 0.9rem;
            margin-bottom: 10px;
            color: var(--text-secondary);
            letter-spacing: 1px;
        }

        .key-value {
            font-size: 1.6rem;
            font-weight: 700;
            letter-spacing: 3px;
            color: var(--neon-green);
            word-break: break-all;
            text-shadow: 0 0 10px rgba(0, 255, 157, 0.5);
            font-family: 'Orbitron', sans-serif;
            margin: 15px 0;
        }

        .copy-btn {
            background: rgba(0, 255, 157, 0.1);
            color: var(--neon-green);
            border: 1px solid var(--neon-green);
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .copy-btn:hover {
            background: rgba(0, 255, 157, 0.2);
            box-shadow: 0 0 15px rgba(0, 255, 157, 0.3);
            transform: translateY(-2px);
        }

        .instructions {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
            border: 1px solid rgba(0, 255, 157, 0.2);
            position: relative;
        }

        .instructions::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--neon-green), var(--neon-blue));
        }

        .instructions-title {
            font-size: 1.1rem;
            margin-bottom: 15px;
            color: var(--neon-blue);
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .instruction {
            margin-bottom: 12px;
            display: flex;
            align-items: flex-start;
            padding: 10px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 6px;
            transition: var(--transition);
        }

        .instruction:hover {
            background: rgba(0, 0, 0, 0.4);
            transform: translateX(5px);
        }

        .instruction i {
            margin-right: 12px;
            color: var(--neon-green);
            font-size: 1.2rem;
            min-width: 20px;
        }

        .cyber-btn {
            width: 100%;
            padding: 16px;
            border-radius: 8px;
            border: none;
            background: linear-gradient(135deg, var(--neon-pink), var(--neon-purple));
            color: white;
            font-weight: 700;
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: var(--transition);
            margin: 30px 0 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            box-shadow: 0 0 20px rgba(255, 42, 109, 0.5);
            position: relative;
            overflow: hidden;
            font-family: 'Orbitron', sans-serif;
        }

        .cyber-btn::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                transparent 45%,
                rgba(255, 255, 255, 0.2) 50%,
                transparent 55%
            );
            transform: rotate(30deg);
            transition: var(--transition);
            opacity: 0;
        }

        .cyber-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 30px rgba(255, 42, 109, 0.8);
        }

        .cyber-btn:hover::before {
            opacity: 1;
            animation: shine 1.5s;
        }

        @keyframes shine {
            0% { transform: rotate(30deg) translate(-30%, -30%); }
            100% { transform: rotate(30deg) translate(30%, 30%); }
        }

        .cyber-btn:active {
            transform: translateY(0);
        }

        .cyber-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.8rem;
            color: var(--text-secondary);
            padding-top: 20px;
            border-top: 1px solid rgba(0, 255, 157, 0.1);
            letter-spacing: 1px;
        }

        /* Terminal effect */
        .terminal-effect {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 255, 157, 0.05),
                rgba(0, 255, 157, 0.05) 1px,
                transparent 1px,
                transparent 2px
            );
            pointer-events: none;
            z-index: 9999;
            opacity: 0.3;
            mix-blend-mode: overlay;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .cyber-container {
                padding: 25px;
            }
            
            .cyber-title {
                font-size: 1.8rem;
            }
        }

        @media (max-width: 480px) {
            .cyber-container {
                padding: 20px;
            }
            
            .cyber-title {
                font-size: 1.6rem;
            }
            
            .key-value {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
    <div class="terminal-effect"></div>
    
    <div class="cyber-container">
        <div class="cyber-header">
            <div class="cyber-logo">
                <img src="https://mafiakey.site/icon.png" alt="MAFIA-HACKER">
            </div>
            <h1 class="cyber-title">ACCESS GRANTED</h1>
            <p class="cyber-subtitle">PREMIUM KEY GENERATION COMPLETE</p>
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
        </div>

        <div class="order-details">
            <div class="detail-row">
                <span class="detail-label">TRANSACTION ID:</span>
                <span class="detail-value"><?= substr($key, 0, 8) ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">TARGET GAME:</span>
                <span class="detail-value">PUBG MOBILE</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">ACCESS DURATION:</span>
                <span class="detail-value"><?= $duration ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">AUTHORIZED DEVICES:</span>
                <span class="detail-value"><?= $devices ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">CREDITS TRANSFERRED:</span>
                <span class="detail-value">₹<?= $price ?></span>
            </div>
        </div>

        <div class="key-container">
            <div class="key-label">YOUR ACCESS KEY:</div>
            <div class="key-value" id="generatedKey"><?= $key ?></div>
            <button class="copy-btn" onclick="copyToClipboard()">
                <i class="fas fa-copy"></i> COPY TO CLIPBOARD
            </button>
        </div>

        <div class="instructions">
            <div class="instructions-title">ACTIVATION PROTOCOL</div>
            <div class="instruction">
                <i class="fas fa-terminal"></i>
                <span>DOWNLOAD OUR PREMIUM APPLICATION FROM SECURE SOURCES</span>
            </div>
            <div class="instruction">
                <i class="fas fa-terminal"></i>
                <span>INITIALIZE THE APPLICATION AND NAVIGATE TO AUTHENTICATION MODULE</span>
            </div>
            <div class="instruction">
                <i class="fas fa-terminal"></i>
                <span>INPUT THIS ACCESS KEY WHEN PROMPTED</span>
            </div>
            <div class="instruction">
                <i class="fas fa-terminal"></i>
                <span>PREMIUM FEATURES WILL BE IMMEDIATELY DEPLOYED</span>
            </div>
        </div>

        <button class="cyber-btn" onclick="window.location.href='https://t.me/MAFIA_HACKERi'">
            <i class="fas fa-user-secret"></i> REQUEST SUPPORT
        </button>

        <div class="cyber-footer">
            &copy; <?= date('Y') ?> MAFIA-HACKER SYSTEMS | ALL RIGHTS RESERVED
        </div>
    </div>

    <script>
        function copyToClipboard() {
            const key = document.getElementById('generatedKey').innerText;
            navigator.clipboard.writeText(key).then(() => {
                // Create a notification element
                const notification = document.createElement('div');
                notification.textContent = 'ACCESS KEY COPIED TO CLIPBOARD';
                notification.style.position = 'fixed';
                notification.style.bottom = '20px';
                notification.style.left = '50%';
                notification.style.transform = 'translateX(-50%)';
                notification.style.backgroundColor = 'rgba(0, 255, 157, 0.2)';
                notification.style.color = 'var(--neon-green)';
                notification.style.padding = '10px 20px';
                notification.style.borderRadius = '5px';
                notification.style.border = '1px solid var(--neon-green)';
                notification.style.boxShadow = '0 0 15px rgba(0, 255, 157, 0.5)';
                notification.style.zIndex = '1000';
                notification.style.animation = 'fadeInOut 2.5s ease-out';
                notification.style.fontWeight = '600';
                notification.style.letterSpacing = '1px';
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.remove();
                }, 2500);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }

        // Add typing animation for cyberpunk feel
        document.addEventListener('DOMContentLoaded', () => {
            const elements = [
                { selector: '.cyber-subtitle', text: 'PREMIUM KEY GENERATION COMPLETE' },
                { selector: '.key-label', text: 'YOUR ACCESS KEY:' },
                { selector: '.instructions-title', text: 'ACTIVATION PROTOCOL' }
            ];
            
            elements.forEach(item => {
                const el = document.querySelector(item.selector);
                if (el) {
                    const originalText = el.textContent;
                    el.textContent = '';
                    
                    let i = 0;
                    const typing = setInterval(() => {
                        if (i < originalText.length) {
                            el.textContent += originalText.charAt(i);
                            i++;
                        } else {
                            clearInterval(typing);
                        }
                    }, 30);
                }
            });
        });
    </script>
</body>
</html>