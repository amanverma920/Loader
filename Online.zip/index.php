<?php
session_start();

// Database Configuration
$servername = "localhost";
$dbname = "androidengine_api";
$username = "androidengine_api";
$password = "androidengine_api";

$api_url = 'https://quickgateway.in/api/create-order';
$user_token = '001412d36083a1840b83d03d2039a867';
$redirect_url = 'https://key.vip-mod.xyz/success.php'; // Update

// Telegram Configuration
define('TELEGRAM_BOT_TOKEN', '8006838510:AAHsz26VrXVSAhUbaS4nf-J8BqiNQVWl7jo');
define('TELEGRAM_CHAT_ID', '7631090802');

// Pricing Configuration
$durations = [
    1 => ['label' => '2 Hours', 'price' => 1],
    5 => ['label' => '5 Hours', 'price' => 20],
    24 => ['label' => '1 Day', 'price' => 30],
    72 => ['label' => '3 Days', 'price' => 50],
    168 => ['label' => '7 Days', 'price' => 100],
    336 => ['label' => '14 Days', 'price' => 180],
    720 => ['label' => '30 Days', 'price' => 300],
    1440 => ['label' => '60 Days', 'price' => 500]
];

// Device price mapping
$device_prices = [
    1 => 0,
    2 => 50,
    3 => 100,
    5 => 150,
    10 => 200
];

// Database Connection
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// Error message handling
$error_message = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Key Generator | MAFIA-HACKER</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --neon-blue: #0ff0fc;
            --neon-pink: #ff2a6d;
            --neon-purple: #d300c5;
            --neon-green: #00ff9d;
            --dark-bg: #0d0c1d;
            --darker-bg: #070611;
            --panel-bg: rgba(15, 15, 35, 0.8);
            --text-primary: #e0e0ff;
            --text-secondary: #a0a0c0;
            --glow: 0 0 10px rgba(0, 255, 157, 0.7);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background-color: var(--dark-bg);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-image: 
                radial-gradient(circle at 20% 30%, rgba(255, 42, 109, 0.15) 0%, transparent 25%),
                radial-gradient(circle at 80% 70%, rgba(0, 255, 157, 0.15) 0%, transparent 25%),
                linear-gradient(to bottom, var(--darker-bg), var(--dark-bg));
            overflow-x: hidden;
        }

        .cyber-container {
            width: 100%;
            max-width: 600px;
            background: var(--panel-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 0 30px rgba(0, 255, 157, 0.2);
            border: 1px solid rgba(0, 255, 157, 0.2);
            position: relative;
            overflow: hidden;
            z-index: 1;
            backdrop-filter: blur(10px);
            animation: fadeIn 0.8s ease-out, scanlines 8s linear infinite;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes scanlines {
            0% { background-position: 0 0; }
            100% { background-position: 0 20px; }
        }

        .cyber-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                transparent 45%,
                rgba(0, 255, 157, 0.1) 50%,
                transparent 55%
            );
            transform: rotate(30deg);
            z-index: -1;
            opacity: 0.3;
        }

        .cyber-header {
            text-align: center;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 20px;
        }

        .cyber-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 25%;
            width: 50%;
            height: 2px;
            background: linear-gradient(to right, transparent, var(--neon-green), transparent);
            box-shadow: var(--glow);
        }

        .cyber-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 15px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 20px rgba(0, 255, 157, 0.5);
            border: 2px solid var(--neon-green);
            position: relative;
            overflow: hidden;
        }

        .cyber-logo::before {
            content: '';
            position: absolute;
            width: 150%;
            height: 150%;
            background: conic-gradient(
                transparent 0deg,
                var(--neon-green) 60deg,
                transparent 120deg,
                var(--neon-pink) 180deg,
                transparent 240deg,
                var(--neon-blue) 300deg,
                transparent 360deg
            );
            animation: rotate 4s linear infinite;
        }

        .cyber-logo img {
            width: 60%;
            height: 60%;
            object-fit: contain;
            z-index: 1;
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .cyber-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.2rem;
            margin-bottom: 10px;
            background: linear-gradient(90deg, var(--neon-green), var(--neon-blue));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            text-shadow: 0 0 10px rgba(0, 255, 157, 0.5);
        }

        .cyber-subtitle {
            font-size: 1rem;
            opacity: 0.8;
            letter-spacing: 1px;
            color: var(--text-secondary);
        }

        .price-display {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            text-align: center;
            margin: 25px 0;
            background: linear-gradient(90deg, var(--neon-pink), var(--neon-purple));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: pulse 2s infinite, flicker 3s infinite alternate;
            text-shadow: 0 0 15px rgba(255, 42, 109, 0.7);
            letter-spacing: 2px;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        @keyframes flicker {
            0%, 19%, 21%, 23%, 25%, 54%, 56%, 100% {
                opacity: 1;
                text-shadow: 0 0 15px rgba(255, 42, 109, 0.7);
            }
            20%, 24%, 55% {
                opacity: 0.8;
                text-shadow: 0 0 5px rgba(255, 42, 109, 0.3);
            }
        }

        .cyber-form {
            margin-top: 30px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-label {
            display: block;
            margin-bottom: 10px;
            font-size: 1rem;
            font-weight: 600;
            color: var(--neon-blue);
            letter-spacing: 1px;
        }

        .form-label i {
            margin-right: 10px;
            color: var(--neon-green);
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            border-radius: 8px;
            border: 1px solid rgba(0, 255, 157, 0.3);
            background: rgba(0, 0, 0, 0.4);
            color: var(--text-primary);
            font-size: 1rem;
            transition: var(--transition);
            font-family: 'Rajdhani', sans-serif;
            font-weight: 500;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--neon-green);
            box-shadow: 0 0 15px rgba(0, 255, 157, 0.3);
            background: rgba(0, 0, 0, 0.6);
        }

        .select-wrapper {
            position: relative;
        }

        .select-wrapper::after {
            content: '\f078';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--neon-green);
            pointer-events: none;
        }

        .cyber-btn {
            width: 100%;
            padding: 16px;
            border-radius: 8px;
            border: none;
            background: linear-gradient(135deg, var(--neon-pink), var(--neon-purple));
            color: white;
            font-weight: 700;
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: var(--transition);
            margin: 30px 0 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            box-shadow: 0 0 20px rgba(255, 42, 109, 0.5);
            position: relative;
            overflow: hidden;
            font-family: 'Orbitron', sans-serif;
        }

        .cyber-btn::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                transparent 45%,
                rgba(255, 255, 255, 0.2) 50%,
                transparent 55%
            );
            transform: rotate(30deg);
            transition: var(--transition);
            opacity: 0;
        }

        .cyber-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 30px rgba(255, 42, 109, 0.8);
        }

        .cyber-btn:hover::before {
            opacity: 1;
            animation: shine 1.5s;
        }

        @keyframes shine {
            0% { transform: rotate(30deg) translate(-30%, -30%); }
            100% { transform: rotate(30deg) translate(30%, 30%); }
        }

        .cyber-btn:active {
            transform: translateY(0);
        }

        .location-section {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
            border: 1px solid rgba(0, 255, 157, 0.2);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .location-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--neon-blue), var(--neon-pink));
        }

        .location-section p {
            margin-bottom: 15px;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .location-btn {
            background: rgba(0, 255, 157, 0.1);
            color: var(--neon-green);
            border: 1px solid var(--neon-green);
            padding: 12px 25px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .location-btn:hover {
            background: rgba(0, 255, 157, 0.2);
            box-shadow: 0 0 15px rgba(0, 255, 157, 0.3);
            transform: translateY(-2px);
        }

        .location-status {
            font-size: 0.85rem;
            color: var(--text-secondary);
            padding: 10px;
            border-radius: 5px;
            background: rgba(0, 0, 0, 0.2);
        }

        .location-status i {
            margin-right: 8px;
        }

        .customer-details {
            display: none;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
            border: 1px solid rgba(0, 255, 157, 0.2);
            animation: fadeInDetails 0.5s ease-out;
        }

        @keyframes fadeInDetails {
            from { opacity: 0; max-height: 0; }
            to { opacity: 1; max-height: 500px; }
        }

        .features-container {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            padding: 20px;
            margin-top: 25px;
            border: 1px solid rgba(0, 255, 157, 0.2);
            position: relative;
        }

        .features-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--neon-pink), var(--neon-purple));
        }

        .features-title {
            text-align: center;
            font-size: 1.1rem;
            margin-bottom: 20px;
            color: var(--neon-blue);
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .feature {
            display: flex;
            align-items: flex-start;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 6px;
            transition: var(--transition);
            margin-bottom: 12px;
            border-left: 3px solid var(--neon-green);
        }

        .feature:hover {
            background: rgba(0, 0, 0, 0.4);
            transform: translateX(5px);
            border-left: 3px solid var(--neon-pink);
        }

        .feature i {
            margin-right: 15px;
            color: var(--neon-green);
            font-size: 1.3rem;
            min-width: 25px;
        }

        .feature-text h4 {
            font-size: 1rem;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .feature-text p {
            font-size: 0.85rem;
            color: var(--text-secondary);
        }

        .cyber-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 0.8rem;
            color: var(--text-secondary);
            padding-top: 20px;
            border-top: 1px solid rgba(0, 255, 157, 0.1);
            letter-spacing: 1px;
        }

        .error-message {
            background: rgba(214, 48, 49, 0.2);
            border: 1px solid var(--neon-pink);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            text-align: center;
            color: var(--neon-pink);
            font-weight: 600;
            letter-spacing: 1px;
            animation: errorPulse 2s infinite;
        }

        @keyframes errorPulse {
            0%, 100% { box-shadow: 0 0 5px rgba(255, 42, 109, 0); }
            50% { box-shadow: 0 0 15px rgba(255, 42, 109, 0.5); }
        }

        /* Cyberpunk checkbox style */
        .cyber-checkbox {
            display: flex;
            align-items: center;
            margin: 20px 0;
            cursor: pointer;
        }

        .cyber-checkbox input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
        }

        .cyber-checkbox .checkmark {
            position: relative;
            height: 20px;
            width: 20px;
            background: rgba(0, 0, 0, 0.3);
            border: 2px solid var(--neon-green);
            border-radius: 4px;
            margin-right: 15px;
            transition: var(--transition);
        }

        .cyber-checkbox:hover .checkmark {
            box-shadow: 0 0 10px rgba(0, 255, 157, 0.5);
        }

        .cyber-checkbox input:checked ~ .checkmark {
            background: var(--neon-green);
        }

        .cyber-checkbox .checkmark::after {
            content: '';
            position: absolute;
            display: none;
            left: 6px;
            top: 2px;
            width: 5px;
            height: 10px;
            border: solid black;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }

        .cyber-checkbox input:checked ~ .checkmark::after {
            display: block;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .cyber-container {
                padding: 25px;
            }
            
            .cyber-title {
                font-size: 1.8rem;
            }
        }

        @media (max-width: 480px) {
            .cyber-container {
                padding: 20px;
            }
            
            .cyber-title {
                font-size: 1.6rem;
            }
            
            .price-display {
                font-size: 2rem;
            }
            
            .cyber-btn {
                padding: 14px;
                font-size: 1rem;
            }
        }

        /* Cyberpunk terminal effect */
        .terminal-effect {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 255, 157, 0.05),
                rgba(0, 255, 157, 0.05) 1px,
                transparent 1px,
                transparent 2px
            );
            pointer-events: none;
            z-index: 9999;
            opacity: 0.3;
            mix-blend-mode: overlay;
        }
    </style>
</head>
<body>
    <div class="terminal-effect"></div>
    
    <div class="cyber-container">
        <div class="cyber-header">
            <div class="cyber-logo">
                <img src="https://mafiakey.site/icon.png" alt="MAFIA-HACKER">
            </div>
            <h1 class="cyber-title">MAFIA-HACKER</h1>
            <p class="cyber-subtitle">PREMIUM KEY GENERATION SYSTEM</p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <div class="price-display" id="gamePrice">₹10</div>

        <form id="paymentForm" class="cyber-form" method="POST" action="process_order.php">
            <input type="hidden" name="game" value="PUBG">
            <input type="hidden" name="customer_location" id="customerLocation">
            <input type="hidden" name="latitude" id="latitude">
            <input type="hidden" name="longitude" id="longitude">

            <div class="form-group">
                <label class="form-label"><i class="fas fa-gamepad"></i> GAME SELECTION</label>
                <input type="text" class="form-control" value="PUBG Mobile" readonly style="color: var(--neon-green);">
            </div>

            <div class="form-group">
                <label class="form-label"><i class="fas fa-clock"></i> DURATION</label>
                <div class="select-wrapper">
                    <select name="duration" id="durationSelect" class="form-control" required>
                        <?php foreach ($durations as $hours => $data): ?>
                            <option value="<?= $hours ?>"><?= $data['label'] ?> (₹<?= $data['price'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label"><i class="fas fa-microchip"></i> DEVICE AUTHORIZATION</label>
                <div class="select-wrapper">
                    <select name="devices" id="devicesSelect" class="form-control" required>
                        <?php foreach ($device_prices as $device => $price): ?>
                            <option value="<?= $device ?>"><?= $device ?> DEVICE(S) (₹<?= $price ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="location-section">
                <p>FOR OPTIMAL SERVICE DELIVERY, ENABLE LOCATION TRACKING</p>
                <button type="button" id="locationBtn" class="location-btn">
                    <i class="fas fa-satellite-dish"></i> INITIATE LOCATION SCAN
                </button>
                <div class="location-status" id="locationStatus">
                    <i class="fas fa-circle-notch fa-spin"></i> LOCATION MODULE STANDBY
                </div>
            </div>

            <div class="customer-details" id="customerDetails">
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-id-card"></i> OPERATOR IDENTIFICATION</label>
                    <input type="text" name="customer_name" class="form-control" placeholder="ENTER FULL DESIGNATION" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-envelope"></i> COMMUNICATION CHANNEL</label>
                    <input type="email" name="customer_email" class="form-control" placeholder="INPUT SECURE EMAIL PROTOCOL" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-phone-alt"></i> DIRECT LINK FREQUENCY</label>
                    <input type="tel" name="mobile" class="form-control" placeholder="ENTER TRANSMISSION CODE" required>
                </div>
            </div>

            <button type="submit" id="payButton" class="cyber-btn">
                <i class="fas fa-key"></i> INITIATE PAYMENT SEQUENCE
            </button>

            <div class="features-container">
                <div class="features-title">
                    <i class="fas fa-star-of-life"></i> SYSTEM FEATURES
                </div>
                <div class="features">
                    <div class="feature">
                        <i class="fas fa-shield-virus"></i>
                        <div class="feature-text">
                            <h4>QUANTUM ENCRYPTION</h4>
                            <p>Military-grade security protocols for all transactions</p>
                        </div>
                    </div>
                    <div class="feature">
                        <i class="fas fa-bolt"></i>
                        <div class="feature-text">
                            <h4>INSTANT DEPLOYMENT</h4>
                            <p>Key generation within nanoseconds of payment verification</p>
                        </div>
                    </div>
                    <div class="feature" onclick="window.open('https://t.me/MAFIA_HACKERi', '_blank')" style="cursor: pointer;">
                        <i class="fas fa-headset"></i>
                        <div class="feature-text">
                            <h4>24/7 SUPPORT NETWORK</h4>
                            <p>Contact @MAFIA_HACKERi for immediate assistance</p>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div class="cyber-footer">
            &copy; <?= date('Y') ?> MAFIA-HACKER SYSTEMS | ALL RIGHTS RESERVED
        </div>
    </div>

    <script>
    // Update price when duration or devices change
    function updatePrice() {
        const durationSelect = document.getElementById('durationSelect');
        const devicesSelect = document.getElementById('devicesSelect');
        const priceDisplay = document.getElementById('gamePrice');
        
        const durationPrice = parseInt(durationSelect.options[durationSelect.selectedIndex].text.match(/₹(\d+)/)[1]);
        const devicePrice = parseInt(devicesSelect.options[devicesSelect.selectedIndex].text.match(/₹(\d+)/)[1]);
        const totalPrice = durationPrice + devicePrice;
        
        // Create a temporary element for the animation
        const tempElement = document.createElement('div');
        tempElement.className = 'price-display';
        tempElement.textContent = `₹${totalPrice}`;
        tempElement.style.position = 'absolute';
        tempElement.style.opacity = '0';
        tempElement.style.transform = 'scale(1.5)';
        tempElement.style.transition = 'all 0.3s ease-out';
        priceDisplay.parentNode.appendChild(tempElement);
        
        // Trigger animation
        setTimeout(() => {
            tempElement.style.opacity = '1';
            tempElement.style.transform = 'scale(1)';
            
            setTimeout(() => {
                priceDisplay.textContent = `₹${totalPrice}`;
                tempElement.remove();
                
                // Add neon flicker effect
                priceDisplay.style.animation = 'none';
                void priceDisplay.offsetWidth; // Trigger reflow
                priceDisplay.style.animation = 'pulse 2s infinite, flicker 3s infinite alternate';
            }, 300);
        }, 10);
    }
    
    // Location permission handler with cyberpunk style
    document.getElementById('locationBtn').addEventListener('click', function() {
        const locationStatus = document.getElementById('locationStatus');
        const customerDetails = document.getElementById('customerDetails');
        const btn = this;
        
        btn.innerHTML = '<i class="fas fa-satellite"></i> SCANNING...';
        btn.style.color = 'var(--neon-blue)';
        btn.style.borderColor = 'var(--neon-blue)';
        btn.style.boxShadow = '0 0 15px rgba(0, 240, 252, 0.5)';
        
        locationStatus.innerHTML = '<i class="fas fa-satellite-dish fa-spin"></i> INITIATING GEOLOCATION PROTOCOL...';
        locationStatus.style.color = 'var(--neon-blue)';
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;
                    
                    try {
                        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
                        const data = await response.json();
                        
                        let locationText = '';
                        if (data.address) {
                            if (data.address.city) locationText += data.address.city;
                            if (data.address.state) locationText += `, ${data.address.state}`;
                            if (data.address.country) locationText += `, ${data.address.country}`;
                        } else {
                            locationText = `COORDINATES: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
                        }
                        
                        document.getElementById('customerLocation').value = locationText;
                        locationStatus.innerHTML = `<i class="fas fa-check-circle" style="color:var(--neon-green)"></i> LOCATION ACQUIRED: ${locationText}`;
                        
                        // Show customer details with animation
                        customerDetails.style.display = 'block';
                        btn.innerHTML = '<i class="fas fa-map-marked-alt"></i> LOCATION LOCKED';
                        btn.style.color = 'var(--neon-green)';
                        btn.style.borderColor = 'var(--neon-green)';
                        btn.style.boxShadow = '0 0 15px rgba(0, 255, 157, 0.5)';
                        
                        // Add success pulse effect
                        btn.style.animation = 'none';
                        void btn.offsetWidth; // Trigger reflow
                        btn.style.animation = 'pulse 1s 3';
                    } catch (error) {
                        document.getElementById('customerLocation').value = `COORDINATES: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
                        locationStatus.innerHTML = `<i class="fas fa-check-circle" style="color:var(--neon-green)"></i> APPROXIMATE LOCATION DETECTED`;
                        customerDetails.style.display = 'block';
                        btn.innerHTML = '<i class="fas fa-map-marked-alt"></i> LOCATION APPROXIMATED';
                        btn.style.color = 'var(--neon-green)';
                        btn.style.borderColor = 'var(--neon-green)';
                    }
                },
                (error) => {
                    let message = "GEOLOCATION ACCESS DENIED";
                    if (error.code === error.POSITION_UNAVAILABLE) {
                        message = "GEOLOCATION UNAVAILABLE";
                    } else if (error.code === error.TIMEOUT) {
                        message = "SCAN TIMEOUT";
                    }
                    locationStatus.innerHTML = `<i class="fas fa-exclamation-triangle" style="color:var(--neon-pink)"></i> ${message}`;
                    locationStatus.style.color = 'var(--neon-pink)';
                    customerDetails.style.display = 'block';
                    btn.innerHTML = '<i class="fas fa-exclamation-circle"></i> SCAN FAILED';
                    btn.style.color = 'var(--neon-pink)';
                    btn.style.borderColor = 'var(--neon-pink)';
                    btn.style.boxShadow = '0 0 15px rgba(255, 42, 109, 0.5)';
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        } else {
            locationStatus.innerHTML = '<i class="fas fa-exclamation-triangle" style="color:var(--neon-pink)"></i> GEOLOCATION PROTOCOL NOT SUPPORTED';
            locationStatus.style.color = 'var(--neon-pink)';
            customerDetails.style.display = 'block';
            btn.innerHTML = '<i class="fas fa-times-circle"></i> SYSTEM INCOMPATIBLE';
            btn.style.color = 'var(--neon-pink)';
            btn.style.borderColor = 'var(--neon-pink)';
        }
    });
    
    // Initialize
    document.getElementById('durationSelect').addEventListener('change', updatePrice);
    document.getElementById('devicesSelect').addEventListener('change', updatePrice);
    updatePrice();
    
    // Add terminal-like typing effect for fun
    const elementsToType = [
        { element: document.querySelector('.cyber-subtitle'), text: 'PREMIUM KEY GENERATION SYSTEM', delay: 50 },
        { element: document.getElementById('locationStatus'), text: 'LOCATION MODULE STANDBY', delay: 30 }
    ];
    
    elementsToType.forEach(item => {
        const originalText = item.element.textContent;
        item.element.textContent = '';
        
        let i = 0;
        const typing = setInterval(() => {
            if (i < originalText.length) {
                item.element.textContent += originalText.charAt(i);
                i++;
            } else {
                clearInterval(typing);
            }
        }, item.delay);
    });
    </script>
</body>
</html>