<?php
session_start();

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
$servername = "localhost";
$dbname = "androidengine_api";
$username = "androidengine_api";
$password = "androidengine_api";

// Telegram Configuration
define('TELEGRAM_BOT_TOKEN', '8006838510:AAHsz26VrXVSAhUbaS4nf-J8BqiNQVWl7jo');
define('TELEGRAM_CHAT_ID', '7631090802');

// Pricing Configuration
$durations = [
    1 => ['label' => '2 Hours', 'price' => 1],
    5 => ['label' => '5 Hours', 'price' => 20],
    24 => ['label' => '1 Day', 'price' => 30],
    72 => ['label' => '3 Days', 'price' => 50],
    168 => ['label' => '7 Days', 'price' => 100],
    336 => ['label' => '14 Days', 'price' => 180],
    720 => ['label' => '30 Days', 'price' => 300],
    1440 => ['label' => '60 Days', 'price' => 500]
];

$device_prices = [
    1 => 0,
    2 => 50,
    3 => 100,
    5 => 150,
    10 => 200
];

// Database Connection
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// Set the API endpoint URL
$api_url = 'https://quickgateway.in/api/create-order';
$user_token = '001412d36083a1840b83d03d2039a867';
$redirect_url = 'https://key.vip-mod.xyz/success.php';

// Validate form submission
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Invalid request method');
}

// Get form data
$game = $_POST['game'] ?? '';
$duration = $_POST['duration'] ?? '';
$devices = (int)($_POST['devices'] ?? 0);
$customer_name = $_POST['customer_name'] ?? '';
$customer_email = $_POST['customer_email'] ?? '';
$customer_phone = $_POST['mobile'] ?? '';
$customer_location = $_POST['customer_location'] ?? '';
$latitude = $_POST['latitude'] ?? '';
$longitude = $_POST['longitude'] ?? '';

// Validate game and duration
if ($game !== 'PUBG' || !isset($durations[$duration]) || $devices <= 0) {
    die('Invalid order details');
}

// Calculate price
$duration_price = $durations[$duration]['price'];
$device_price = $device_prices[$devices] ?? 0;
$total_price = $duration_price + $device_price;

// Generate a unique key
$key = strtoupper(bin2hex(random_bytes(8)));

// Store order in database
try {
    $stmt = $pdo->prepare("INSERT INTO keys_code (game, user_key, duration, max_devices, status, created_at, updated_at)
        VALUES (:game, :user_key, :duration, :devices, 1, NOW(), NOW())");
    
    $stmt->execute([
        ':game' => $game,
        ':user_key' => $key,
        ':duration' => $duration,
        ':devices' => $devices
    ]);
    
    // Store in Session
    $_SESSION = [
        'generated_key' => $key,
        'game' => $game,
        'duration' => $durations[$duration]['label'],
        'devices' => $devices,
        'price' => $total_price,
        'customer_name' => $customer_name,
        'customer_email' => $customer_email,
        'customer_phone' => $customer_phone,
        'customer_location' => $customer_location,
        'coordinates' => "$latitude,$longitude"
    ];
    
    // Telegram Notification
    $telegram_message = "🛒 *New Payment Received* 🛒\n";
    $telegram_message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $telegram_message .= "💰 *Amount:* ₹$total_price\n";
    $telegram_message .= "📅 *Date:* " . date('Y-m-d H:i:s') . "\n";
    $telegram_message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $telegram_message .= "👤 *Customer Details*\n";
    $telegram_message .= "• *Name:* $customer_name\n";
    $telegram_message .= "• *Email:* $customer_email\n";
    $telegram_message .= "• *Phone:* $customer_phone\n";
    $telegram_message .= "• *Location:* $customer_location\n";
    $telegram_message .= "• *Coordinates:* [$latitude,$longitude](https://www.google.com/maps?q=$latitude,$longitude)\n";
    $telegram_message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $telegram_message .= "🔑 *Key Details*\n";
    $telegram_message .= "• *Game:* $game\n";
    $telegram_message .= "• *Duration:* {$durations[$duration]['label']}\n";
    $telegram_message .= "• *Devices:* $devices\n";
    $telegram_message .= "• *Generated Key:* `$key`\n";
    $telegram_message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $telegram_message .= "👨‍💻 *Developer:* [@MAFIA_HACKERi](https://t.me/MAFIA_HACKERi)";
    
    $telegram_url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $telegram_data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $telegram_message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => true
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $telegram_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $telegram_data,
        CURLOPT_RETURNTRANSFER => true
    ]);
    curl_exec($ch);
    curl_close($ch);
    
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Prepare API payload
$data = [
    'customer_mobile' => $customer_phone,
    'user_token' => $user_token,
    'amount' => $total_price,
    'order_id' => uniqid('order_', true),
    'redirect_url' => $redirect_url,
    'remark1' => "PUBG Key - {$durations[$duration]['label']}",
    'remark2' => "Devices: $devices"
];

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $api_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query($data),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/x-www-form-urlencoded'
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false // Remove this in production with proper SSL setup
]);

// Execute and get response
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);

if ($curl_error) {
    die("cURL Error: $curl_error");
}

// Log the API response for debugging
file_put_contents('payment_log.txt', date('Y-m-d H:i:s') . " - Response: $response\n", FILE_APPEND);

$result = json_decode($response, true);

if (!$result) {
    die("Invalid API response format. HTTP Code: $http_code");
}

if (!isset($result['status'])) {
    die("API response missing status field. Full response: " . print_r($result, true));
}

if ($result['status'] === true) {
    // Redirect to payment gateway
    header("Location: " . $result['result']['payment_url']);
    exit();
} else {
    $error_message = $result['message'] ?? 'Unknown error';
    // Log detailed error
    file_put_contents('payment_log.txt', date('Y-m-d H:i:s') . " - Payment Failed: $error_message\nData: " . print_r($data, true) . "\nResponse: " . print_r($result, true) . "\n", FILE_APPEND);
    
    // Redirect back with error
    header("Location: index.php?error=" . urlencode("Payment failed: $error_message"));
    exit();
}

curl_close($ch);
?>