<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "pages/dbFunctions.php";
include "pages/dbInfo.php";
include "auth/header.php";
if(isset($_SESSION['order_id'])){

 $slq_p = "SELECT * FROM orders where order_id='".$_SESSION['order_id']."'";
$res_p = getXbyY($slq_p);
if($res_p[0]["status"]!="SUCCESS"){
echo "Payment Pending";
exit();
}
}
else{
    exit();
}
function redirectDecrypt($ciphertext_base64, $key="ONKARJHAPAYMENTGATEWAY", $iv="ONKARJHA") {
  
    $key = hash('sha256', $key, true);
    $iv = substr(hash('sha256', $iv, true), 0, 16);

    $ciphertext = base64_decode($ciphertext_base64);
    $plaintext = openssl_decrypt($ciphertext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $plaintext;
}

$url =  str_replace(" ", "+", $_GET['url']);
$red = redirectDecrypt($url);
header('Location:'.$red);
?>
