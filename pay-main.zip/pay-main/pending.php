
    
<!DOCTYPE html>
<html>
   <head>
      <?php include 'auth/common_files/head.php';?>
      <link rel="stylesheet" type="text/css" href="auth/assets/css/plugin.css">
      <style>
      </style>
      <title>Payment Pending</title>
   </head>
   <body>
     
      <script>Swal.fire({
  title: "Payment Pending!",
  text: "We are verifying your payment now!",
  icon: "info",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Done"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>
      
   </body>
</html>