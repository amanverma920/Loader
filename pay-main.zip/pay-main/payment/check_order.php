<?php

include "../pages/dbFunctions.php";
include "../auth/header.php";

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(400);
    $response = [
        "status" => false,
        "message" => "Invalid request format",
    ];

    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $required_params = ["user_token", "order_id"];

    foreach ($required_params as $param) {
        if (!isset($_POST[$param]) || empty($_POST[$param])) {
            http_response_code(400);
            echo json_encode([
                "status" => false,
                "message" => "Missing required parameter",
            ]);
            exit();
        }
    }

    $user_token = filter_var($_POST["user_token"], FILTER_SANITIZE_STRING);
    $order_id = filter_var($_POST["order_id"], FILTER_SANITIZE_STRING);

    $sql = "SELECT acc_ban, acc_lock, expiry FROM users WHERE user_token = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $user_token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        http_response_code(401);
        echo json_encode([
            "status" => false,
            "message" => "Unauthorized access",
        ]);
        exit();
    }

    $stmt->bind_result($acc_ban, $acc_lock, $expiry);
    $stmt->fetch();
    $stmt->close();

    if ($acc_ban == "on") {
        http_response_code(403);
        echo json_encode([
            "status" => false,
            "message" => "Your Account is Banned",
        ]);
        exit();
    }

    if ($acc_lock >= 3) {
        http_response_code(403);
        echo json_encode([
            "status" => false,
            "message" => "Your Account is Locked",
        ]);
        exit();
    }

    $sql =
        "SELECT status, amount, utr, create_date FROM orders WHERE user_token = ? AND order_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode([
            "status" => false,
            "message" => "Database prepare error: " . $conn->error,
        ]);
        exit();
    }

    $stmt->bind_param("ss", $user_token, $order_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($status, $amount, $utr, $create_date);
        $stmt->fetch();

        if ($status === "SUCCESS") {
            http_response_code(200);
            $response["status"] = true;
            $response["message"] = "Transaction Successfully";
            $response["result"] = [
                "txnStatus" => "SUCCESS",
                "orderId" => $order_id,
                "amount" => $amount,
                "date" => $create_date,
                "utr" => $utr,
            ];
        } elseif ($status === "FAILURE") {
            http_response_code(200);
            $response["status"] = true;
            $response["message"] = "Transaction Failed";
            $response["result"] = [
                "txnStatus" => "FAILURE",
                "orderId" => $order_id,
                "amount" => $amount,
                "date" => $create_date,
            ];
        } else {
            http_response_code(200);
            $response["status"] = true;
            $response["message"] = "Transaction Pending";
            $response["result"] = [
                "txnStatus" => "PENDING",
                "orderId" => $order_id,
                "amount" => $amount,
                "date" => $create_date,
            ];
        }
    } else {
        http_response_code(404);
        $response["status"] = false;
        $response["message"] = "Order not found";
    }

    $stmt->close();

    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>
