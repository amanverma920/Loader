<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

error_reporting(1);

define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");

include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "auth/config.php";
include ROOT_DIR . "pages/dbInfo.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $byteTransactionId = $_POST["byte_order_status"];

} else {
    $byteTransactionId = $_GET["byte_order_status"];
}

$sqlSelectOrderscxr = "SELECT * FROM orders WHERE byteTransactionId=?";
$stmtSelectOrderscxr = $conn->prepare($sqlSelectOrderscxr);
$stmtSelectOrderscxr->bind_param("s", $byteTransactionId);
$stmtSelectOrderscxr->execute();
$resultSelectOrders = $stmtSelectOrderscxr->get_result();
$cxrrrowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrderscxr->close();

if (!$cxrrrowOrders) {
    die("Byter error");
}

$order_id = $cxrrrowOrders["order_id"];

$sqlCheckStatus = "SELECT status FROM orders WHERE order_id=?";
$stmtCheckStatus = $conn->prepare($sqlCheckStatus);
$stmtCheckStatus->bind_param("s", $order_id);
$stmtCheckStatus->execute();
$resultCheckStatus = $stmtCheckStatus->get_result();
if ($resultCheckStatus->num_rows > 0) {
    $rowCheckStatus = $resultCheckStatus->fetch_assoc();
    if ($rowCheckStatus["status"] === "SUCCESS") {
        echo "ALREADY";
        $stmtCheckStatus->close();
        $conn->close();
        exit();
    }
}
$stmtCheckStatus->close();

$sqlDelete = "DELETE FROM reports WHERE status='' AND order_id=?";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bind_param("s", $order_id);
$stmtDelete->execute();
$stmtDelete->close();

$sqlSelectOrders = "SELECT * FROM orders WHERE order_id=?";
$stmtSelectOrders = $conn->prepare($sqlSelectOrders);
$stmtSelectOrders->bind_param("s", $order_id);
$stmtSelectOrders->execute();
$resultSelectOrders = $stmtSelectOrders->get_result();
$rowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrders->close();

if (!$rowOrders) {
    die("Order not found");
}

$user_token = $rowOrders["user_token"];
$gateway_txn = $rowOrders["gateway_txn"];
$cxrremark1 = $rowOrders["remark1"];

$sqlSelectUser = "SELECT * FROM users WHERE user_token=?";
$stmtSelectUser = $conn->prepare($sqlSelectUser);
$stmtSelectUser->bind_param("s", $user_token);
$stmtSelectUser->execute();
$resultSelectUser = $stmtSelectUser->get_result();
$rowUser = $resultSelectUser->fetch_assoc();
$stmtSelectUser->close();

$callback_url = $rowUser["callback_url"];
$megabyteuserid = $rowUser["id"];

$txn_data = file_get_contents(
    $root."phnpe/user_txn.php?no=" .
        $user_token .
        ""
);
        $user_token .
        "";

$jsonStart = strpos($txn_data, '{');
$jsonString = substr($txn_data, $jsonStart);

$jsonData = json_decode($jsonString, true);

 $data = $jsonData["data"];
 $results = $data["results"];

foreach ($results as $result) {

    if ($result["merchantTransactionId"] == $byteTransactionId) {

        $cxrmerchantTransactionId = $result["merchantTransactionId"];
    $customerDetails = $result["customerDetails"];
        $user_name = $customerDetails["userName"];
        $paymentApp = $result["paymentApp"];
        $paymentApp = $paymentApp["paymentApp"];

        $amount = $result["amount"];
         $amount = $amount / 100;
        $transactionId = $result["transactionId"]; 
        $paymentState = $result["payResponseCode"]; 
        $transactionDate = $result["transactionDate"];
        $transactionNote = $result["transactionNote"];
        $transactionDate = date("m/d/Y", $transactionDate);
        $UTR = $result["utr"];
         $vpa = $result["vpa"] ?? "test@paytm"; 

        $sqlInsertReport =
            "INSERT INTO reports (transactionId, status, order_id, vpa, user_name, paymentApp, amount, user_token, transactionNote, merchantTransactionId, user_id, UTR) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmtInsertReport = $conn->prepare($sqlInsertReport);

        $stmtInsertReport->bind_param(
            "ssssssdsssss",
            $transactionId,
            $paymentState,
            $order_id,
            $vpa,
            $user_name,
            $paymentApp,
            $amount,
            $user_token,
            $transactionNote,
            $cxrmerchantTransactionId,
            $megabyteuserid,
            $UTR
        );

        if ($stmtInsertReport->execute() === true) {
            $stmtInsertReport->close();
        }
    }
}

$sqlSelectReports = "SELECT * FROM reports WHERE order_id=?";
$stmtSelectReports = $conn->prepare($sqlSelectReports);
$stmtSelectReports->bind_param("s", $order_id);
$stmtSelectReports->execute();
$resultSelectReports = $stmtSelectReports->get_result();
$rowReports = $resultSelectReports->fetch_assoc();
$stmtSelectReports->close();

$db_status = $rowReports["status"];
$db_user_token = $rowReports["user_token"];
$db_transactionId = $rowReports["transactionId"]; 
$db_merchantTransactionId = $rowReports["merchantTransactionId"]; 
$db_transactionNote = $rowReports["transactionNote"]; 

if (
    $db_status == "SUCCESS" &&
    $byteTransactionId == $db_merchantTransactionId
) {
    $sql = "UPDATE orders SET status='SUCCESS',utr='$UTR' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE reports SET status='SUCCESS' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE orders SET utr=? WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $UTR, $order_id);
    $stmt->execute();
    $stmt->close();
  
 
    /*************************************************************************************/
 
$webhook_data = [
    'order_id'=> $order_id,
    'status'=> "SUCCESS",
    'remark1'=>$cxrremark1,
 ];


if (!empty($callback_url)) {
    $json_data = json_encode($webhook_data);

    $ch = curl_init($callback_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($json_data)
    ]);

    $webhook_response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log("Webhook curl error: " . curl_error($ch));
    }

    curl_close($ch);
}

    /*************************************************************************************/
     echo "SUCCESS";
} else {
    echo "PENDING";
}

if (
    $db_status == "FAILURE" ||
    $db_status == "FAILED" ||
    $db_status == "UPI_BACKBONE_ERROR"
) {
    echo "FAILURE";
}

$conn->close();
?>