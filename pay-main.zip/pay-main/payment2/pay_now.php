<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Payment Page</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <link rel="stylesheet" type="text/css" href="../../auth/assets/css/plugin.css?v=111">

      <link rel="stylesheet" type="text/css" href="../../auth/assets/css/app.css">
      <style>
  
        * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         }
         h2{
         margin-bottom: unset;
         line-height: 30px;;margin-top: 18px;
         }p{
              margin-bottom: 0rem;
         }
         .mt-20 {
         margin-top: 20px;
         }
         .mt-10 {
         margin-top: 10px;
         }
         .main_pay {
         margin: auto;
         margin-top: 50px;
         margin-bottom: 50px;
         /* position: absolute; */
         border-radius: 10px;
         /* top: 50%; */
         /* left: 50%; */
         /* transform: translate(-50%, -50%); */
         width: 450px;
         height: 700px;
         background-color: #fff;
         }
         .head {
         border-radius: 10px 10px 0 0;
         height: 80px;
         background: linear-gradient(105deg, #9472ee 0%, #3205aa 100%);
         display: flex;
         align-items: center;
         padding: 0 20px;
         }
         .logo {
         height: 50px;
         border-radius: 7px;
         ;
         }
         .shop_name {
         color: #fff;
         margin-left: 15px;
         ;
         }
         .shop_verified {
         color: #fff;
         align-items: center;
         margin-left: 15px;
         ;
         }
         .shop_verified>img {
         height: 20px;
         }
         .shop_verified>span {
         font-size: 15px;
         }
         .qrCode {
         margin-top: 10px;
         width: 200px;padding: 20px;
         border: 1px solid #efefef;
         }
         .small_img {
         width: 70px;
         }
         /********************************/
         .upi_app_logo {
         padding: 10px;
         height: 60px;
         border: 1px solid #efefef;
         }
         .apps {
         justify-content: center;
         }
         #timer {
         color: red
         }
   .loader {
  width: 40px;
  height: 40px;
  border: 5px solid #eee;
  border-top: 5px solid #9472ee;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-top: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
         @media only screen and (max-width: 500px) {
         .main_pay {
         /* position: fixed; */
         /* top: 0; */
         /* left: 0; */
         /* transform: unset; */
         border-radius: 0;
         width: 100%;
         min-height: 100vh;
         max-height: 100%;
         margin-top: 0;
         margin-bottom: 0;
         }
         .head {
         border-radius: 0;
         }
         }
      </style>
   </head>
   <?php
      date_default_timezone_set("Asia/Kolkata");
      
      define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");
       include ROOT_DIR . "auth/header.php";
      include ROOT_DIR . "pages/dbFunctions.php";
      include ROOT_DIR . "pages/dbInfo.php";
      
      $link_token = sanitizeInput($_GET["token"]);
      
      $sql_fetch_order_id = "SELECT order_id, created_at FROM payment_links WHERE link_token = '$link_token'";
      $result = getXbyY($sql_fetch_order_id);
      
      if (count($result) === 0) {
          echo "Token not found or expired";
          exit();
      }
      
      $order_id = $result[0]["order_id"];
      $_SESSION['order_id']=$order_id;
      $created_at = strtotime($result[0]["created_at"]);
      $current_time = time();
      
      $slq_p = "SELECT * FROM orders where order_id='$order_id'";
      $res_p = getXbyY($slq_p);
      if($res_p[0]["status"]=="SUCCESS"){
    echo "Payment Already Done! Token Expired!";
    exit();
}
      $amount = $res_p[0]["amount"];
      $user_token = $res_p[0]["user_token"];
      $redirect_url = $res_p[0]["redirect_url"];
      $cxrkalwaremark = $res_p[0]["byteTransactionId"];
      
      if ($redirect_url == "") {
          $redirect_url = "https://" . $_SERVER["SERVER_NAME"] . "/";
      }
      
      $obj = json_decode($txn_data);
      $data = $obj->data;
      
      $json0 = json_decode($txn_data, 1);
      $data = $json0["data"];
      $results = $data["results"];
      $customerDetails = $results[$i]["customerDetails"];
      
      $slq_p = "SELECT * FROM store_id where user_token='$user_token'";
      $res_p = getXbyY($slq_p);
      $unitId = $res_p[0]["unitId"];
      
      $slq_p = "SELECT * FROM users where user_token='$user_token'";
      $res_p = getXbyY($slq_p);
      $upi_id = $res_p[0]["upi_id"];
      $cxrmerchantTransactionId = $cxrkalwaremark;
      $asdasd23 = "ARC" . rand(111, 999) . time() . rand(1, 100);
      $upi_url = "upi://pay?pa=$upi_id&am=$amount&pn=$unitId&tn=$cxrkalwaremark&tr=$cxrkalwaremark";
      
      $encoded_upi_url = urlencode($upi_url);
      
      $qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?data=$encoded_upi_url&size=150x150";
      
      $orders = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&upi://pay?pa=$upi_id&am=$amount&pn=$unitId&tn=$cxrkalwaremark&tr=$cxrkalwaremark";
      $qrCodeBase64 = $qr_code_url;
      
      $paytmintent = "paytmmp://cash_wallet?pa=$upi_id&pn=$unitId&am=$amount&cu=INR&tn=$cxrkalwaremark&tr=$cxrkalwaremark&mc=4722&&sign=AAuN7izDWN5cb8A5scnUiNME+LkZqI2DWgkXlN1McoP6WZABa/KkFTiLvuPRP6/nWK8BPg/rPhb+u4QMrUEX10UsANTDbJaALcSM9b8Wk218X+55T/zOzb7xoiB+BcX8yYuYayELImXJHIgL/c7nkAnHrwUCmbM97nRbCVVRvU0ku3Tr&featuretype=money_transfer";
      ?>
   <body>
      <div class="main_pay">
<div class="head">
    <img class="logo" src="https://yt3.ggpht.com/ytc/AIdro_kdcrho7xyyY1R2wEihiTfXO10kW6UauBWjPwv9piZyddM=s800-c-k-c0x00ffffff-no-rj" alt="logo">
    <div>
        <h4 class="shop_name"><?php echo $unitId;?></h4>
        <p class="flex shop_verified">
            <img src="https://checkout-static-next.razorpay.com/build/assets/images/rtb.f4f28384.png">&nbsp;
            <span>VERIFIED</span>
        </p>
    </div>
</div>
<center>
    <p class="mt-20" style="font-size:16px">Pay with UPI QR</p>
    <img alt="qr" src="<?php echo $qrCodeBase64;?>" class="qrCode" id="qr-image">
    <p class="mt-10">Amount : ₹<?php echo $amount;?></p>
    <p class="mt-20">Scan the QR Code or Click on UPI App</p>
    <div class="flex mt-20 apps" style="display:flex">
        <div>
            <a href="<?php echo $paytmintent;?>">
            <img src="../../auth/assets/images/paytm.png" class="upi_app_logo">
            </a>
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <div>
        <a class="paybyupiappsbtn" href="#" onclick="shareImage();">
            <img src="../../auth/assets/images/gpay.jpeg" class="upi_app_logo" /></a>
        </div>
    </div>
    <div class="loader mt-20"></div>
    <p class="time mt-20">Valid Till :    <span id="timer"></span></p>
</center>
</div>
<script>
        async function shareImage() {
            const imgElement = document.getElementById('qr-image');
            const response = await fetch(imgElement.src);
            const blob = await response.blob();
            const file = new File([blob], "UPI_QR.png", { type: blob.type });

            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                await navigator.share({
                    title: "Pay via Google Pay",
                    text: "Scan this QR code to pay via Google Pay.",
                    files: [file],
                });
            } else {
                alert("Sharing not supported. Long press on the QR code to save it.");
            }
        }
    </script>
      <script>
         var paymentProcessed = false;
         
         function checkPaymentStatus() {
         
             if (paymentProcessed) {
                 return;
             }
         
             $.ajax({
                 type: 'post',
                 url: '<?php echo $_SESSION[
            "root"
            ]; ?>/order2/payment-status',
                 data: 'byte_order_status=<?php echo $cxrmerchantTransactionId; ?>',
                 success: function (data) {
                     console.log(data);
                     if (data === 'SUCCESS') {
         
                         if (!paymentProcessed) {
                             paymentProcessed = true;
                             Swal.fire({
                                 title: '',
                                 text: 'Your Payment Received Successfully 👍 Please Wait',
                                 icon: 'success'
                             }).then((result) => {
                                 if (result.isConfirmed || result.isDismissed) {
                                     window.location.href = "../../redirect.php?url=<?php echo $redirect_url; ?>";
                                 }
                             });
                         }
                     } else if (data === 'FAILURE') {
         
                         if (!paymentProcessed) {
                             paymentProcessed = true;
                             Swal.fire({
                                 title: '',
                                 text: 'Your Payment Was Failed',
                                 icon: 'error'
                             }).then((result) => {
                                 if (result.isConfirmed || result.isDismissed) {
                                     
                                 }
                             });
                         }
                     }
                     else if (data === 'ALREADY') {
         
                         if (!paymentProcessed) {
                             paymentProcessed = true;
                             Swal.fire({
                                 title: '',
                                 text: 'Payment has already been completed!',
                                 icon: 'success'
                             }).then((result) => {
                                 if (result.isConfirmed || result.isDismissed) {
                                   
                                 }
                             });
                         }
                     }
         
                     else if (data === 'PENDING') {
                         
                     }
                 }
             });
         }
         
         setInterval(checkPaymentStatus, 2000);
         
         function payViaUPI() {
         
             window.location.href = "<?php echo $orders; ?>";
         }
         
         function upiCountdown(elm, minute, second, url) {
             document.getElementById(elm).innerHTML = minute + ":" + second;
             startTimer();
         
             function startTimer() {
                 var presentTime = document.getElementById(elm).innerHTML;
                 var timeArray = presentTime.split(/[:]+/);
                 var m = timeArray[0];
                 var s = checkSecond((timeArray[1] - 1));
                 if (s == 59) { m = m - 1 }
                 if (m < 0) {
                     Swal.fire({
                         title: 'Oops',
                         text: 'Transaction Timeout!',
                         icon: 'error'
                     });
                     window.location.href = "https://<?php echo $_SERVER[
            "SERVER_NAME"
            ]; ?>";
                 }
                 document.getElementById(elm).innerHTML = m + ":" + s;
                 setTimeout(startTimer, 1000);
             }
         
             function checkSecond(sec) {
                 if (sec < 10 && sec >= 0) { sec = "0" + sec };
                 if (sec < 0) { sec = "59" };
                 return sec;
             }
         }
         
         upiCountdown("timer", 5, 0, location.href);
      </script>
   </body>
</html>