

<?php
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);
define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");

include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "auth/config.php";
include ROOT_DIR . "pages/dbInfo.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $byteTransactionId = $_POST["byte_order_status"];
} else {
    header("HTTP/1.1 403 Forbidden");
    exit("Forbidden");
}
 $key = $_POST['key'];
$sqlSelectOrderscxr = "SELECT * FROM orders WHERE byteTransactionId=?";
$stmtSelectOrderscxr = $conn->prepare($sqlSelectOrderscxr);
$stmtSelectOrderscxr->bind_param("s", $byteTransactionId);
$stmtSelectOrderscxr->execute();
$resultSelectOrders = $stmtSelectOrderscxr->get_result();
$cxrrrowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrderscxr->close();

if (!$cxrrrowOrders) {
    die("Byter error");
}

$order_id = $cxrrrowOrders["order_id"];
$bytehackamount = $cxrrrowOrders["amount"];
$bytepaytmtxnref = $cxrrrowOrders["paytm_txn_ref"];
$db_merchantTransactionId = $byteTransactionId;

$sqlCheckStatus = "SELECT status FROM orders WHERE order_id=?";
$stmtCheckStatus = $conn->prepare($sqlCheckStatus);
$stmtCheckStatus->bind_param("s", $order_id);
$stmtCheckStatus->execute();
$resultCheckStatus = $stmtCheckStatus->get_result();
if ($resultCheckStatus->num_rows > 0) {
    $rowCheckStatus = $resultCheckStatus->fetch_assoc();
    if ($rowCheckStatus["status"] === "SUCCESS") {
        echo "ALREADY";
        $stmtCheckStatus->close();
        $conn->close();
        exit();
    }
}
$stmtCheckStatus->close();

$sqlDelete = "DELETE FROM reports WHERE status='' AND order_id=?";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bind_param("s", $order_id);
$stmtDelete->execute();
$stmtDelete->close();

$sqlSelectOrders = "SELECT * FROM orders WHERE order_id=?";
$stmtSelectOrders = $conn->prepare($sqlSelectOrders);
$stmtSelectOrders->bind_param("s", $order_id);
$stmtSelectOrders->execute();
$resultSelectOrders = $stmtSelectOrders->get_result();
$rowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrders->close();

if (!$rowOrders) {
    die("Order not found");
}

$user_token = $rowOrders["user_token"];
$gateway_txn = $rowOrders["gateway_txn"];
$cxrremark1 = $rowOrders["remark1"];
$db_amount = $rowOrders["amount"];

$sqlSelectUser = "SELECT * FROM users WHERE user_token=?";
$stmtSelectUser = $conn->prepare($sqlSelectUser);
$stmtSelectUser->bind_param("s", $user_token);
$stmtSelectUser->execute();
$resultSelectUser = $stmtSelectUser->get_result();
$rowUser = $resultSelectUser->fetch_assoc();
$stmtSelectUser->close();

$callback_url = $rowUser["callback_url"];
$megabyteuserid = $rowUser["id"];

 $sqlSelectMid = "SELECT * FROM bharatpe_tokens WHERE user_token=?";
$stmtSelectMid = $conn->prepare($sqlSelectMid);
$stmtSelectMid->bind_param("s", $user_token);
$stmtSelectMid->execute();
$resultSelectMid = $stmtSelectMid->get_result();
$rowMid = $resultSelectMid->fetch_assoc();

$stmtSelectMid->close();
 $merchantId=$rowMid["merchantId"];
 $token=$rowMid["token"];
 $cookie=$rowMid["cookie"];

function bharatpe_trans( $merchantId, $token, $cookie) {
    $fromDate = date('Y-m-d', strtotime('0 days'));
    $toDate = date('Y-m-d');

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://payments-tesseract.bharatpe.in/api/v1/merchant/transactions?module=PAYMENT_QR&merchantId=' . $merchantId . '&sDate=' . $fromDate . '&eDate=' . $toDate,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 120,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'token: ' . $token,
            'user-agent: Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
            'Cookie: ' . $cookie
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    $decodedResponse = json_decode($response, true);
  
    if (is_array($decodedResponse) && isset($decodedResponse['status']) && $decodedResponse['status']) {
        return $decodedResponse['data']['transactions'];
    } else {
        return $response;
    }
}
$json =  bharatpe_trans($merchantId,$token,$cookie);


// Assuming $json contains the array from your response (already decoded from JSON)
if ($json !== null && is_array($json)) {

    // Filter transactions by bankReferenceNo
    $matchedTxns = array_filter($json, function ($txn) use ($key) {
        return isset($txn["bankReferenceNo"]) && $txn["bankReferenceNo"] === $key;
    });

    // Reindex array
    $matchedTxns = array_values($matchedTxns);

    if (!empty($matchedTxns)) {
        $txn = $matchedTxns[0];

        if (isset($txn["status"]) && $txn["status"] === "SUCCESS") {
            // Extract transaction details
            $transactionId = $txn["internalUtr"];
            $paymentState = $txn["status"];
            $vpa = $txn["payerHandle"];
            $user_name = $txn["payerName"];
            $paymentApp = "NA";
            $amount = $txn["amount"];
            $transactionNote = $txn["internalUtr"];
            $cxrmerchantTransactionId = $order_id;
            $UTR = $txn["bankReferenceNo"];

            // Prepare SQL insert
            $sqlInsertReport = "INSERT INTO reports (
                transactionId, status, order_id, vpa, user_name, 
                paymentApp, amount, user_token, transactionNote, 
                merchantTransactionId, user_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmtInsertReport = $conn->prepare($sqlInsertReport);

            if (!$stmtInsertReport) {
                die("Prepare failed: " . $conn->error);
            }

            $stmtInsertReport->bind_param(
                "sssssssssss",
                $transactionId,
                $paymentState,
                $order_id,
                $vpa,
                $user_name,
                $paymentApp,
                $amount,
                $user_token,
                $transactionNote,
                $cxrmerchantTransactionId,
                $megabyteuserid
            );

            if ($stmtInsertReport->execute()) {
                $stmtInsertReport->close();
                //echo "SUCCESS";
            } else {
                //echo "Insert failed: " . $stmtInsertReport->error;
            }
        } else {
             //"PENDING";
           
        }
    } else {
        // "PENDING"; // No matching txn found
    }
} else {
    //echo "Invalid or empty JSON";
}

/********************************** */
$sqlSelectReports = "SELECT * FROM reports WHERE order_id=?";
$stmtSelectReports = $conn->prepare($sqlSelectReports);
$stmtSelectReports->bind_param("s", $order_id);
$stmtSelectReports->execute();
$resultSelectReports = $stmtSelectReports->get_result();
$rowReports = $resultSelectReports->fetch_assoc();
$stmtSelectReports->close();

 $db_status = $rowReports["status"];
 $db_user_token = $rowReports["user_token"];
 $db_transactionId = $rowReports["transactionId"];
 $db_transactionNote = $rowReports["transactionNote"];
//    echo "db_status: " . $db_status . "<br>";
//     echo "cxrmerchantTransactionId: " . $cxrmerchantTransactionId . "<br>";
//     echo "db_merchantTransactionId: " . $db_merchantTransactionId . "<br>";
//     echo "bytehackamount: " . $bytehackamount . "<br>";
//     echo "db_amount: " . $db_amount . "<br>";
if (
    $db_status == "SUCCESS" &&
    $cxrmerchantTransactionId == $db_merchantTransactionId &&
    $bytehackamount == $db_amount
) {
    $sql = "UPDATE orders SET status='SUCCESS' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE reports SET status='TXN_SUCCESS' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE orders SET utr=? WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $UTR, $order_id);
    $stmt->execute();
    $stmt->close();
    
  
    /*************************************************************************************/
 
$webhook_data = [
    'order_id'=> $order_id,
    'status'=> "SUCCESS",
    'remark1'=>$cxrremark1,
 ];


if (!empty($callback_url)) {
    $json_data = json_encode($webhook_data);

    $ch = curl_init($callback_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($json_data)
    ]);

    $webhook_response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log("Webhook curl error: " . curl_error($ch));
    }

    curl_close($ch);
}

    /*************************************************************************************/

     echo "SUCCESS";
} else {
    echo "PENDING";
}

if (
    $db_status == "FAILURE" ||
    $db_status == "FAILED" ||
    $db_status == "UPI_BACKBONE_ERROR"
) {
    echo "FAILURE";
}

$conn->close();

?>
