<?php

date_default_timezone_set("Asia/Kolkata");

define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");
include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "pages/dbInfo.php";
include ROOT_DIR . "auth/config.php";

$link_token = $_GET["token"];

$sql_fetch_order_id = "SELECT order_id, created_at FROM payment_links WHERE link_token = '$link_token'";
$result = getXbyY($sql_fetch_order_id);

if (count($result) === 0) {
    echo "Token not found or expired";
    exit();
}

$order_id = $result[0]["order_id"];
$created_at = strtotime($result[0]["created_at"]);
$current_time = time();

// if ($current_time - $created_at > 5 * 60) {
//     echo "Token has expired";
//     exit();
// }

$sql_order = "SELECT * FROM orders WHERE order_id='$order_id'";
$order_result = getXbyY($sql_order);

if (empty($order_result)) {
    echo "'Order not found!";
    exit();
}

$amount = $order_result[0]["amount"];
$user_token = $order_result[0]["user_token"];
$redirect_url = $order_result[0]["redirect_url"];
$cxrkalwaremark = $order_result[0]["byteTransactionId"];
$cxrbytectxnref = $order_result[0]["paytm_txn_ref"];
$cxruser_id = $order_result[0]["user_id"];
$orderstatus = $order_result[0]["status"];

if ($orderstatus == "SUCCESS") {
    echo "<script>Swal.fire('Success!', 'Order is already successful!', 'info');</script>";
    exit();
}

if ($redirect_url == "") {
    $redirect_url = "https://" . $_SERVER["SERVER_NAME"] . "/";
}

$sql_mobikwik = "SELECT * FROM mobikwik_token WHERE user_token='$user_token'";
$mobikwik_result = getXbyY($sql_mobikwik);
$upi_id = $mobikwik_result[0]["merchant_upi"];
$Authorization = $mobikwik_result[0]["Authorization"];

$sql_user = "SELECT * FROM users WHERE user_token='$user_token'";
$user_result = getXbyY($sql_user);
$unitId = $user_result[0]["name"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTR Number Submission</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../auth/assets/css/plugin.css?v=111">
    <link rel="stylesheet" type="text/css" href="../../auth/assets/css/app.css">
</head>
<script>
    $(document).ready(function () {
        Swal.fire({
            title: 'Enter UTR Number',
            input: 'text',
            inputLabel: 'UTR Number',
            inputPlaceholder: 'Enter your UTR number here',
            inputAttributes: {
                autocapitalize: 'off',
                oninput: "this.value = this.value.replace(/\\D/g, '').slice(0, 12);"
            },
            showCancelButton: true,
            confirmButtonText: 'Submit',
            didOpen: () => {

                const confirmButton = Swal.getConfirmButton();
                confirmButton.setAttribute('name', 'utrverify');
            },
            preConfirm: (utr_number) => {
                if (!utr_number) {
                    Swal.showValidationMessage('UTR number is required!');
                    return false;
                } else {
                    return new Promise((resolve) => {
                        let link  = "<?php echo $_SESSION['root'] ?>payment8/status.php";
                        console.log(link);
                        $.post( link , {
                            utr_number: utr_number,    
                            token: '<?php echo $link_token; ?>',  
                            utrverify: ''               
                        }, function(response) {

                            if (response.status === 'success') {
                                Swal.fire('Success', response.message, 'success').then(() => {

                                    if (response.redirect_url) {
                                        window.location.href = response.redirect_url;
                                    }
                                });
                            } else if (response.status === 'error') {
                                Swal.fire('Error', response.message, 'error');
                            } else if (response.status === 'info') {
                                Swal.fire('Info', response.message, 'info');
                            }
                            resolve(response);
                        }, 'json').fail(function() {
                            Swal.fire('Error', 'There was an issue processing your UTR number!', 'error');
                        });
                    });
                }
            }
        });
    });
</script>

</body>
</html>