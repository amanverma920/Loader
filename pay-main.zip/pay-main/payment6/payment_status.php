

<?php
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);
define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");

include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "auth/config.php";
include ROOT_DIR . "pages/dbInfo.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $byteTransactionId = $_POST["byte_order_status"];
} else {
    header("HTTP/1.1 403 Forbidden");
    exit("Forbidden");
}

$sqlSelectOrderscxr = "SELECT * FROM orders WHERE byteTransactionId=?";
$stmtSelectOrderscxr = $conn->prepare($sqlSelectOrderscxr);
$stmtSelectOrderscxr->bind_param("s", $byteTransactionId);
$stmtSelectOrderscxr->execute();
$resultSelectOrders = $stmtSelectOrderscxr->get_result();
$cxrrrowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrderscxr->close();

if (!$cxrrrowOrders) {
    die("Byter error");
}

$order_id = $cxrrrowOrders["order_id"];
$bytehackamount = $cxrrrowOrders["amount"];
$bytepaytmtxnref = $cxrrrowOrders["paytm_txn_ref"];
$db_merchantTransactionId = $byteTransactionId;

$sqlCheckStatus = "SELECT status FROM orders WHERE order_id=?";
$stmtCheckStatus = $conn->prepare($sqlCheckStatus);
$stmtCheckStatus->bind_param("s", $order_id);
$stmtCheckStatus->execute();
$resultCheckStatus = $stmtCheckStatus->get_result();
if ($resultCheckStatus->num_rows > 0) {
    $rowCheckStatus = $resultCheckStatus->fetch_assoc();
    if ($rowCheckStatus["status"] === "SUCCESS") {
        echo "ALREADY";
        $stmtCheckStatus->close();
        $conn->close();
        exit();
    }
}
$stmtCheckStatus->close();

$sqlDelete = "DELETE FROM reports WHERE status='' AND order_id=?";
$stmtDelete = $conn->prepare($sqlDelete);
$stmtDelete->bind_param("s", $order_id);
$stmtDelete->execute();
$stmtDelete->close();

$sqlSelectOrders = "SELECT * FROM orders WHERE order_id=?";
$stmtSelectOrders = $conn->prepare($sqlSelectOrders);
$stmtSelectOrders->bind_param("s", $order_id);
$stmtSelectOrders->execute();
$resultSelectOrders = $stmtSelectOrders->get_result();
$rowOrders = $resultSelectOrders->fetch_assoc();
$stmtSelectOrders->close();

if (!$rowOrders) {
    die("Order not found");
}

$user_token = $rowOrders["user_token"];
$gateway_txn = $rowOrders["gateway_txn"];
$cxrremark1 = $rowOrders["remark1"];
$db_amount = $rowOrders["amount"];

$sqlSelectUser = "SELECT * FROM users WHERE user_token=?";
$stmtSelectUser = $conn->prepare($sqlSelectUser);
$stmtSelectUser->bind_param("s", $user_token);
$stmtSelectUser->execute();
$resultSelectUser = $stmtSelectUser->get_result();
$rowUser = $resultSelectUser->fetch_assoc();
$stmtSelectUser->close();

$callback_url = $rowUser["callback_url"];
$megabyteuserid = $rowUser["id"];

$sqlSelectMid = "SELECT app_fc FROM freecharge_token WHERE user_token=?";
$stmtSelectMid = $conn->prepare($sqlSelectMid);
$stmtSelectMid->bind_param("s", $user_token);
$stmtSelectMid->execute();
$resultSelectMid = $stmtSelectMid->get_result();
$rowMid = $resultSelectMid->fetch_assoc();
$stmtSelectMid->close();

if ($rowMid) {
    $bytemerchantid = $rowMid["app_fc"];
} else {
    die("MID not found for user_token: $user_token");
}

$mid = $bytemerchantid;
$txn_ref_id = $bytepaytmtxnref;
$url = "https://www.freecharge.in/thv/listv3?fcAppType=MSITE";

$app_fc_cookie = $mid;
$postData = json_encode([
    "limit" => 1,
    "offset" => 0,
    "filterTxnTypes" => [],
    "status" => [],
    "txnTypes" => [],
    "selectedDate" => "",
]);

$headers = [
    "Content-Type: application/json",
    "Accept: application/json, text/plain, */*",
    "Origin: https://www.freecharge.in",
    "Referer: https://www.freecharge.in/",
    "User-Agent: Mozilla/5.0",
    "Cookie: app_fc={$app_fc_cookie}",
];

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    //echo "Request Error: " . curl_error($ch);
} else {
    $json = json_decode($response, true);
}

curl_close($ch);

if ($json !== null && isset($json["data"]["globalTransactions"])) {
  $found = 0;
  foreach ($json["data"]["globalTransactions"] as $t) {
    if($t["billerInfo"]["billerMetaData"][1]["sectionDetails"][2]["value"] == str_replace("-", "", $txn_ref_id)){
        $txn = $t;
        $found = 1;
        break;
        
        
    }
}

    if ($found==1) {
      

        if (
            isset($txn["txnDetails"]["status"]) &&
            $txn["txnDetails"]["status"] === "SUCCESS"
        ) {
            $transactionId = $txn_ref_id;
            $paymentState = $txn["txnDetails"]["status"];
            $vpa = $txn["txnDetails"]["subtitle"];
            $user_name = $txn["txnDetails"]["title"];
            $paymentApp = "NA";
            $amount = $txn["txnDetails"]["amount"];
            $transactionNote = $txn_ref_id;
            $cxrmerchantTransactionId =$txn_ref_id;

            $UTR = "";
            if (
                isset(
                    $txn["billerInfo"]["billerMetaData"][1][
                        "sectionDetails"
                    ][1]["value"]
                )
            ) {
                $UTR =
                    $txn["billerInfo"]["billerMetaData"][1][
                        "sectionDetails"
                    ][1]["value"];
            }

            $sqlInsertReport = "INSERT INTO reports (transactionId, status, order_id, vpa, user_name, paymentApp, amount, user_token, transactionNote, merchantTransactionId, user_id)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmtInsertReport = $conn->prepare($sqlInsertReport);

            if (!$stmtInsertReport) {
                die("Prepare failed: " . $conn->error);
            }

            $stmtInsertReport->bind_param(
                "sssssssssss",
                $transactionId,
                $paymentState,
                $order_id,
                $vpa,
                $user_name,
                $paymentApp,
                $amount,
                $user_token,
                $transactionNote,
                $cxrmerchantTransactionId,
                $megabyteuserid
            );

            if ($stmtInsertReport->execute()) {
                $stmtInsertReport->close();
            } else {
            }
        } else {
            //echo "PENDING";
        }
    } else {
      //  echo "PENDING";
      
    }
} else {
    //echo "PENDING";
    
}

$sqlSelectReports = "SELECT * FROM reports WHERE order_id=?";
$stmtSelectReports = $conn->prepare($sqlSelectReports);
$stmtSelectReports->bind_param("s", $order_id);
$stmtSelectReports->execute();
$resultSelectReports = $stmtSelectReports->get_result();
$rowReports = $resultSelectReports->fetch_assoc();
$stmtSelectReports->close();

$db_status = $rowReports["status"];
$db_user_token = $rowReports["user_token"];
$db_transactionId = $rowReports["transactionId"];
$db_transactionNote = $rowReports["transactionNote"];

if (
    $db_status == "SUCCESS" &&
    $cxrmerchantTransactionId == $db_merchantTransactionId &&
    $bytehackamount == $db_amount
) {
    $sql = "UPDATE orders SET status='SUCCESS' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE reports SET status='TXN_SUCCESS' WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();

    $sql = "UPDATE orders SET utr=? WHERE order_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $UTR, $order_id);
    $stmt->execute();
    $stmt->close();
 
    /*************************************************************************************/
 

    /*************************************************************************************/
 
$webhook_data = [
    'order_id'=> $order_id,
    'status'=> "SUCCESS",
    'remark1'=>$cxrremark1,
 ];


if (!empty($callback_url)) {
    $json_data = json_encode($webhook_data);

    $ch = curl_init($callback_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($json_data)
    ]);

    $webhook_response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log("Webhook curl error: " . curl_error($ch));
    }

    curl_close($ch);
}

    /*************************************************************************************/
    echo "SUCCESS";
} else {
    echo "PENDING";
}

if (
    $db_status == "FAILURE" ||
    $db_status == "FAILED" ||
    $db_status == "UPI_BACKBONE_ERROR"
) {
    echo "FAILURE";
}

$conn->close();

?>
