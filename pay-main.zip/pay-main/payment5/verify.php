<?php
date_default_timezone_set("Asia/Kolkata");

define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");
include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "pages/dbInfo.php";
include ROOT_DIR . "auth/config.php";

// Handle incoming token
$link_token = $_GET["token"] ?? '';

$status_type = '';
$status_message = '';
$show_form = true;

if (!$link_token) {
    $status_type = 'error';
    $status_message = 'No token provided';
    $show_form = false;
} else {
    $sql_fetch_order_id = "SELECT order_id, created_at FROM payment_links WHERE link_token = '$link_token'";
    $result = getXbyY($sql_fetch_order_id);

    if (count($result) === 0) {
        $status_type = 'error';
        $status_message = 'Token not found or expired';
        $show_form = false;
    } else {
        $order_id = $result[0]["order_id"];

        $sql_order = "SELECT * FROM orders WHERE order_id='$order_id'";
        $order_result = getXbyY($sql_order);
$redirect_url = $order_result[0]["redirect_url"] ?: "https://" . $_SERVER["SERVER_NAME"] . "/";
        if (empty($order_result)) {
            $status_type = 'error';
            $status_message = 'Order not found';
            $show_form = false;
        } else {
            $orderstatus = $order_result[0]["status"];

            if ($orderstatus === "PENDING_") {
                $status_type = 'info';
                $status_message = 'Order is yet to be verified!';
                $show_form = false;
            }
            if ($orderstatus === "SUCCESS") {
                $status_type = 'success';
                $status_message = 'Order is already successful!';
                header('Location:../../success');
                $show_form = false;
            }

            
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTR Number Submission</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../auth/assets/css/plugin.css?v=111">
    <link rel="stylesheet" type="text/css" href="../../auth/assets/css/app.css">
</head>
<body>

<script>
    $(document).ready(function () {
        const showForm = <?php echo json_encode($show_form); ?>;
        const statusType = "<?php echo $status_type; ?>";
        const statusMessage = "<?php echo $status_message; ?>";

        if (!showForm) {
            if (statusMessage) {
                Swal.fire(statusType.charAt(0).toUpperCase() + statusType.slice(1), statusMessage, statusType);
            }
            return;
        }

        Swal.fire({
            title: 'Enter UTR Number',
            input: 'text',
            inputLabel: 'UTR Number',
            inputPlaceholder: 'Enter your UTR number here',
            inputAttributes: {
                autocapitalize: 'off',
                oninput: "this.value = this.value.replace(/\\D/g, '').slice(0, 12);"
            },
            showCancelButton: true,
            confirmButtonText: 'Submit',
            preConfirm: (utr_number) => {
                if (!utr_number) {
                    Swal.showValidationMessage('UTR number is required!');
                    return false;
                }

                return new Promise((resolve) => {
                    $.post('<?php echo $_SESSION["root"]; ?>payment5/status.php', {
                        utr_number: utr_number,
                        token: '<?php echo $link_token; ?>',
                        utrverify: ''
                    }, function (response) {
                        let icon = response.status === 'success' ? 'success' :
                                   response.status === 'error' ? 'error' : 'info';

                        Swal.fire(icon.charAt(0).toUpperCase() + icon.slice(1), response.message, icon)
                            .then(() => {
                                if (response.redirect_url) {
                                    window.location.href = response.redirect_url;
                                } else {
                                    window.location.href = "../../pending";
                                }
                            });

                        resolve(response);
                    }, 'json').fail(function () {
                        Swal.fire('Error', 'There was an issue processing your UTR number!', 'error');
                    });
                });
            }
        });
    });
</script>

</body>
</html>
