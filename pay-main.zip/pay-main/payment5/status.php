<?php

date_default_timezone_set("Asia/Kolkata");

define("ROOT_DIR", realpath(dirname(__FILE__)) . "/../");
include ROOT_DIR . "pages/dbFunctions.php";
include ROOT_DIR . "pages/dbInfo.php";
include ROOT_DIR . "auth/config.php";
include "smtp/PHPMailerAutoload.php";
function smtp_mailer($to, $subject, $msg, $email, $pass, $host, $sender)
    {
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "tls";
        $mail->Host = $host;
        $mail->Port = 587;
        $mail->IsHTML(true);
        $mail->CharSet = "UTF-8";
        //$mail->SMTPDebug = 2;
        $mail->Username = $email;
        $mail->Password = $pass;
        $mail->setFrom($email, $sender);
        $mail->Subject = $subject;
        $mail->Body =$msg;
        $mail->AddAddress($to);
        $mail->SMTPOptions = [
            "ssl" => [
                "verify_peer" => false,
                "verify_peer_name" => false,
                "allow_self_signed" => false,
            ],
        ];
        if (!$mail->Send()) {
            return "0";
        } else {
            return "1";
        }
    }

$link_token = $_POST["token"];

$sql_fetch_order_id = "SELECT order_id, created_at FROM payment_links WHERE link_token = '$link_token'";

$result = getXbyY($sql_fetch_order_id);

if (count($result) === 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Token not found or expired",
    ]);
    exit();
}

$order_id = $result[0]["order_id"];
$created_at = strtotime($result[0]["created_at"]);
$current_time = time();

$sql_order = "SELECT * FROM orders WHERE order_id='$order_id'";
$order_result = getXbyY($sql_order);

if (empty($order_result)) {
    echo json_encode(["status" => "error", "message" => "Order not found"]);
    exit();
}

$user_token = $order_result[0]["user_token"];
$redirect_url =
    $order_result[0]["redirect_url"] ?:
    "https://" . $_SERVER["SERVER_NAME"] . "/";
$cxruser_id = $order_result[0]["user_id"];
$orderstatus = $order_result[0]["status"];

if ($orderstatus == "SUCCESS") {
    echo json_encode([
        "status" => "success",
        "message" => "Order is already successful",
    ]);
    exit();
}if ($orderstatus == "PENDING_") {
    echo json_encode([
        "status" => "info",
        "message" => "We are verifying the payment!",
    ]);
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["utrverify"])) {
    $utr_number = $_POST["utr_number"];

    if (!empty($utr_number)) {
        // Update order status and utr
        $update_query =
            "UPDATE orders SET status='PENDING_', utr=? WHERE order_id=? AND user_id=?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("ssi", $utr_number, $order_id, $cxruser_id);
        if (!$stmt_update->execute()) {
            echo json_encode([
                "status" => "error",
                "message" =>
                    "Failed to update order status: " . $stmt_update->error,
            ]);
            $stmt_update->close();
            exit();
        }
        $stmt_update->close();

      
       
        $date = date("Y-m-d");
        $utr = $utr_number;
        $user_id = $cxruser_id;
       

        // Prepare statement
        $stmt = $conn->prepare("
    INSERT INTO googlepay_transactions 
    (date, utr, user_id,order_id) 
    VALUES (?, ?, ?,?)
");

        // Bind parameters: s (string), d (double), s, s, s, i (integer), i, i
        $stmt->bind_param(
            "siis",
         
            $date,
            $utr,
            $user_id,
            $order_id
          
        );

        // Execute and check
        if ($stmt->execute()) {
$sql_api = "SELECT * FROM api_settings";
$api_result = getXbyY($sql_api);
$sql_email = "SELECT email FROM users where user_token='$user_token'";
$email_result = getXbyY($sql_email);
/********************MAIL DETAILS ******************* */
 $receiver_email = $email_result[0]['email'];
$sender_email = $api_result[0]['sender_email'];
$sender_host = $api_result[0]['host'];
$sender_pass = $api_result[0]['pass'];
/*************************************** */
                 smtp_mailer(
        $receiver_email,
        "PAYMENT INFO",
        "Someone paid you using GooglePay! Please Open admin panel and approve the payment!",
        $sender_email,
        $sender_pass,
        $sender_host,
        "PAYMENT GATEWAY"
    );
            echo json_encode([
                "status" => "info",
                "message" =>
                    "UTR Received! You will soon receive a mail from us!",
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Failed to insert transaction: " . $stmt->error,
            ]);
        }

        $stmt->close();
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "UTR number is missing",
        ]);
    }
}

?>
