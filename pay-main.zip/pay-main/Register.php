
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login Form</title>
      <!-- Bootstrap CSS -->
      <?php include "auth/common_files/head.php"; ?>

  <link rel="stylesheet" type="text/css" href="auth/assets/css/plugin.css">

  <link rel="stylesheet" type="text/css" href="auth/assets/css/app.css">

      <style>

         html, body {
         height: 100%;

         background: url('https://wallpapers.com/images/hd/python-program-coding-6kx47hfzock0lrhe.webp') no-repeat center center fixed;
         background-size: cover;
         }

         .overlay {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background: rgba(0, 0, 0, 0.2); 
         }
      </style>
   </head>
   <body class="p-4 mx-auto">
      <?php
include "auth/header.php";
include "auth/function.php";

if (isset($_POST["create"])) {
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];

    $checkMobileQuery = "SELECT * FROM `users` WHERE `mobile` = '$mobile'";
    $checkMobileResult = mysqli_query($conn, $checkMobileQuery);

    $checkEmailQuery = "SELECT * FROM `users` WHERE `email` = '$email'";
    $checkEmailResult = mysqli_query($conn, $checkEmailQuery);

    if (mysqli_num_rows($checkMobileResult) > 0) {
       echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your mobile number already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
    } elseif (mysqli_num_rows($checkEmailResult) > 0) {
        echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your email ID already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
    } else {
        $password = $_POST["password"];
        $name = $_POST["name"];
        $company = $_POST["company"];
        $pin = $_POST["pin"];
        $pan = $_POST["pan"];
        $aadhaar = $_POST["aadhaar"];

        $checkpan = "SELECT * FROM `users` WHERE `pan` = '$pan'";
        $checkpanResult = mysqli_query($conn, $checkpan);

        $checkaadhar = "SELECT * FROM `users` WHERE `aadhaar` = '$aadhaar'";
        $checkAadharResult = mysqli_query($conn, $checkaadhar);

        if (mysqli_num_rows($checkpanResult) > 0) {
            echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your Pan Number already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        } elseif (mysqli_num_rows($checkAadharResult) > 0) {
           echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your Aadhar ID already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        } else {
            $location = $_POST["location"];
            $key = md5(rand(00000000, 99999999));
            $pass = password_hash($password, PASSWORD_BCRYPT);
            $today = date("Y-m-d", strtotime("+1 days"));

           

            $register = "INSERT INTO `users`(`name`, `mobile`, `role`, `password`, `email`, `company`, `pin`, `pan`, `aadhaar`, `location`, `user_token`, `expiry`) 
   VALUES ('$name', '$mobile', 'User', '$pass', '$email', '$company', '$pin', '$pan', '$aadhaar', '$location', '$key', '$today')";

            $result = mysqli_query($conn, $register);

            $msg = "Dear $name thanks For Registering Us
   Your Username = $mobile
   Your Password = $password
   Thanks & Regards";
            $encodedMsg = urlencode($msg);

            if ($result) {
                echo "<script>
Swal.fire({
title: 'Success!',
text: 'Account Creating Successful! Now please login!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
            } else {
                echo "<script>
Swal.fire({
title: 'Error!',
text: 'Some error Occured!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
            }
        }
    }
}
?>
      <!-- Black overlay -->
      <div class="overlay"></div>
      <form class="card p-4 mx-auto mb-4" style="max-width: 95%;width: 400px" method="POST" action="<?php echo htmlspecialchars(
          $_SERVER["PHP_SELF"]
      ); ?>">
      <h5>Sign Up</h5>
         <div class="mb-3">
            <label class="form-label" for="username">Full Name</label>
            <input type="text" class="form-control" id="username" name="name" placeholder="Enter Full Name" autofocus>
         </div>
         <div class="mb-3"><label class="form-label" for="username">WhatsApp Number</label>
            <input type="number" class="form-control" id="Number" name="mobile"  placeholder="Enter WhatsApp Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);" autofocus>
         </div>
         <div class="mb-3"><label class="form-label" for="email">e-Mail ID</label>
            <input type="text" class="form-control" id="email" name="email" placeholder="Enter e-Mail ID">
         </div>
         <div class="mb-3">
            <label class="form-label" for="username">Company Name</label>
            <input type="text" class="form-control" id="company" name="company" placeholder="Enter Company Name" required>
         </div>
         <div class="mb-3">
            <label class="form-label" for="username">Aadhaar Number</label>
            <input type="number" class="form-control" id="aadhar" name="aadhaar" placeholder="Enter Aadhaar Number" required>
         </div>
         <div class="mb-3">
            <label class="form-label" for="username">PAN Number</label>
            <input type="text" class="form-control" id="pan" name="pan" placeholder="Enter PAN Number" required>
         </div>
         <div class="mb-3">
            <label class="form-label" for="username">District</label>
            <input type="text" class="form-control" id="location" name="location" placeholder="Enter District" required autofocus>
         </div>
         <div class="mb-3"><label class="form-label" for="username">PinCode</label>
            <input type="text" class="form-control" id="pin" name="pin" placeholder="Enter PinCode" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);" required autofocus>
         </div>
         <div class="mb-3"><label class="form-label" for="username">Password</label>
            <input type="password" class="form-control" id="pin" name="password" placeholder="Set Password"  required autofocus>
         </div>
         <div class=" py-2">
            <div class="form-check mb-0">
               <input class="form-check-input" type="checkbox" id="terms-conditions" name="terms">
               <label class="form-label" class="form-check-label" for="terms-conditions">
               I Agree To The
               <a href="javascript:void(0);">Terms & Conditions</a>
               </label>
            </div>
         </div>
         <button type="submit" name="create" class="btn btn-primary d-grid w-100">
         SignUp
         </button>
      </form><br><br>
      <!-- Bootstrap JS (Optional) -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
   </body>
</html>