<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "../auth/config.php";

function requestt($url, $data0, $headers, $includeHeader = false) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, 1);      
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data0);       
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');  
    curl_setopt($ch, CURLOPT_HEADER, $includeHeader);

    $output1 = curl_exec($ch); 

    if(curl_errno($ch)) {
        echo 'cURL error: ' . curl_error($ch);
        curl_close($ch);
        return false;
    }

    curl_close($ch);
    return $output1;
}

function checksum($data) {
    include "../auth/config.php";
    $domain = $_SERVER['SERVER_NAME'];
    $url = $root."phnpe/checksum_my.php?trd=" . urlencode($data);

    $headers = [
        "Host: $domain",
        "Connection: keep-alive",
        "Cache-Control: max-age=0",
        "Upgrade-Insecure-Requests: 1",
        "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Safari/537.36",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding: gzip, deflate",
        "Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,bn;q=0.6"
    ];

    $userDetails = requestt($url, "", $headers, false);

    if ($userDetails === false) {
        return "Error fetching details";  
    }

    return substr($userDetails, 4);
}

function checksum_2($data) {
    $domain = $_SERVER['SERVER_NAME'];
    include "../auth/config.php";
    $url =$root."phnpe/checksum_my.php?trd=" . urlencode($data);

    $headers = [
        "Host: $domain",
        "Connection: keep-alive",
        "Cache-Control: max-age=0",
        "Upgrade-Insecure-Requests: 1",
        "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Safari/537.36",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding: gzip, deflate",
        "Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,bn;q=0.6"
    ];

    $userDetails = requestt($url, "", $headers, false);

    if ($userDetails === false) {
        return "Error fetching details";  
    }

    return substr($userDetails, 4);
}
?>