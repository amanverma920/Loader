<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">

    <?php include "auth/common_files/head.php";?>
    <link rel="stylesheet" href="auth/assets/css/plugin.css">
    <link rel="stylesheet" href="auth/assets/css/app.css">
    <style type="text/css">
        body{
            height: 100vh;
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center"><?php

$dbInfoFile = 'pages/dbInfo.php';
$configFile = 'auth/config.php';
$sqlFile = 'sql.sql'; 

if (file_exists($dbInfoFile) && file_exists($configFile)) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $host = $_POST['host'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $dbname = $_POST['dbname'];

    $connection = new mysqli($host, $username, $password, $dbname);

    if ($connection->connect_error) {

        echo "
    
        <script>
            window.onload = function() {
                swal({
                    title: 'Error!',
                    text: 'Database details are incorrect: " . addslashes($connection->connect_error) . "',
                    icon: 'error',
                    button: 'OK'
                }).then(function() {
                    window.location.href = 'install.php'; 
                });
            }
        </script>";
        exit; 
    } else {

        $dbInfoContent = "<?php\n";
        $dbInfoContent .= "error_reporting(0);\n";
        $dbInfoContent .= "date_default_timezone_set('Asia/Kolkata');\n\n";
        $dbInfoContent .= "function connect_database() {\n";
        $dbInfoContent .= "\t\$fetchType = \"array\";\n";
        $dbInfoContent .= "\t\$dbHost = \"$host\";\n";
        $dbInfoContent .= "\t\$dbLogin = \"$username\";\n";
        $dbInfoContent .= "\t\$dbPwd = '$password';\n";
        $dbInfoContent .= "\t\$dbName = \"$dbname\";\n";
        $dbInfoContent .= "\t\$con = mysqli_connect(\$dbHost, \$dbLogin, \$dbPwd, \$dbName);\n";
        $dbInfoContent .= "\tif (!\$con) {\n";
        $dbInfoContent .= "\t\tdie(\"Database Connection failed: \" . mysqli_connect_errno());\n";
        $dbInfoContent .= "\t}\n";
        $dbInfoContent .= "\treturn (\$con);\n";
        $dbInfoContent .= "}\n\n";
        $dbInfoContent .= "// Database configuration\n";
        $dbInfoContent .= "define('DB_HOST', '$host');\n";
        $dbInfoContent .= "define('DB_USERNAME', '$username');\n";
        $dbInfoContent .= "define('DB_PASSWORD', '$password');\n";
        $dbInfoContent .= "define('DB_NAME', '$dbname');\n";
        $dbInfoContent .= "?>";

$configContent = "<?php\n";
$configContent .= "// error_reporting(E_ALL);\n";
$configContent .= "// ini_set(\"display_errors\", true);\n\n";
$configContent .= "\$conn = new mysqli('$host', '$username', '$password', '$dbname');\n";
$configContent .= "\$server = \$_SERVER[\"SERVER_NAME\"];\n\n";
$configContent .= "// Fetch site settings from the database\n";
$configContent .= "\$query = \"SELECT * FROM site_settings LIMIT 1\";\n";
$configContent .= "\$result = mysqli_query(\$conn, \$query);\n\n";
$configContent .= "if (\$result && mysqli_num_rows(\$result) > 0) {\n";
$configContent .= "    \$site_settings = mysqli_fetch_assoc(\$result);\n";
$configContent .= "} else {\n";
$configContent .= "    // Default values in case settings are not found\n";
$configContent .= "    \$site_settings = [\n";
$configContent .= "        'brand_name' => 'PAYMENT GATEWAY',\n";
$configContent .= "        'logo_url' => 'https://cashfreelogo.cashfree.com/website/landings-cache/landings/logo-lightbg_3x.webp',\n";
$configContent .= "        'site_link' => 'http://localhost/pay/',\n";
$configContent .= "        'whatsapp_number' => 'XXXXXXXXXX',\n";
$configContent .= "        'copyright_text' => '© Default Copyright'\n";
$configContent .= "    ];\n";
$configContent .= "}\n";
$configContent.= "\$root=\$site_settings[\"site_link\"];";
$configContent.="\$_SESSION[\"root\"]=\$root;";
$configContent .= "?>";

        file_put_contents($dbInfoFile, $dbInfoContent);
        file_put_contents($configFile, $configContent);

        if (file_exists($sqlFile)) {
            $sql = file_get_contents($sqlFile);
            $queries = explode(";", $sql); 

            foreach ($queries as $query) {
                $query = trim($query);
                if ($query) {
                    if (!$connection->query($query)) {
                        echo "
                       
                        <script>
                            window.onload = function() {
                                swal({
                                    title: 'Import Error!',
                                    text: 'Failed to execute query: " . addslashes($connection->error) . "',
                                    icon: 'error',
                                    button: 'OK'
                                }).then(function() {
                                    window.location.href = 'install.php';
                                });
                            }
                        </script>";
                        exit; 
                    }
                }
            }
        }

        header('Location: index.php');
        exit;
    }
}

?>

  <form style="max-width: 95%;width: 400px"  method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="card p-4">
                    <h5 class="">Setup Database</h5>
                    <p>Fill out the form quickly and click Install!</p>
                    
                    <div class="mb-3">
                        <label for="MID" class="form-label">Host</label>
                        <input type="text" name="host" id="MID" placeholder="" class="form-control " required value="localhost">
                    </div>
                    <div class="mb-3">
                        <label for="MID" class="form-label">DB Username</label>
                        <input type="text" name="username" id="MID" placeholder="" class="form-control " required value="root">
                    </div>
                    <div class="mb-3">
                        <label for="MID" class="form-label">DB Password</label>
                        <input type="text" name="password" id="MID" placeholder="" class="form-control " value="">
                    </div>
                    <div class="mb-3">
                        <label for="MID" class="form-label">DB Name</label>
                        <input type="text" name="dbname" id="MID" placeholder="" class="form-control " required value="pay">
                    </div>

                    

                    

                    <div class="d-grid mt-1">
                        <button type="submit" name="submit" class="btn btn-success">Install <i class="fa-solid fa-arrow-right"></i></button>
                    </div>
                </div>
            </form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
</body>
</html>