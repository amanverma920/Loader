<!--<a href="Register">Register</a><a href="auth/index">Login</a>-->
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if (!file_exists("pages/dbInfo.php") || !file_exists("auth/config.php")) {
header('Location: install.php');
exit;
}
include "auth/header.php";
?><!--<a href="Register">Register</a><a href="auth/index">Login</a>-->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $site_settings['brand_name'];?> | Secure Payment Gateway</title>
  <meta name="description" content="Professional payment gateway solution for UPI, wallets, and bank transfers in India">
  
  <!-- Favicon -->
  <link rel="icon" href="https://www.cloudlinkd.com/wp-content/uploads/2022/07/favicon.png" type="image/png">
  
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  
  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- AOS Animation -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <style>
    :root {
      --primary-color: #28a745;
      --secondary-color: #17a2b8;
      --dark-color: #212529;
      --light-color: #f8f9fa;
    }
    
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      background-color: #ffffff;
      color: #333;
      line-height: 1.6;
    }
    
    .navbar {
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    }
    
    .navbar-brand img {
      transition: transform 0.3s;
    }
    
    .navbar-brand:hover img {
      transform: scale(1.05);
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      padding: 10px 25px;
      font-weight: 500;
      letter-spacing: 0.5px;
    }
    
    .btn-outline-primary {
      color: var(--primary-color);
      border-color: var(--primary-color);
    }
    
    .btn-outline-primary:hover {
      background-color: var(--primary-color);
    }
    
    .hero {
      background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1526628953301-3e589a6a8b74') center center/cover no-repeat;
      height: 90vh;
      color: #fff;
      display: flex;
      align-items: center;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    
    .hero-content {
      position: relative;
      z-index: 2;
    }
    
    .hero h1 {
      font-size: 3.5rem;
      font-weight: 700;
      margin-bottom: 20px;
      line-height: 1.2;
    }
    
    .hero p {
      font-size: 1.3rem;
      margin-bottom: 30px;
      opacity: 0.9;
    }
    
    .hero .btn {
      margin: 10px;
      font-size: 1.1rem;
      padding: 12px 30px;
      border-radius: 50px;
      font-weight: 500;
      transition: all 0.3s;
    }
    
    .hero .btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    
    .feature-box {
      padding: 30px;
      border-radius: 10px;
      background: #fff;
      box-shadow: 0 5px 30px rgba(0,0,0,0.05);
      transition: all 0.3s;
      height: 100%;
      text-align: center;
    }
    
    .feature-box:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }
    
    .feature-icon {
      font-size: 2.5rem;
      color: var(--primary-color);
      margin-bottom: 20px;
    }
    
    .section-title {
      position: relative;
      margin-bottom: 50px;
      text-align: center;
    }
    
    .section-title h2 {
      font-weight: 700;
      position: relative;
      display: inline-block;
      padding-bottom: 15px;
    }
    
    .section-title h2:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 3px;
      background: var(--primary-color);
    }
    
    .testimonial-card {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 30px rgba(0,0,0,0.05);
      position: relative;
      margin-top: 40px;
    }
    
    .testimonial-card:before {
      content: '\201C';
      font-family: Georgia, serif;
      font-size: 60px;
      color: var(--primary-color);
      opacity: 0.2;
      position: absolute;
      top: 10px;
      left: 10px;
    }
    
    .testimonial-author {
      display: flex;
      align-items: center;
      margin-top: 20px;
    }
    
    .testimonial-author img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 15px;
      object-fit: cover;
    }
    
    .author-info h5 {
      margin-bottom: 0;
      font-weight: 600;
    }
    
    .author-info p {
      margin-bottom: 0;
      font-size: 0.9rem;
      color: #6c757d;
    }
    
    .how-it-works .step {
      position: relative;
      padding-left: 80px;
      margin-bottom: 40px;
    }
    
    .how-it-works .step-number {
      position: absolute;
      left: 0;
      top: 0;
      width: 60px;
      height: 60px;
      background: var(--primary-color);
      color: #fff;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: 700;
    }
    
    footer {
      background: var(--dark-color);
      color: #fff;
      padding: 60px 0 20px;
    }
    
    footer h5 {
      color: #fff;
      margin-bottom: 20px;
      font-weight: 600;
    }
    
    footer ul li {
      margin-bottom: 10px;
    }
    
    footer a {
      color: rgba(255,255,255,0.7);
      text-decoration: none;
      transition: all 0.3s;
    }
    
    footer a:hover {
      color: #fff;
      padding-left: 5px;
    }
    
    .social-icons a {
      display: inline-block;
      width: 40px;
      height: 40px;
      background: rgba(255,255,255,0.1);
      border-radius: 50%;
      text-align: center;
      line-height: 40px;
      margin-right: 10px;
      transition: all 0.3s;
    }
    
    .social-icons a:hover {
      background: var(--primary-color);
      transform: translateY(-5px);
    }
    
    @media (max-width: 768px) {
      .hero h1 {
        font-size: 2.5rem;
      }
      
      .hero p {
        font-size: 1.1rem;
      }
      
      .how-it-works .step {
        padding-left: 0;
        padding-top: 70px;
      }
      
      .how-it-works .step-number {
        left: 50%;
        top: 0;
        transform: translateX(-50%);
      }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="<?php echo $site_settings['site_link'];?>">
      <img src="<?php echo $site_settings['logo_url'];?>" alt="<?php echo $site_settings['brand_name'];?>" style="height: 40px;" class="me-2">
      <span class="fw-bold"><?php echo $site_settings['brand_name'];?></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="#pricing">Pricing</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#features">Features</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#how-it-works">How It Works</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#testimonials">Testimonials</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact">Contact</a>
        </li>
      </ul>
      <div class="ms-lg-3 mt-3 mt-lg-0">
        <a href="auth/index" class="btn btn-outline-light me-2">Login</a>
        <a href="Register" class="btn btn-primary">Register</a>
      </div>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero" id="home">
  <div class="container">
    <div class="hero-content" data-aos="fade-up">
      <h1>Powerful Payment Solutions for Your Business</h1>
      <p class="lead">Accept UPI, wallets, and bank transfers with <?php echo $site_settings['brand_name'];?> - India's most reliable payment gateway</p>
      <div class="d-flex flex-wrap justify-content-center">
        <a href="auth/lib/buy.php" class="btn btn-primary btn-lg">Buy Source Now</a>
        <a href="auth/lib/test.php" class="btn btn-outline-light btn-lg">Pay ₹1</a>
      </div>
    </div>
  </div>
</section>

<!-- Features Section -->
<section class="py-5 bg-light" id="features">
  <div class="container py-5">
    <div class="section-title" data-aos="fade-up">
      <h2>Why Choose CloudLinkd UPI</h2>
      <p class="text-muted">Experience seamless transactions with our advanced features</p>
    </div>
    
    <div class="row g-4">
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-bolt"></i>
          </div>
          <h3>Lightning Fast</h3>
          <p>Process payments in seconds with our optimized infrastructure that ensures minimal latency.</p>
        </div>
      </div>
      
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-shield-alt"></i>
          </div>
          <h3>Bank-Level Security</h3>
          <p>PCI DSS compliant with end-to-end encryption to protect your transactions and customer data.</p>
        </div>
      </div>
      
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-rupee-sign"></i>
          </div>
          <h3>Lowest Fees</h3>
          <p>Competitive pricing with transparent fee structure and no hidden charges.</p>
        </div>
      </div>
      
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-mobile-alt"></i>
          </div>
          <h3>UPI Integration</h3>
          <p>Seamless integration with all UPI apps including Google Pay, PhonePe, Paytm and more.</p>
        </div>
      </div>
      
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-chart-line"></i>
          </div>
          <h3>Real-time Analytics</h3>
          <p>Comprehensive dashboard with real-time reports and transaction insights.</p>
        </div>
      </div>
      
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
        <div class="feature-box">
          <div class="feature-icon">
            <i class="fas fa-headset"></i>
          </div>
          <h3>24/7 Support</h3>
          <p>Dedicated support team available round the clock to assist you.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- How It Works Section -->
<section class="py-5" id="how-it-works">
  <div class="container py-5">
    <div class="section-title" data-aos="fade-up">
      <h2>How It Works</h2>
      <p class="text-muted">Get started in just 3 simple steps</p>
    </div>
    
    <div class="row how-it-works">
      <div class="col-lg-4" data-aos="fade-right">
        <div class="step">
          <div class="step-number">1</div>
          <h3>Create Your Account</h3>
          <p>Register with your business details and complete the quick verification process.</p>
        </div>
      </div>
      
      <div class="col-lg-4" data-aos="fade-right" data-aos-delay="100">
        <div class="step">
          <div class="step-number">2</div>
          <h3>Connect Payment Methods</h3>
          <p>Link your UPI ID, bank account, or integrate with our API for automated payments.</p>
        </div>
      </div>
      
      <div class="col-lg-4" data-aos="fade-right" data-aos-delay="200">
        <div class="step">
          <div class="step-number">3</div>
          <h3>Start Accepting Payments</h3>
          <p>Generate payment links or use our checkout to begin receiving money instantly.</p>
        </div>
      </div>
    </div>
    
    <div class="text-center mt-5" data-aos="fade-up">
      <a href="Register" class="btn btn-primary btn-lg px-5">Sign Up Free</a>
    </div>
  </div>
</section>

<!-- Pricing Section -->
<section class="pricing-section py-5 bg-light" id="pricing">
  <div class="container py-5">
    <div class="section-title" data-aos="fade-up">
      <h2>Simple, Transparent Pricing</h2>
      <p class="text-muted">No hidden fees. Pay only for what you use.</p>
    </div>

    <div class="row g-4 justify-content-center">
      <!-- Starter Plan -->
      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
        <div class="pricing-card">
          <div class="pricing-header">
            <h3>Starter</h3>
            <div class="price">
              <span class="currency">₹</span>
              <span class="amount">1.99</span>
              <span class="period">/transaction</span>
            </div>
            <p>Perfect for small businesses</p>
          </div>
          <div class="pricing-features">
            <ul>
              <li><i class="fas fa-check-circle text-success"></i> UPI Payments</li>
              <li><i class="fas fa-check-circle text-success"></i> 1000 transactions/month</li>
              <li><i class="fas fa-check-circle text-success"></i> Basic Dashboard</li>
              <li><i class="fas fa-check-circle text-success"></i> Email Support</li>
              <li><i class="fas fa-times-circle text-muted"></i> Advanced Analytics</li>
              <li><i class="fas fa-times-circle text-muted"></i> Priority Support</li>
            </ul>
          </div>
          <div class="pricing-footer">
            <a href="Register" class="btn btn-outline-primary">Get Started</a>
          </div>
        </div>
      </div>

      <!-- Popular - Business Plan -->
      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
        <div class="pricing-card popular">
          <div class="popular-badge">MOST POPULAR</div>
          <div class="pricing-header">
            <h3>Business</h3>
            <div class="price">
              <span class="currency">₹</span>
              <span class="amount">1.49</span>
              <span class="period">/transaction</span>
            </div>
            <p>Growing businesses</p>
          </div>
          <div class="pricing-features">
            <ul>
              <li><i class="fas fa-check-circle text-success"></i> UPI + Card Payments</li>
              <li><i class="fas fa-check-circle text-success"></i> 5000 transactions/month</li>
              <li><i class="fas fa-check-circle text-success"></i> Advanced Dashboard</li>
              <li><i class="fas fa-check-circle text-success"></i> Phone + Email Support</li>
              <li><i class="fas fa-check-circle text-success"></i> Basic Analytics</li>
              <li><i class="fas fa-times-circle text-muted"></i> Dedicated Account Manager</li>
            </ul>
          </div>
          <div class="pricing-footer">
            <a href="Register" class="btn btn-primary">Choose Plan</a>
          </div>
        </div>
      </div>

      <!-- Enterprise Plan -->
      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
        <div class="pricing-card">
          <div class="pricing-header">
            <h3>Enterprise</h3>
            <div class="price">
              <span class="currency">₹</span>
              <span class="amount">0.99</span>
              <span class="period">/transaction*</span>
            </div>
            <p>High volume businesses</p>
          </div>
          <div class="pricing-features">
            <ul>
              <li><i class="fas fa-check-circle text-success"></i> All Payment Methods</li>
              <li><i class="fas fa-check-circle text-success"></i> Unlimited transactions</li>
              <li><i class="fas fa-check-circle text-success"></i> Premium Dashboard</li>
              <li><i class="fas fa-check-circle text-success"></i> 24/7 Priority Support</li>
              <li><i class="fas fa-check-circle text-success"></i> Advanced Analytics</li>
              <li><i class="fas fa-check-circle text-success"></i> Dedicated Account Manager</li>
            </ul>
          </div>
          <div class="pricing-footer">
            <a href="#contact" class="btn btn-outline-primary">Contact Sales</a>
          </div>
        </div>
      </div>
    </div>

    <div class="text-center mt-5" data-aos="fade-up">
      <p class="text-muted">* Volume discounts available. <a href="#contact">Contact us</a> for custom enterprise solutions.</p>
    </div>
  </div>
</section>

<style>
/* Pricing Section Styles */
.pricing-section {
  position: relative;
}

.pricing-card {
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 5px 30px rgba(0,0,0,0.05);
  transition: all 0.3s ease;
  height: 100%;
  position: relative;
  overflow: hidden;
  border: 1px solid #eee;
}

.pricing-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.pricing-card.popular {
  border: 1px solid var(--primary-color);
}

.popular-badge {
  position: absolute;
  top: 15px;
  right: -30px;
  background: var(--primary-color);
  color: white;
  padding: 5px 30px;
  font-size: 12px;
  font-weight: 600;
  transform: rotate(45deg);
  width: 120px;
  text-align: center;
}

.pricing-header {
  padding: 30px 20px;
  text-align: center;
  border-bottom: 1px solid #f5f5f5;
}

.pricing-header h3 {
  font-weight: 700;
  margin-bottom: 10px;
}

.price {
  margin: 15px 0;
  font-weight: 700;
}

.price .currency {
  font-size: 24px;
  vertical-align: super;
}

.price .amount {
  font-size: 48px;
  line-height: 1;
}

.price .period {
  font-size: 14px;
  color: #6c757d;
  font-weight: normal;
}

.pricing-features {
  padding: 30px 20px;
}

.pricing-features ul {
  list-style: none;
  padding: 0;
}

.pricing-features li {
  margin-bottom: 15px;
  display: flex;
  align-items: center;
}

.pricing-features i {
  margin-right: 10px;
  font-size: 18px;
}

.pricing-footer {
  padding: 20px;
  text-align: center;
  border-top: 1px solid #f5f5f5;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
  .pricing-card.popular {
    transform: scale(1);
  }
}

@media (max-width: 768px) {
  .price .amount {
    font-size: 36px;
  }
  
  .pricing-features li {
    font-size: 14px;
  }
}
</style>

<!-- Auto-Floating Payment Logos Section -->
<section class="payment-logos-container py-5">
  <div class="container">
    <h4 class="text-center mb-5 text-muted">TRUSTED BY BUSINESSES INTEGRATED WITH</h4>
    <div class="payment-logos-grid">
      <!-- Paytm -->
      <div class="payment-logo" data-aos="fade-up">
        <img src="https://www.logo.wine/a/logo/Paytm/Paytm-Logo.wine.svg" alt="Paytm" class="floating-logo">
      </div>
      
      <!-- PhonePe -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="50">
        <img src="https://upload.wikimedia.org/wikipedia/commons/7/71/PhonePe_Logo.svg" alt="PhonePe" class="floating-logo">
      </div>
      
      <!-- Google Pay -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="100">
        <img src="https://static.cdnlogo.com/logos/g/33/google-pay.svg" alt="Google Pay" class="floating-logo">
      </div>
      
      <!-- SBI -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="150">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/State_Bank_of_India.svg/1920px-State_Bank_of_India.svg.png" alt="SBI" class="floating-logo">
      </div>
      
      <!-- HDFC -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="200">
        <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8f/HDFC_Life_Logo.svg/800px-HDFC_Life_Logo.svg.png" alt="HDFC" class="floating-logo">
      </div>
      
      <!-- Freecharge -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="250">
        <img src="https://www.peakxv.com/wp-content/uploads/sites/2/2022/03/logo_freecharge.png" alt="Freecharge" class="floating-logo">
      </div>
      
      <!-- Mobikwik -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="300">
        <img src="https://brandlogos.net/wp-content/uploads/2023/11/mobikwik-logo_brandlogos.net_355pv.png" alt="Mobikwik" class="floating-logo">
      </div>
      
      <!-- BharatPe -->
      <div class="payment-logo" data-aos="fade-up" data-aos-delay="350">
        <img src="https://bharatpemoney.com/images/bharatpe-upi-logo-p-500.png" alt="BharatPe" class="floating-logo">
      </div>
    </div>
  </div>
</section>

<style>
/* Payment Logos Container */
.payment-logos-container {
  background: #f8f9fa;
  overflow: hidden;
  padding: 40px 0;
}

/* Grid Layout */
.payment-logos-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 30px;
  align-items: center;
  justify-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

/* Individual Logo Container */
.payment-logo {
  text-align: center;
  padding: 15px;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Logo Image Styles - Maintains Original Dimensions */
.payment-logo img {
  max-height: 60px; /* Only sets maximum, not fixed height */
  width: auto; /* Maintains original aspect ratio */
  max-width: 100%;
  filter: grayscale(100%);
  opacity: 0.8;
  transition: all 0.5s ease;
  object-fit: contain; /* Ensures proper scaling */
}

/* Floating Animation */
@keyframes gentleFloat {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}

/* Apply Animation to Logos */
.payment-logo img {
  animation: gentleFloat 4s ease-in-out infinite;
}

/* Staggered Animation Delays */
.payment-logo:nth-child(1) img { animation-delay: 0s; }
.payment-logo:nth-child(2) img { animation-delay: 0.5s; }
.payment-logo:nth-child(3) img { animation-delay: 1s; }
.payment-logo:nth-child(4) img { animation-delay: 1.5s; }
.payment-logo:nth-child(5) img { animation-delay: 2s; }
.payment-logo:nth-child(6) img { animation-delay: 2.5s; }
.payment-logo:nth-child(7) img { animation-delay: 3s; }
.payment-logo:nth-child(8) img { animation-delay: 3.5s; }

/* Hover Effects */
.payment-logo img:hover {
  animation: none;
  transform: translateY(0) scale(1.05);
  filter: grayscale(0%);
  opacity: 1;
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
  .payment-logos-grid {
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
  }
  
  .payment-logo img {
    max-height: 40px;
  }
  
  @keyframes gentleFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
  }
}
</style>
<!-- Testimonials Section -->
<section class="py-5 bg-light" id="testimonials">
  <div class="container py-5">
    <div class="section-title" data-aos="fade-up">
      <h2>What Our Customers Say</h2>
      <p class="text-muted">Trusted by thousands of businesses across India</p>
    </div>
    
    <div class="row">
      <div class="col-md-6" data-aos="fade-up">
        <div class="testimonial-card">
          <p>"Switching to CloudLinkd UPI was the best decision for our e-commerce store. Payment processing is now seamless and we've seen a 30% increase in successful transactions."</p>
          <div class="testimonial-author">
            <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Rahul Sharma">
            <div class="author-info">
              <h5>Rahul Sharma</h5>
              <p>CEO, FashionHub</p>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
        <div class="testimonial-card">
          <p>"The dashboard is incredibly intuitive and the support team is always responsive. We've reduced our payment processing costs by 40% since we started using this gateway."</p>
          <div class="testimonial-author">
            <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Priya Patel">
            <div class="author-info">
              <h5>Priya Patel</h5>
              <p>Founder, OrganicMart</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FAQ Section -->
<section class="py-5 bg-light" id="faq">
  <div class="container py-5">
    <div class="section-title" data-aos="fade-up">
      <h2>Frequently Asked Questions</h2>
      <p class="text-muted">Find quick answers to common queries</p>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="accordion" id="faqAccordion">
          
          <!-- Question 1 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                <i class="fas fa-question-circle text-primary me-2"></i>
                What payment methods does CloudLinkd UPI support?
              </button>
            </h3>
            <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                We support all major payment methods including UPI (Google Pay, PhonePe, Paytm, etc.), Net Banking (All major Indian banks), Credit/Debit Cards (Visa, Mastercard, Rupay), and popular wallets.
              </div>
            </div>
          </div>

          <!-- Question 2 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up" data-aos-delay="100">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                <i class="fas fa-question-circle text-primary me-2"></i>
                How long does it take to set up an account?
              </button>
            </h3>
            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Account activation is instant after registration. For full merchant capabilities including withdrawals, verification typically takes 1-2 business days after document submission.
              </div>
            </div>
          </div>

          <!-- Question 3 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                <i class="fas fa-question-circle text-primary me-2"></i>
                What are your transaction fees?
              </button>
            </h3>
            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                We offer competitive pricing starting at just 1.5% per transaction for UPI payments and 2.5% for credit/debit cards. High-volume merchants qualify for custom pricing with lower rates.
              </div>
            </div>
          </div>

          <!-- Question 4 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                <i class="fas fa-question-circle text-primary me-2"></i>
                How quickly are settlements processed?
              </button>
            </h3>
            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                We process settlements daily. UPI payments reflect in your account within T+1 days (next business day), while card payments take T+2 days. Weekend transactions are processed on Monday.
              </div>
            </div>
          </div>

          <!-- Question 5 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                <i class="fas fa-question-circle text-primary me-2"></i>
                Is there an API available for integration?
              </button>
            </h3>
            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Yes! We provide a robust REST API with comprehensive documentation. Our API supports payment collection, refunds, and transaction reporting. Developer-friendly SDKs are available for PHP, Node.js, Python and Java.
              </div>
            </div>
          </div>

          <!-- Question 6 -->
          <div class="accordion-item shadow-sm mb-3" data-aos="fade-up" data-aos-delay="500">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                <i class="fas fa-question-circle text-primary me-2"></i>
                What security measures are in place?
              </button>
            </h3>
            <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                We use bank-grade security including PCI-DSS compliance, 256-bit SSL encryption, two-factor authentication, and regular security audits. All transactions are tokenized and we never store sensitive card details on our servers.
              </div>
            </div>
          </div>

        </div>

        <div class="text-center mt-5" data-aos="fade-up">
          <p>Still have questions? <a href="#contact" class="text-primary fw-bold">Contact our support team</a></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-primary text-white">
  <div class="container py-5 text-center">
    <h2 class="mb-4" data-aos="fade-up">Ready to Transform Your Payment Experience?</h2>
    <p class="lead mb-5" data-aos="fade-up" data-aos-delay="100">Join thousands of businesses already using CloudLinkd UPI for seamless transactions</p>
    <div data-aos="fade-up" data-aos-delay="200">
      <a href="Register" class="btn btn-light btn-lg px-5 me-3">Get Started Free</a>
      <a href="#" class="btn btn-outline-light btn-lg px-5">Contact Sales</a>
    </div>
  </div>
</section>

<!-- Footer -->
<footer id="contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 mb-4 mb-lg-0">
        <h5><?php echo $site_settings['brand_name'];?></h5>
        <p>India's most trusted payment gateway solution for businesses of all sizes. Secure, fast, and reliable.</p>
        <div class="social-icons mt-4">
          <a href=""><i class="fab fa-telegram-plane"></i></a>
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
         
        </div>
      </div>
      
      <div class="col-lg-2 col-md-6 mb-4 mb-md-0">
        <h5>Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="#home">Home</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#how-it-works">How It Works</a></li>
          <li><a href="#testimonials">Testimonials</a></li>
          <li><a href="auth/index">Login</a></li>
        </ul>
      </div>
      
      <div class="col-lg-2 col-md-6 mb-4 mb-md-0">
        <h5>Resources</h5>
        <ul class="list-unstyled">
          <li><a href="#">Documentation</a></li>
          <li><a href="#">API Reference</a></li>
          <li><a href="#">Pricing</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#">Blog</a></li>
        </ul>
      </div>
      
      <div class="col-lg-4 col-md-6">
        <h5>Contact Us</h5>
        <ul class="list-unstyled">
          <li><i class="fas fa-map-marker-alt me-2"></i> MY Address</li>
          <li><i class="fas fa-phone me-2"></i> +91<?php echo $site_settings['whatsapp_number'];?></li>
          <li><i class="fas fa-envelope me-2"></i> <a href="" class="__cf_email__" data-cfemail="">[email&#160;protected]</a></li>
          <li><i class="fas fa-clock me-2"></i> Support: 24/7</li>
        </ul>
      </div>
    </div>
    
    <hr class="my-4 bg-secondary">
    
    <div class="row">
      <div class="col-md-6 text-center text-md-start">
        <p class="mb-0">Copyright &copy; 2025 <?php echo $site_settings['brand_name'];?>. All rights reserved.</p>
      </div>
      <div class="col-md-6 text-center text-md-end">
        <p class="mb-0">
          <a href="#" class="text-white me-3">Privacy Policy</a>
          <a href="#" class="text-white me-3">Terms of Service</a>
          <a href="#" class="text-white">Refund Policy</a>
        </p>
      </div>
    </div>
  </div>
</footer>
<!-- WhatsApp Chat Widget -->
<div class="whatsapp-chat">
  <a href="https://api.whatsapp.com/send?phone=+91<?php echo $site_settings['whatsapp_number'];?>&text=I_NEED_PG_FOR_1300" 
     target="_blank" 
     class="whatsapp-button">
    <i class="fab fa-whatsapp"></i>
  </a>
  <div class="whatsapp-tooltip">Need help? Chat with us!</div>
</div>

<style>
/* WhatsApp Chat Widget Styles */
.whatsapp-chat {
  position: fixed;
  left: 20px;
  bottom: 20px;
  z-index: 999;
}

.whatsapp-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  background-color: #25D366; /* WhatsApp brand color */
  color: white;
  border-radius: 50%;
  font-size: 30px;
  box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
  transition: all 0.3s ease;
  position: relative;
}

.whatsapp-button:hover {
  background-color: #128C7E; /* Darker WhatsApp color */
  transform: scale(1.1);
  box-shadow: 0 6px 16px rgba(37, 211, 102, 0.4);
}

.whatsapp-tooltip {
  position: absolute;
  left: 70px;
  bottom: 15px;
  background: white;
  padding: 8px 15px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.whatsapp-button:hover + .whatsapp-tooltip {
  opacity: 1;
  visibility: visible;
  left: 75px;
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
  .whatsapp-chat {
    left: 15px;
    bottom: 15px;
  }
  
  .whatsapp-button {
    width: 50px;
    height: 50px;
    font-size: 25px;
  }
}
</style>

<!-- Scripts -->
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  // Initialize AOS animation
  AOS.init({
    duration: 800,
    easing: 'ease-in-out',
    once: true
  });
  
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
</script>
<a href="#" class="scroll-to-top" id="scrollToTop">
  <i class="fas fa-arrow-up"></i>
</a>

<style>
/* Scroll to Top Button */
.scroll-to-top {
  position: fixed;
  bottom: -60px; /* Start hidden below viewport */
  right: 30px;
  width: 50px;
  height: 50px;
  background-color: #28a745; /* Your brand green */
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  text-decoration: none;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
  z-index: 999;
  opacity: 0;
}

.scroll-to-top.visible {
  bottom: 30px; /* Show 30px from bottom */
  opacity: 1;
}

.scroll-to-top:hover {
  background-color: #218838; /* Darker green on hover */
  transform: translateY(-3px);
}
</style>

<script>
window.addEventListener('scroll', function() {
  const scrollToTop = document.getElementById('scrollToTop');
  const footer = document.querySelector('footer');
  const footerTop = footer.getBoundingClientRect().top;
  const windowHeight = window.innerHeight;
  
  // Show button when footer enters viewport (top of footer reaches bottom of viewport)
  if (footerTop <= windowHeight) {
    scrollToTop.classList.add('visible');
  } else {
    scrollToTop.classList.remove('visible');
  }
});

// Smooth scroll to top
document.getElementById('scrollToTop').addEventListener('click', function(e) {
  e.preventDefault();
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});
</script>
</script>
</body>
</html>