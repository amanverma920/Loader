<?php
include "header.php";
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}
function sanitize_input($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, "UTF-8");
}

if (isset($_POST["create"])) {
    $name = sanitize_input($_POST["name"]);
    $mobile = sanitize_input($_POST["mobile"]);
    $remark = sanitize_input($_POST["remark"]);
    $amount = sanitize_input($_POST["amount"]);

    if (empty($remark)) {
        $remark = "PAYMENT_LINK";
    }

    $orderid = "TXN".mt_rand(10000000000, 9999999999999);

    $data = [
        "customer_mobile" => $mobile,
        "user_token" => $userdata["user_token"],
        "amount" => $amount,
        "order_id" => $orderid,
        "redirect_url" => $root . "success",
        "remark1" => $remark,"customer_name" => $name,
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $root . "api/create-order",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => http_build_query($data),
        CURLOPT_HTTPHEADER => ["User-Agent: Apidog/1.0.0 (https://apidog.com)"],
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    $jsondatares = json_decode($response, true);

    if ($jsondatares["status"] == true) {
        $paymentlink = $jsondatares["result"]["payment_url"];
        
    } else {
        echo "Error creating payment link.";
    }
}
?>

 
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>


<?php 
if(isset($paymentlink)){
    
    echo '
    <!-- Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="paymentModalLabel">Payment Link</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>Click below to proceed with your payment:</p>
            <a href="'.$paymentlink.'" id="paymentLink" class="" target="_blank">'.$paymentlink.'</a>
          </div>
        </div>
      </div>
    </div>

    <script>
      document.addEventListener("DOMContentLoaded", function() {
        var myModal = new bootstrap.Modal(document.getElementById("paymentModal"));
        myModal.show();
      });
    </script>
    ';
}

?>


     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>PAYMENT LINKS</h4>
               <div class="bg-white mt-3 p-4">
                <h6 class="mb-3">Create Payment Links</h6>
                  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row">
                     <div class="mb-3 col-12 col-md-3 d-flex flex-column">
                        <label for="">Name</label>
                        <input type="text" name="name" class="form-control mt-2" placeholder="Name">
                     </div>
                     <div class="mb-3 col-12 col-md-3 d-flex flex-column">
                        <label for="">Amount</label>
                        <input type="number" name="amount" required class="form-control mt-2" placeholder="0.0">
                     </div>
                     <div class="mb-3 col-12 col-md-3 d-flex flex-column">
                        <label for="">Remark</label>
                        <input type="text" name="remark" class="form-control mt-2" placeholder="Remarks">
                     </div>
                     <div class="mb-3 col-12 col-md-3 d-flex flex-column">
                        <label for="">Mobile Number</label>
                        <input type="number" name="mobile" class="form-control mt-2" placeholder="Number">
                     </div>
                     <div class="col d-flex justify-content-end flex-column">
                        <button class="btn btn-success mt-2" type="submit" name="create">Create Link</button>
                     </div>
                  </form>
                  <div class="mt-4">
                     <h6>Payment Links</h6>
                    <?php
$query = "SELECT * FROM `orders` WHERE user_id='{$userdata["id"]}' ORDER BY `id` DESC";
$query_run = mysqli_query($conn, $query);

if ($query_run) {
    $orders = mysqli_fetch_all($query_run, MYSQLI_ASSOC);
} else {
    echo "Error in query: " . mysqli_error($conn);
}
?> <div class="overflow-auto">
<table class="table table-sm table-hover table-bordered table-head-bg-primary" id="datatable" width="100%">
    <thead>
        <tr>
            <th>#</th>
            <th>Customer Mobile</th>
            <th>Amount</th>
            <th>Order id</th>
            <th>Status</th>
            <th>Remarks</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($orders as $row): ?>
            <?php $st =
                $row["status"] == "SUCCESS"
                    ? '<span class="badge text-bg-success">Success</span>'
                    : ($row["status"] == "FAILURE"
                        ? '<span class="badge text-bg-danger">Failed</span>'
                        : '<span class="badge text-bg-warning">Pending</span>'); ?>
            <tr>
                <td><?php echo $row["id"]; ?></td>
                <td><?php echo $row["customer_mobile"]; ?></td>
                <td><?php echo $row["amount"]; ?></td>
                <td><?php echo $row["order_id"]; ?></td>
                <td><?php echo $st; ?></td>
                <td><?php echo $row["remark1"]; ?></td>
                <td><?php echo $row["create_date"]; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table></div>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <?php include "common_files/footer.php";?>
      
   </body>
</html>