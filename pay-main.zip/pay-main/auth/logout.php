<!DOCTYPE html>
<html>
<head>
    <!-- Include the SweetAlert CDN link -->
    <?php include "common_files/head.php";?>
</head>
<body>

<?php
include "config.php";
session_start();
session_destroy();

 echo '
    <script>
        Swal.fire({
            title: "Logout Successfull!!",
            text: "You are free to login any time you want :)",
            confirmButtonText: "Ok",
            icon: "success" 
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "index"; // Replace with your desired redirect URL
            }
        });
    </script>
';

?>
</body>
</html>