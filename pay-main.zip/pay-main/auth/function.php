<?php

include "config.php";

$query = "SELECT * FROM site_settings LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $site_settings = mysqli_fetch_assoc($result);
} else {

    $site_settings = []; 

    echo "Error: No site settings found.";
}

$query = "SELECT * FROM api_settings LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $api_settings = mysqli_fetch_assoc($result);

    $host = $api_settings["host"];
    $pass = $api_settings["pass"];
    $sender_email = $api_settings["sender_email"];
} else {
    die("Error: No API settings found."); 
}

?>