
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
 <script type="text/javascript" src="assets/js/app.js?"></script>
<script type="text/javascript" src="assets/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script type="text/javascript">
   /* $(document).ready(function() {
        $("#datatable").DataTable({
        destroy: true,
        responsive: true,
        order: [
            [1, "asc"]
        ],
        pageLength: 10,
        columnDefs: [{
                targets: 0,
                orderable: false,
                width: "18px"
            },
            {
                //targets: 6,
                orderable: false
            }
        ],
        layout: {
            topStart: null,
            topEnd: null,
            bottomStart: 'info',
            bottomEnd: 'paging'
        }
    });
    });*/
        
</script>
