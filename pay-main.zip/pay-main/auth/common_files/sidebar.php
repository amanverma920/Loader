<div class="col sidebar shadow-sm p-0 m-0 d-none-">
      <div class="side-head d-flex  align-items-center justify-content-center">
         <img src="<?php echo $site_settings["logo_url"];?>" alt="" class="logo">
      </div>
      <div class="side">
         <ul class="side-options px-0">
            <li><a href="dashboard"><i class="fi fi-rr-house-chimney"></i> Dashboard</a></li>
            <?php  if($userdata['role']=="Admin"){
               echo '<li class="small-text">ADMIN MANAGEMENT</li>
            <li><a href="sitesetting"><i class="fi fi-rr-document-gear"></i> Manage Website</a></li>
            <li><a href="add_api"><i class="fi fi-rr-envelope"></i> Mail Setup</a></li>
            <li><a href="manage_subscription"><i class="fi fi-rr-subscription"></i> Manage Subscription</a></li>
            <li><a href="add_merchant"><i class="fi fi-rr-user-add"></i> Create New User</a></li>
            <li><a href="merchant_list"><i class="fi fi-rr-list-check"></i> User List</a></li>';
            };?>
            
            <li class="small-text">MERCHANT SETTINGS</li>
            <li><a href="connect_merchant"><i class="fi fi-rr-plug-connection"></i> Connect Merchant</a></li>
            <li><a href="payment_link"><i class="fi fi-rr-broken-chain-link-wrong"></i> Payment Links</a></li>
            <li><a href="transactions"><i class="fi fi-rr-time-past"></i> Transaction History</a></li>
            <li><a href="gpay-transactions"><i class="fi fi-rr-time-past"></i> Gpay Pending Transactions</a></li>
            <li><a href="subscription"><i class="fi fi-rr-subscription"></i> Subscription</a></li>
            <li class="small-text">ACCOUNT SETTINGS</li>
            <li><a href="profile"><i class="fi fi-rr-user-skill-gear"></i> Manage Profile</a></li>
            <li><a href="change_password"><i class="fi fi-rr-lock"></i> Change Password</a></li>
            <li><a href="apidetails"><i class="fi fi-rr-code-compare"></i> Api Details</a></li>
            <li><a href="simple_code"><i class="fi fi-rr-square-terminal"></i> Sample Code</a></li>
         </ul>
      </div>
   </div>