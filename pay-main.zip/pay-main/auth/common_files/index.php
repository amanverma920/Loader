<!DOCTYPE html>
<html>
   <head>
      <?php include 'head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>
      <div class="container-fluid row p-0 m-0">
         <?php include "sidebar.php";?>
         <div class="col p-0">
            <?php include "header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>MERCHANT SETTINGS</h4>
               <div class="bg-white mt-3 p-4">
                  <form action="#" class="row">
                     <div class="col d-flex flex-column">
                        <label for="">Merchant Name</label>
                        <select name="" id="" class="form-control mt-2">
                           <option value="">--SELECT MERCHANT--</option>
                        </select>
                     </div>
                     <div class="col d-flex flex-column">
                        <label for="">Merchant Number</label>
                        <input type="number" class="form-control mt-2" placeholder="Number">
                     </div>
                     <div class="col d-flex justify-content-end flex-column">
                        <button class="btn btn-success mt-2">Add Merchant</button>
                     </div>
                  </form>
                  <div class="mt-4">
                     <h6>Connected Mercahnts</h6>
                     <table class="table mt-3 table-striped table-bordered">
                        <thead>
                           <tr>
                              <th scope="col">#ID</th>
                              <th scope="col">MERCHANT NAME</th>
                              <th scope="col">PHONE NUMBER</th>
                              <th scope="col">ADDEDED ON</th>
                              <th scope="col">STATUS</th>
                              <th scope="col">
                                 Verify
                              </th>
                              <th scope="col">Delete</th>
                           </tr>
                           <tr>
                              <td>1</td>
                              <td>Phonepe</td>
                              <td>9999999999</td>
                              <td><span class="badge rounded-pill text-bg-primary">23/33/2234</span></td>
                              <td><span class="badge rounded-pill text-bg-success">Active</span></td>
                              <td><button class="btn btn-primary">Verify</button></td>
                              <td><button class="btn btn-danger">Delete</button></td>
                           </tr>
                        </thead>
                        <tbody>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <script type="text/javascript" src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/2.2.2/js/dataTables.bootstrap5.min.js"></script>
      <script type="text/javascript" src="assets/js/app.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      <script>
         new DataTable('#example');
      </script>
   </body>
</html>