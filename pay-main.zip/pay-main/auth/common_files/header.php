<div class="header shadow-sm row container-fluid m-0">
   <!-- Left section for mobile (Logo and left nav) -->
   <div class="col d-flex align-items-center d-md-none toogle-side">
      <div class="btn btn-primary cursor-pointer d-flex align-items-center justify-content-center"><i class="fi fi-rr-tally-3"></i></div>
   </div>

   <!-- Logo and center section (visible on all screen sizes) -->
  <div class="col d-flex align-items-center justify-content-center d-md-none">
   <div class="side-head d-flex align-items-center justify-content-center">
      <img src="<?php echo $site_settings["logo_url"];?>" alt="" class="logo">
   </div>
</div>

<div class="col d-none d-md-flex align-items-center justify-content-end">
      <!-- Search form for desktop -->
      <form action="" class="container-fluid">
         <input type="text" placeholder="Search..." class="form-control">
      </form>
   </div>
   <!-- Right section for mobile: Admin profile and dropdown -->
   <div class="col d-flex align-items-center justify-content-end">
      <div class="dropdown">
         <button class="btn btn-light dropdown-toggle " type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo $userdata["name"];?>
         </button>
         <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="profile">Profile</a></li>
            <li><a class="dropdown-item" href="change_password">Change Password</a></li>
            <li><a class="dropdown-item" href="logout">Logout</a></li>
         </ul>
      </div>
   </div>

   <!-- Search form and right admin dropdown (only visible on desktop) -->
   
</div>
