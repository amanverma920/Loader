

<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Site Settings</title>
   </head>
   <body>
<?php
include "header.php"; // Include your header file
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}

// Initialize variables
$whatsapp_api_url = '';
$sender_id = '';
$api_key = '';
$sender_email = '';

if($userdata["role"] != 'Admin'){
   echo '<script>
 window.location.href = "dashboard";
</script>';

    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Capture the POST data
$host = $_POST['host'];
$pass = $_POST['pass'];
$sender_email = $_POST['sender_email'];

// Check if settings already exist
$query = "SELECT * FROM api_settings LIMIT 1"; // Get any existing setting
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
// If settings exist, update them
$settings = $result->fetch_assoc();
$id = $settings['id'];

// Prepare the update statement
$update_query = "UPDATE api_settings SET host = ?,  pass = ?, sender_email = ? WHERE id = ?";
$update_stmt = $conn->prepare($update_query);
$update_stmt->bind_param("sssi", $host, $pass, $sender_email, $id);

if ($update_stmt->execute()) {
// Success message
echo "<script>
Swal.fire({
title: 'Success!',
text: 'API settings updated successfully!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
} else {
// Error during update
echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error updating settings: " . addslashes($update_stmt->error) . "',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
}

$update_stmt->close(); // Close the update statement
} else {
// If no settings exist, insert new ones
$insert_query = "INSERT INTO api_settings (whatsapp_api_url, sender_id, api_key, sender_email) VALUES (?, ?, ?, ?)";
$insert_stmt = $conn->prepare($insert_query);
$insert_stmt->bind_param("ssss", $whatsapp_api_url, $sender_id, $api_key, $sender_email);

if ($insert_stmt->execute()) {
// Success message for insert
echo "<script>
Swal.fire({
title: 'Success!',
text: 'API settings added successfully!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
} else {
// Error during insert
echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error adding settings: " . addslashes($insert_stmt->error) . "',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
}

$insert_stmt->close(); // Close the insert statement
}
}

// Fetch current API settings to display in the form if they exist
$query = "SELECT * FROM api_settings LIMIT 1"; // Get any existing setting
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
$settings = $result->fetch_assoc();
$host = $settings['host'];
$pass = $settings['pass'];

$sender_email = $settings['sender_email'];
} else {
// No settings found, set default values
$whatsapp_api_url = '';
$sender_id = '';
$api_key = '';
$sender_email = '';
}

$stmt->close(); // Close the statement
?>





     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>SMTP Mail Setup</h4>
               <div class="bg-white mt-3 p-4">
                
                  <div class="mt-0">
                    
                      <form method="POST" action="add_api.php">
                        <div class="row">
                        <!-- <div class="mb-3 col-12 col-md-6">
                        <label for="MID" class="form-label">Api Key</label>
                        <input type="text" name="api_key" value="<?php echo htmlspecialchars($api_key); ?>" class="form-control" required>
                        </div> -->
                        <div class="mb-3 col-12 col-md-6">
                        <label for="MID" class="form-label">Sender Email</label>
                        <input type="email" name="sender_email" value="<?php echo htmlspecialchars($sender_email); ?>" class="form-control" required>
                        </div>
                        <div class="row">
                        <div class="mb-3 col-12 col-md-6">
                        <label for="MID" class="form-label">Email Host</label>
                        <input type="text" name="host" value="<?php echo htmlspecialchars($host); ?>" class="form-control" required>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                        <label for="MID" class="form-label">Email Password</label>
                        <input type="text" name="pass" value="<?php echo htmlspecialchars($pass); ?>" class="form-control" required>
                        </div>
                        </div>
                        
                        </div>
                        <div class="row">
                        
                        <div class="mb-1 col">
                        <button type="submit" name="submit" class="btn btn-success">Save Changes</button>
                        </div>
                        </div>
                      </form>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
  <?php include "common_files/footer.php";?>
      
   </body>
</html>