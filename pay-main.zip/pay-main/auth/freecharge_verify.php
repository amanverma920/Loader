<!DOCTYPE html>
<html>
   <head>
      <?php
      include "header.php";

      include "common_files/head.php";
      ?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body><?php
   define("cxrpaysecureheader", true);
   define("ABSPATH", dirname(__FILE__) . "/"); 

   require_once ABSPATH . "header.php";
   ?>


<?php // Verify CSRF token
if ($_SERVER["REQUEST_METHOD"] === "POST") {
     $cookie = $_POST["cookie"];
     $upi = $_POST["upi"];
     $no = filter_var($_REQUEST["number"], FILTER_VALIDATE_INT);
   



        

   
            
            $query = "UPDATE freecharge_token SET app_fc='$cookie', Upiid='$upi', status='Active' WHERE phoneNumber='$no'";
            $result = mysqli_query($conn, $query);
            
            if ($result && mysqli_affected_rows($conn) > 0) {
                $ssid = $_SESSION["user_id"];
                $sqlwbb4 = "UPDATE users SET freecharge_connected='Yes' WHERE id='$ssid'";
                $rodrtny = mysqli_query($conn, $sqlwbb4);

               

                            echo '<script src="js/jquery-3.2.1.min.js"></script>';
                            echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
                            echo '<script>$("#loading_ajax").hide();
                            Swal.fire({
                            icon: "success",
                            title: "Congratulations! Your FreechargeHasbeen Connected Successfully!",
                            showConfirmButton: true, // Show the confirm button
                            confirmButtonText: "Ok!", // Set text for the confirm button
                            allowOutsideClick: false, // Prevent the user from closing the popup by clicking outside
                            allowEscapeKey: false // Prevent the user from closing the popup by pressing Escape key
                            }).then((result) => {
                            if (result.isConfirmed) {
                            window.location.href = "dashboard"; // Redirect to "dashboard" when the user clicks the confirm button
                            }
                            });
                            </script>';
            } else {
                // Show SweetAlert2 error message

                $error = mysqli_error($conn); // Get the MySQL error message
                $error = "Failed!";
                            echo '<script src="js/jquery-3.2.1.min.js"></script>';
                            echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
                            echo '<script>$("#loading_ajax").hide();
                            Swal.fire({
                            icon: "error",
                            title: "Error",
                            text: "Failed to update the database. Error: ' .
                            $error .
                            '",
                            showConfirmButton: true,
                            confirmButtonText: "Ok",
                            allowOutsideClick: false,
                            allowEscapeKey: false
                            });
                            </script>';
            }
         
      

    }

?>

</body>
</html>