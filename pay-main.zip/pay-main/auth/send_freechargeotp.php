<!DOCTYPE html>
<html>
   <head>
      <?php include 'header.php';

       include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body><?php
define('cxrpaysecureheader', true);

define('ABSPATH', dirname(__FILE__) . '/'); 

require_once(ABSPATH . 'header.php');

?>

<?php
if(isset($_POST['Verify'])){ 
$mobileNumber = filter_var($_REQUEST['freecharge_mobile'], FILTER_VALIDATE_INT);
    if ($userdata['freecharge_connected']=="Yes"){

        echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
            Swal.fire({
                icon: "error",
                title: "Merchant Already Connected !!",
                showConfirmButton: true, 
                confirmButtonText: "Ok!", 
                allowOutsideClick: false, 
                allowEscapeKey: false 
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "connect_merchant"; 
                }
            });
        </script>';
        exit();
    }



    if (true) {

     
                        echo '<div class="container d-flex justify-content-center align-items-center vh-100">
   <form id="paytmForm" method="POST" action="freecharge_verify" class="w-100" style="max-width: 500px;">
      <div class="card p-4">
         <h5 class="text-center mb-4">VERIFY FREECHARGE MERCHANT</h5>
        
         <input type="hidden" name="number" value="' . $mobileNumber . '">
          <input type="hidden" name="user_token" value="' . $userdata['user_token'] . '">
            <div class="col-md-12 mb-3">
            <label for="OTP"  class="form-label">Enter Freecharge app_fc Cookie</label>
            <input type="text" name="cookie" id="cookie" placeholder="Enter Cookie" class="form-control" required>
            </div>
            <div class="col-md-12 mb-3">
            <label for="OTP"  class="form-label">Enter Freecharge UPI ID</label>
            <input type="text" name="upi" id="upi" placeholder="Enter UPI ID" class="form-control" required>
            </div>
         <div class="d-grid mt-1">
            <button type="submit" name="verifyotp" class="btn btn-success">Verify Paytm</button>
         </div>
      </div>
   </form>
</div>';
    } else {

        echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
            Swal.fire({
                icon: "error",
                title: "' . $errorMessage . '!",
                showConfirmButton: true, 
                confirmButtonText: "Ok!", 
                allowOutsideClick: false, 
                allowEscapeKey: false 
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "connect_merchant"; 
                }
            });
        </script>';
        exit();
    }
} 

else{

echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
    Swal.fire({
        icon: "error",
        title: "Form Not Submitted!!",
        showConfirmButton: true, 
        confirmButtonText: "Ok!", 
        allowOutsideClick: false, 
        allowEscapeKey: false 
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "connect_merchant"; 
        }
    });
</script>';
exit;
}
?>

</body>
</html>