<?php include "header.php";if(!isset($_SESSION["user_id"])){
    header('Location:../');
} ?>

 
                    <!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Site Settings</title>
   </head>
   <body>
      <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>TRANSACTION HISTORY</h4>
               <div class="bg-white mt-3 p-4">
                  <div class="mt-0"><div class="overflow-auto">
                                            <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                <th>#</th>
                                                <th>Mobile</th>
                                                <th>Date Time</th>
                                                <th>Merchant</th>
                                                <th>Gateway Txn</th>
                                                <th>Bank RRN</th>
                                                <th>Order ID</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
<?php
if($userdata['role'] == 'User'){
$token = $userdata['user_token'];


$query = "SELECT `id`, `create_date`, `gateway_txn`, `customer_mobile`, `method`, `utr`, `byteTransactionId`, `order_id`, `amount`, `status` FROM `orders` WHERE user_token = '$token' ORDER BY `create_date` DESC";
$query_run = mysqli_query($conn, $query);


if ($query_run) {
    while ($row = mysqli_fetch_assoc($query_run)) {
        
      
        
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "</td>";
echo "<td>" . htmlspecialchars($row['customer_mobile'], ENT_QUOTES, 'UTF-8') . "</td>";
echo "<td>" . htmlspecialchars($row['create_date'], ENT_QUOTES, 'UTF-8') . "</td>";

        ?>
        <td><?php echo htmlspecialchars($row['method']); ?></td>
        <?php
        echo "<td>" . htmlspecialchars($row['gateway_txn'], ENT_QUOTES, 'UTF-8') . "</td>";
        ?>
        <?php
        echo "<td>" . htmlspecialchars($row['utr'], ENT_QUOTES, 'UTF-8') . "</td>";
echo "<td>" . htmlspecialchars($row['order_id'], ENT_QUOTES, 'UTF-8') . "</td>";
echo "<td>₹" . htmlspecialchars($row['amount'], ENT_QUOTES, 'UTF-8') . "</td>";


        //$sts = $row['status'];
        if($row['status']=="SUCCESS"){
            $sts = 'Success';
            $cls = "badge badge-success";
        }else{
            $sts = 'Pending';
            $cls = "badge badge-warning";
        }
        echo "<td><button class='$cls'>" . $sts . "</button></td>";
        echo "</tr>";
    }
} else {
    echo "Error in query: ";
    //echo "Error in query: " . mysqli_error($conn); 
}
}

//admin ke lie echo 

else{
    $token = $userdata['user_token'];


$query = "SELECT * FROM `orders` ORDER BY id DESC";
$query_run = mysqli_query($conn, $query);

if ($query_run) {
    while ($row = mysqli_fetch_assoc($query_run)) {
        
      
        
        echo "<tr>";
       echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "</td>";
       echo "<td>" . htmlspecialchars($row['customer_mobile'], ENT_QUOTES, 'UTF-8') . "</td>";
       echo "<td>" . htmlspecialchars($row['create_date'], ENT_QUOTES, 'UTF-8') . "</td>";

        ?>
        <td><?php echo htmlspecialchars($row['method']); ?></td>
        <?php
        echo "<td>" . htmlspecialchars($row['gateway_txn'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['utr'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>" . htmlspecialchars($row['order_id'], ENT_QUOTES, 'UTF-8') . "</td>";
        echo "<td>₹" . htmlspecialchars($row['amount'], ENT_QUOTES, 'UTF-8') . "</td>";

        //$sts = $row['status'];
        if($row['status']=='SUCCESS'){
            $sts = 'Success';
            $cls = "btn btn-success";
        }else{
            $sts = 'Pending';
            $cls = "btn btn-warning";
        }
        echo "<td><button class='$cls'>" . $sts . "</button></td>";
        echo "</tr>";
    }
} else {
    echo "Error in query: ";
    //echo "Error in query: " . mysqli_error($conn); 
}
}
?>
                                            
                                        </tbody>
                        </table></div>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
  <?php include "common_files/footer.php";?>
   </body>
</html>