
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Site Settings</title>
   </head>
   <body>

<?php
// Enable error reporting for debugging
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

// Start output buffering to prevent premature output
ob_start();

include "header.php";
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}
include "config.php"; // Assuming config.php contains the database connection

// Initialize message variable
$message = "";

// Fetch existing settings from the database
$query = "SELECT * FROM site_settings LIMIT 1";
$result = mysqli_query($conn, $query);
$settings = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $brand_name = $_POST['brand_name'];
    $logo_url = $_POST['logo_url'];
    $site_link = $_POST['site_link'];
    $whatsapp_number = $_POST['whatsapp_number'];
    $copyright_text = $_POST['copyright_text'];

    if ($settings) {
        // Update existing record
        $update_query = "UPDATE site_settings SET brand_name='$brand_name', logo_url='$logo_url', site_link='$site_link', whatsapp_number='$whatsapp_number', copyright_text='$copyright_text' WHERE id=".$settings['id'];
        if (mysqli_query($conn, $update_query)) {
            echo "<script>
Swal.fire({
title: 'Success!',
text: 'Settings Updated!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
        } else {
            echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error Occured!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        }
    } else {
        // Insert new record
        $insert_query = "INSERT INTO site_settings (brand_name, logo_url, site_link, whatsapp_number, copyright_text) VALUES ('$brand_name', '$logo_url', '$site_link', '$whatsapp_number', '$copyright_text')";
        if (mysqli_query($conn, $insert_query)) {
               echo "<script>
Swal.fire({
title: 'Success!',
text: 'Settings Updated!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
        } else {
               echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error Occured!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        }
    }

    // Redirect after form submission
    //header("Location: sitesetting.php?message=" . urlencode($message));
    //exit();
}

if($userdata["role"] != 'Admin'){
   echo '<script>
 window.location.href = "dashboard";
</script>';

    exit;
}


// End output buffering and flush output
ob_end_flush();
?>
<?php if($userdata["role"] != 'Admin'){ exit; }?>



     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>WEBSITE SETTINGS</h4>
               <div class="bg-white mt-3 p-4">
                
                  <div class="mt-0">
                    
                      <form method="POST" action="sitesetting.php">
    <div class="row">
        <div class="mb-3 col-12 col-md-6">
            <label for="MID" class="form-label">Website Name</label>
            <input type="text" name="brand_name" id="MID" placeholder="Website Name" class="form-control" required value="<?php echo $site_settings["brand_name"]; ?>">
        </div>
        <div class="mb-3 col-12 col-md-6">
            <label for="MID" class="form-label">Logo URL</label>
            <input type="text" name="logo_url" id="MID" placeholder="Logo URL" class="form-control" required value="<?php echo $site_settings["logo_url"]; ?>">
        </div>
    </div>
    <div class="row">
        <div class="mb-3 col-12 col-md-6">
            <label for="MID" class="form-label">Website Link</label>
            <input type="text" name="site_link" id="MID" placeholder="Website Link" class="form-control" required value="<?php echo $site_settings["site_link"]; ?>">
        </div>
        <div class="mb-3 col-12 col-md-6">
            <label for="MID" class="form-label">Whatsapp Number</label>
            <input type="text" name="whatsapp_number" id="MID" placeholder="Whatsapp Number" class="form-control" required value="<?php echo $site_settings["whatsapp_number"]; ?>">
        </div>
    </div>
    <div class="row">
        <div class="mb-3 col-12 col-md-6">
            <label for="MID" class="form-label">Copyright Text</label>
            <input type="text" name="copyright_text" id="MID" placeholder="Copyright Text" class="form-control" required value="<?php echo $site_settings["copyright_text"]; ?>">
        </div>
        <div class="mb-3 col-12 col-md-6 d-flex justify-content-end flex-column">
            <button type="submit" name="submit" class="btn btn-success">Save Changes</button>
        </div>
    </div>
</form>

                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
    <?php include "common_files/footer.php";?>
   </body>
</html>