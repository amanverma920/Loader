<?php include "header.php"; ?>

<?php 
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}
$query = $conn->query("SELECT * FROM `subscription_plan`");

if($userdata["role"] != 'Admin'){
   echo '<script>
 window.location.href = "dashboard";
</script>';

    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updatesub"])) {

$srno = $_POST['srno'];
$planname = $_POST['plan_name'];
$amount = $_POST['amount'];
$expiry = $_POST['expiry'];

$update_query = "UPDATE subscription_plan SET plan_name = ?, amount = ?, expiry = ? WHERE id = ?";
$update_stmt = $conn->prepare($update_query);
$update_stmt->bind_param("sssi", $planname, $amount, $expiry, $srno);

if ($update_stmt->execute()) {

echo "<script>
Swal.fire({
title: 'Success!',
text: 'Subscription updated successfully!',
icon: 'success',
confirmButtonText: 'OK'
}).then(() => {
    window.location.href = 'manage_subscription';
});
  </script>";

} else {

echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error updating Subscription',
icon: 'error',
confirmButtonText: 'OK'
}).then(() => {
    window.location.href = 'manage_subscription';
});
  </script>";
}

$update_stmt->close(); 

}

?>
          

                    
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>


.pricing .card {
    border: none;
    border-radius: 0rem;
    transition: all 0.2s;
    box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
}

.pricing hr {
    margin: 1.5rem 0;
}

.pricing .card-title {
    margin: 0.5rem 0;
    font-size: 0.9rem;
    letter-spacing: .1rem;
    font-weight: bold;
}

.pricing .card-price {
    font-size: 3rem;
    margin: 0;
}

.pricing .card-price .period {
    font-size: 0.8rem;
}

.pricing ul li {
    margin-bottom: 1rem;
}

.pricing . {
    opacity: 0.7;
}


/* Hover Effects on Card */

@media (min-width: 992px) {
    .pricing .card:hover {
        margin-top: -.25rem;
        margin-bottom: .25rem;
    }

    .pricing .card:hover .btn {
        opacity: 1;
    }
}
      </style>
      <title>Home</title>
   </head>
   <body>





     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>MANAGE SUBSCRIPTION</h4>
               <div class=" mt-0 p-4">
                
                  <div class="mt-0">

                  <?php 
                    if(isset($_GET["srno"]) && $_GET["srno"] != ''){

                    $fetchdata = $conn->query("SELECT * FROM `subscription_plan` WHERE id = '{$_GET["srno"]}'")->fetch_assoc();
                    echo '<div class="row p-4 bg-white">
                             <form method="POST" action="">
                            <input type="hidden" name="srno" value="'. htmlspecialchars($fetchdata["id"]).'" class="form-control" required>
                            <div class="row">
                            <div class="col-md-6 mb-3">
                            <label class="form-label">Plan Name</label>
                            <input type="text" name="plan_name" value="'.htmlspecialchars($fetchdata["plan_name"]).'" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                            <label class="form-label">Amount</label>
                            <input type="text" name="amount" value="'. htmlspecialchars($fetchdata["amount"]).'" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                            <label class="form-label">Expiry Month</label>
                            <input type="text" name="expiry" value="'. htmlspecialchars($fetchdata["expiry"]).'" class="form-control" required>
                            </div>
                            <div class="col-md-12 mb-3">
                            <button type="submit" name="updatesub" class="btn btn-primary">Save Changes</button>
                            </div>
                            </div>
                            </form>                             
                            </div>';exit;
                        }
                    ?>
                                
<section class="pricing">
    <div class="container">
        <div class="row">
                                <?php
                    $query=$conn->query("SELECT * FROM `subscription_plan`"); 
while($row = $query->fetch_assoc()) {
   // echo "1 " . $row["plan_name"] . "<br>";
    echo '<div class="col-lg-4">
                <div class="card mb-5 mb-lg-0">
                    <div class="card-body">
                        <h5 class="card-title  text-uppercase text-center">'.$row["plan_name"].'</h5>
                        <h6 class="card-price text-center">$'.$row["amount"].'<span class="period"> /'.$row["expiry"].' month</span></h6>
                        <hr>
                        <ul class="fa-ul">
                            <li><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>0 Transaction Fee</p></li>
                            <li><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>Realtime Transaction</p></li>
                            <li><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>No Amount Limit</p></li>
                            <li><span class="fa-li"><i class="fi fi-rr-check"></i></span><p style="color:red;">HDFC Vyapar</p></li>
                            <li class=""><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>Dynamic QR Code</p></li>
                            <li class=""><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>Direct UPI Intent</p></li>
                            <li class=""><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>Accept All UPI Apps</p></li>
                            <li class=""><span class="fa-li"><i class="fi fi-rr-check"></i></span><p>24*7 WhatsApp Support</p></li>
                        </ul>
                        <button onclick="window.location.href = \'manage_subscription?srno='.$row["id"].'\'" class="btn btn-outline-success w-100  mt-2 updatesubbtn">Edit</button>
                    </div>
                </div>
            </div>';
}
?>
            
            
           
        </div>
    </div>
</section>





                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
 <?php include "common_files/footer.php";?>
      
   </body>
</html>