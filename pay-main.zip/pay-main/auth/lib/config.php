<?php
include "../config.php";

 $user = "SELECT mobile,user_token FROM users WHERE role = 'Admin'";
$uu = mysqli_query($conn, $user);
$userdata = mysqli_fetch_array($uu);
 $token=$userdata["user_token"];
 $mobile=$userdata["mobile"];
?>