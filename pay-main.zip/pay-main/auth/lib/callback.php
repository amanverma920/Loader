<?php
require_once "../config.php";
require_once "../header.php";
require_once "config.php";

$orderid = $_COOKIE["order_id_cookie"];
$url = $root . "api/check-order-status";
$postData = [
    "user_token" => $token,
    "order_id" => $orderid,
];
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
    exit();
}

curl_close($ch);

$responseData = json_decode($response, true);
//print_r($responseData);
if ($responseData["status"] == 1) {
    $txnStatus = $responseData["result"]["txnStatus"];
    $orderId = $responseData["result"]["orderId"];
    $status = $responseData["result"]["status"];
    $amount = $responseData["result"]["amount"];
    $date = $responseData["result"]["date"];
    $utr = $responseData["result"]["utr"];

    $planid = $_COOKIE["planid_cookie"];
    $email = $_SESSION["username"];

    if ($planid == 1) {
        $monthsToAdd = 1;
    } elseif ($planid == 2) {
        $monthsToAdd = 6;
    } elseif ($planid == 3) {
        $monthsToAdd = 12;
    }  else {
        $monthsToAdd = 0;
    }

    $sql = "UPDATE users SET expiry = DATE_ADD(expiry, INTERVAL $monthsToAdd MONTH) WHERE mobile = '$email'";
    $rrrr = mysqli_query($conn, $sql);

    if ($rrrr) {
        header("Location: " . $_SESSION["root"] . "auth/dashboard");
        exit();
    } else {
        header("Location:" . $_SESSION["root"] . "/auth/subscription");
        exit();
    }
} else {
    $errorMessage = $responseData["message"];
    echo "API Error: $errorMessage";
}
