<?php
include "../header.php";

if (isset($_POST["upigate"])) {
    include "config.php";

    if (empty($_POST["amount"]) || empty($_POST["planid"])) {
        die("Invalid input: Amount and Plan ID are required.");
    }

    $amount = $_POST["amount"];
    $planid = $_POST["planid"];

    $order_id = "TXN" . time() . rand(11111, 99999);

    setcookie("order_id_cookie", $order_id, time() + 3600, "/", "", true, true);
    setcookie("planid_cookie", $planid, time() + 3600, "/", "", true, true);

    

     $url = $root . "api/create-order";
    $callbackurl = $root . "auth/lib/callback";

    $data = [
        "customer_mobile" => $mobile,
        "user_token" => $token,
        "amount" => $amount,
        "order_id" => $order_id,
        "redirect_url" => $callbackurl,
        "plan_id"=>$planid,
        "remark1" => "SUBSCRIPTION",
        "remark2" => "AMOUNT-" . $amount,

    ];
//    echo "<pre>";
//    print_r($data);
//    echo "</pre>";
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
        exit();
    }

    curl_close($ch);
    // echo $response;
    $jsonResponse = json_decode($response, true);
//    echo "<pre>";
//    print_r($jsonResponse);
//    echo "</pre>";
    if ($jsonResponse !== null && isset($jsonResponse["result"]["payment_url"])) {
        $paymentUrl = $jsonResponse["result"]["payment_url"];

        header("Location: " . $paymentUrl);
        exit();
    } else {

        echo "Error Occurred: No payment URL returned from API.";

    }
}
?>