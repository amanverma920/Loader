<?php
include "../header.php";

if (1) {
    include "config.php";

    $host_mob =  $site_settings['whatsapp_number'];

    $amount = "1300";
    $order_id = "TXN".uniqid();

    

     $url = $root . "api/create-order";
    $callbackurl = "https://api.whatsapp.com/send?phone=+91".$host_mob."&text=I_PAID_1300_FOR_PG";

    $data = [
        "customer_mobile" => "9999999999",
        "user_token" => $token,
        "amount" => $amount,
        "order_id" => $order_id,
        "redirect_url" => $callbackurl,
        "plan_id"=>$planid,
        "remark1" => "BUY_SOURCE_CODE",
        "remark2" => "AMOUNT-" . $amount,

    ];
//    echo "<pre>";
//    print_r($data);
//    echo "</pre>";
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
        exit();
    }

    curl_close($ch);
    // echo $response;
    $jsonResponse = json_decode($response, true);
//    echo "<pre>";
//    print_r($jsonResponse);
//    echo "</pre>";
    if ($jsonResponse !== null && isset($jsonResponse["result"]["payment_url"])) {
        $paymentUrl = $jsonResponse["result"]["payment_url"];

        header("Location: " . $paymentUrl);
        exit();
    } else {

        echo "Error Occurred: No payment URL returned from API.";

    }
}
?>