
    
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Site Settings</title>
   </head>
   <body>
<?php
include "header.php";
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}

$is_otp = '';
$whatsapp_alert = '';
$email_alert = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {

$is_otp = $_POST['is_otp']; 
$whatsapp_alert = $_POST['whatsapp_alert']; 
$email_alert = $_POST['email_alert']; 
$mobile = $_POST['mobile']; 

$query = "UPDATE users SET is_otp = ?, whatsapp_alert = ?, email_alert = ? WHERE mobile = ?";
$stmt = $conn->prepare($query); 
$stmt->bind_param("ssss", $is_otp, $whatsapp_alert, $email_alert, $mobile); 

if ($stmt->execute()) {

echo "<script>
Swal.fire({
title: 'Success!',
text: 'Profile updated successfully!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
} else {

echo "<script>
Swal.fire({
title: 'Error!',
text: 'Error updating profile: " . addslashes($stmt->error) . "',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
}

$stmt->close(); 
}

$query = "SELECT * FROM users WHERE mobile = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $mobile);
$stmt->execute();
$result = $stmt->get_result();
$userdata = $result->fetch_assoc();
$stmt->close();
?>





     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>MY PROFILE</h4>
               <div class="bg-white mt-3 p-4">
                
                  <div class="mt-0">
                    <form class="row mb-0" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

<div class="col-md-4 mb-3">
<label class="form-label">Mobile Number</label>
<input type="text" name="mobile" placeholder="Mobile Number" value="<?php echo htmlspecialchars($userdata['mobile'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control input-solid" required>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">Email Address</label>
<input type="text" name="email" placeholder="Email Address" value="<?php echo htmlspecialchars($userdata['email'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control input-solid" required readonly>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">Name</label>
<input type="text" placeholder="Name" value="<?php echo htmlspecialchars($userdata['name'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">Company Name</label>
<input type="text" placeholder="Company Name" value="<?php echo htmlspecialchars($userdata['company'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">PAN Number</label>
<input type="text" placeholder="PAN Number" value="<?php echo htmlspecialchars($userdata['pan'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">Aadhaar Number</label>
<input type="text" placeholder="Aadhaar Number" value="<?php echo htmlspecialchars($userdata['aadhaar'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
</div>
<div class="col-md-4 mb-3">
<label class="form-label">Location</label>
<input type="text" placeholder="Location" value="<?php echo htmlspecialchars($userdata['location'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
</div>



<!--<div class="col-md-4 mb-3">-->
 
<!--<button type="submit" name="update" class="btn btn-primary btn-block">Save</button>-->
<!--</div>-->
</form>
                 
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
       <?php include "common_files/footer.php";?>
      
   </body>
</html>