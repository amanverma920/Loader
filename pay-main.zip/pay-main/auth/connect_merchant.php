<?php

?>
<!DOCTYPE html>
<html>
   <head>
      <?php include 'header.php';
      

       include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>
   <?php

if(!isset($_SESSION["user_id"])){
    header('Location:../');
}

if (isset($_POST["addmerchant"])) {
    $bbbytemerchant = mysqli_real_escape_string($conn, $_POST["merchant_name"]);
    $no = mysqli_real_escape_string($conn, $_POST["c_mobile"]);
    $bbbytetokken = $userdata["user_token"];
    $fcuser_id = isset($_SESSION["user_id"]) ? $_SESSION["user_id"] : '';

    // Prepare the query and data based on the selected merchant
    $queries = [
        "hdfc" => "INSERT INTO hdfc( number, seassion, device_id, user_token, pin, upi_hdfc, UPI, tidlist, status, mobile,user_id) 
                   VALUES ( '$no', '', '', '$bbbytetokken', '', '', '', '', 'Deactive', '$no', '$fcuser_id')",
        "phonepe" => "INSERT INTO phonepe_tokens (user_token, phoneNumber, userId, token, refreshToken, name, device_data,user_id) 
                      VALUES ('$bbbytetokken', '$no', '', '', '', '', '', '$fcuser_id')",
        "paytm" => "INSERT INTO paytm_tokens (user_token, phoneNumber, MID, Upiid,user_id) 
                    VALUES ('$bbbytetokken', '$no', '', '', '$fcuser_id')",
        "bharatpe" => "INSERT INTO bharatpe_tokens (user_token, phoneNumber, token, cookie, merchantId,user_id) 
                       VALUES ('$bbbytetokken', '$no', '', '', '' ,'$fcuser_id')",
        "googlepay" => "INSERT INTO googlepay_tokens (user_token, phoneNumber, Instance_Id, Upiid,user_id) 
                        VALUES ('$bbbytetokken', '$no', '', '', '$fcuser_id')",
        "sbi" => "INSERT INTO sbi_token (user_token, phoneNumber, user_id) 
                  VALUES ('$bbbytetokken', '$no', '$fcuser_id')",
        "freecharge" => "INSERT INTO freecharge_token (user_token, phoneNumber, user_id) 
                         VALUES ('$bbbytetokken', '$no', '$fcuser_id')",
        "mobikwik" => "INSERT INTO mobikwik_token (user_token, phoneNumber, user_id) 
                       VALUES ('$bbbytetokken', '$no', '$fcuser_id')",
        "amazon" => "INSERT INTO amazon_token (user_token, phoneNumber, user_id) 
                       VALUES ('$bbbytetokken', '$no', '$fcuser_id')"
    ];

    // Check if the selected merchant exists in the queries array
    if (isset($queries[$bbbytemerchant])) {
        $data = $queries[$bbbytemerchant];
       
        try {
            $insert = mysqli_query($conn, $data);
            if ($insert) {
                echo '<script>Swal.fire({
  title: "Merchant Added!",
  text: "Congrats! Merchant has been added successfully!",
  icon: "success",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
            } else {
                echo '<script>Swal.fire({
  title: "Merchant Not Added!",
  text: "Looks like merchant already exists!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
            }
        } catch (mysqli_sql_exception $e) {
            
            echo '<script>Swal.fire({
  title: "Merchant Not Added!",
  text: "Looks like merchant already exists!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
        }
    } else {
        echo '<script>Swal.fire({
  title: "Invalid Merchant!",
  text: "Some error occured!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
    }
}


if (isset($_POST["delete"])) {
    $merchant_type = mysqli_real_escape_string($conn, $_POST["merchant_type"]);
    $token = $userdata["user_token"];

    // Map merchant types to their respective tables and user fields
    $merchantMap = [
        "hdfc" => ["table" => "hdfc", "field" => "hdfc_connected"],
        "phonepe" => ["table" => "phonepe_tokens", "field" => "phonepe_connected"],
        "paytm" => ["table" => "paytm_tokens", "field" => "paytm_connected"],
        "bharatpe" => ["table" => "bharatpe_tokens", "field" => "bharatpe_connected"],
        "googlepay" => ["table" => "googlepay_tokens", "field" => "googlepay_connected"],
        "freecharge" => ["table" => "freecharge_token", "field" => "freecharge_connected"],
        "sbi" => ["table" => "sbi_token", "field" => "sbi_connected"],
        "mobikwik" => ["table" => "mobikwik_token", "field" => "mobikwik_connected"],
        "amazon" => ["table" => "amazon_token", "field" => "amazon_connected"]
    ];

    if (array_key_exists($merchant_type, $merchantMap)) {
        $table = $merchantMap[$merchant_type]["table"];
        $field = $merchantMap[$merchant_type]["field"];

        // Prepare delete and update queries
        $del = "DELETE FROM `$table` WHERE user_token = '$token'";
        $update = "UPDATE users SET `$field` = 'No' WHERE user_token = '$token'";

        // Execute delete and update
        $res_del = mysqli_query($conn, $del);
        $res_update = mysqli_query($conn, $update);

        // Handle specific case for phonepe (delete from store_id too)
        if ($merchant_type == "phonepe") {
            $del_store_id = "DELETE FROM store_id WHERE user_token = '$token'";
            mysqli_query($conn, $del_store_id);
        }

        // Final result
        if ($res_del && $res_update) {
            echo '<script>Swal.fire({
  title: "Merchant Deleted!",
  text: "Merchant deleted successfully!",
  icon: "success",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
        } else {
            echo '<script>Swal.fire({
  title: "Merchant deletion failed!",
  text: "Some error occured!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
        }
    } else {
        echo '<script>Swal.fire({
  title: "Merchant Not Added!",
  text: "Looks like merchant already exists!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   
    
  }
});
</script>';
    }
}
?>




      <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>MERCHANT SETTINGS</h4>
               <div class="bg-white mt-3 p-4">
                  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row">
                     <div class="mb-3 col-12 col-md-4">
                        <label for="">Merchant Name</label>
                        <select name="merchant_name" required id="" class="form-control mt-2">
                            <option value="paytm">--SELECT MERCHANT--</option>
                            <option value="paytm">Paytm</option>
                        
                        <option value="phonepe">Phonepe</option>
                        <option value="bharatpe">BharatPe</option>
                         <option value="freecharge">FreeCharge</option>
                        <option value="amazon">Amazon</option>
                        <option value="googlepay">GooglePay</option>
                        <option value="sbi">Sbi Merchant</option>
                       
                        <option value="mobikwik">MobikWik</option>
                        
                        <option value="hdfc">HDFC Vyapar</option>
                        </select>
                     </div>
                     <div class="mb-3 col-12 col-md-4">
                        <label for="">Merchant Number</label>
                        <input type="number" name="c_mobile" class="form-control mt-2" placeholder="Number">
                     </div>
                     <div class="mb-3 col-12 col-md-4 d-flex justify-content-end flex-column">
                        <button class="btn btn-success mt-2" type="submit" name="addmerchant">Add Merchant</button>
                     </div>
                  </form>
                  <div class="mt-4">
                     <h6>Connected Mercahnts</h6>
                     <div class="overflow-auto">
                     <table class="table mt-3 table-striped table-bordered ">
                        <thead>
                           <tr>
                              <th scope="col">#ID</th>
                              <th scope="col">MERCHANT NAME</th>
                              <th scope="col">PHONE NUMBER</th>
                              <th scope="col">ADDEDED ON</th>
                              <th scope="col">STATUS</th>
                              <th scope="col">
                                 Verify
                              </th>
                              <th scope="col">Delete</th>
                           </tr>
                           
                        </thead>
                        <tbody>
                                <?php
$cxrrrrtoken = $userdata['user_token'];
$fetchData = "
    SELECT 'hdfc' AS merchant_type, id, number, date, status FROM hdfc WHERE user_token = '$cxrrrrtoken' 
    UNION ALL 
    SELECT 'phonepe' AS merchant_type, sl AS id, phoneNumber AS number, date, status FROM phonepe_tokens WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'paytm' AS merchant_type, id, phoneNumber AS number, date, status FROM paytm_tokens WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'bharatpe' AS merchant_type, id, phoneNumber AS number, date, status FROM bharatpe_tokens WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'googlepay' AS merchant_type, id, phoneNumber AS number, date, status FROM googlepay_tokens WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'freecharge' AS merchant_type, id, phoneNumber AS number, date, status FROM freecharge_token WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'sbi' AS merchant_type, id, phoneNumber AS number, date, status FROM sbi_token WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'mobikwik' AS merchant_type, id, phoneNumber AS number, date, status FROM mobikwik_token WHERE user_token = '$cxrrrrtoken'
    UNION ALL
    SELECT 'amazon' AS merchant_type, id, phoneNumber AS number, date, status FROM amazon_token WHERE user_token = '$cxrrrrtoken'
";

// echo $fetchData;

$ssData = mysqli_query($conn, $fetchData);

if ($ssData) {
    $counter = 1;
    while ($merchant = mysqli_fetch_array($ssData)) {
        $class = ($merchant['status'] == 'Active') ? 'badge badge-success' : 'badge badge-danger';
        ?>
        <tr>
            <td><?php echo $counter++; ?></td>
            <td><?php echo !empty($merchant['merchant_type']) ? strtoupper(htmlspecialchars($merchant['merchant_type'], ENT_QUOTES, 'UTF-8')) : ''; ?></td>
            <td><?php echo !empty($merchant['number']) ? htmlspecialchars($merchant['number'], ENT_QUOTES, 'UTF-8') : ''; ?></td>
            <td>
                <button type="button" class="btn ripple btn-primary px-2"><?php echo !empty($merchant['date']) ? htmlspecialchars($merchant['date'], ENT_QUOTES, 'UTF-8') : ''; ?></button>
            </td>
            <td style="color: <?php echo ($merchant['status'] == 'Active') ? 'green' : 'red'; ?>">
                <?php echo htmlspecialchars($merchant['status'], ENT_QUOTES, 'UTF-8'); ?>
            </td>
            <td>
<?php
if ($merchant['merchant_type'] == 'hdfc') {
    ?>
    <form action="send_hdfcotp" method="post">
        <input type="hidden" name="hdfc_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'phonepe') {
    ?>
<form action="send_phonepeotp" method="post">
    <input type="hidden" name="phonepe_mobile" value="<?php echo $merchant['number']; ?>">
    <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    <a href="update_upi.php" class="btn btn-success" style="border-radius: 0;font-size: 14px;" id="upiButton">Update UPI ID</a>
    <script>
    document.getElementById("upiButton").addEventListener("click", function() {
        // Redirect to the update_upi.php page
        window.location.href = "update_upi.php"; // Adjust the path if necessary
    });
</script>
</form>



    <?php
} elseif ($merchant['merchant_type'] == 'paytm') {
    ?>
    <form action="send_paytmotp" method="post">
        <input type="hidden" name="paytm_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'bharatpe') {
    ?>
    <form action="send_bharatpeotp" method="post">
        <input type="hidden" name="bharatpe_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'googlepay') {
    ?>
    <form action="send_googlepayotp" method="post">
        <input type="hidden" name="googlepay_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'freecharge') {
    ?>
    <form action="send_freechargeotp" method="post">
        <input type="hidden" name="freecharge_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'sbi') {
    ?>
    <form action="send_sbiotp" method="post">
        <input type="hidden" name="sbi_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'mobikwik') {
    ?>
    <form action="send_mobikwikotp" method="post">
        <input type="hidden" name="mobikwik_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
}
elseif ($merchant['merchant_type'] == 'amazon') {
    ?>
    <form action="send_amazonotp" method="post">
        <input type="hidden" name="amazon_mobile" value="<?php echo $merchant['number']; ?>">
        
        <button class="btn ripple btn-primary px-2" name="Verify">Verify</button>
    </form>
    <?php
}
?>
            </td>
            <td>
<?php
if ($merchant['merchant_type'] == 'hdfc') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="hdfc_mobile" value="<?php echo $merchant['number']; ?>">
        <input type="hidden" name="merchant_type" value="hdfc">
        
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'phonepe') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="phonepe_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="phonepe">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'paytm') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="paytm_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="paytm">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'bharatpe') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="bharatpe_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="bharatpe">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'googlepay') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="googlepay_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="googlepay">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'freecharge') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="freecharge_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="freecharge">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'sbi') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="sbi_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="sbi">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
} elseif ($merchant['merchant_type'] == 'mobikwik') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="mobikwik_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="mobikwik">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
}
elseif ($merchant['merchant_type'] == 'amazon') {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="amazon_mobile" value="<?php echo $merchant['number']; ?>">
        
        <input type="hidden" name="merchant_type" value="amazon">
        <button class="btn ripple btn-danger px-2" name="delete">Delete</button>
    </form>
    <?php
}
?>
            </td>
        </tr>
        <?php
    }
}
?>
</tbody>
                     </table></div>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
    <?php include "common_files/footer.php";?>
      
   </body>
</html>