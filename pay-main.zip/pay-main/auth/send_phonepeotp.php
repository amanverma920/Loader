
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body><?php
   define('ABSPATH', dirname(__FILE__) . '/'); 
   
   //require_once(ABSPATH . 'header.php');
   
   ?>
<?php
   include "../phnpe/index.php";
   include "../pages/dbFunctions.php";
   include "../pages/dbInfo.php";

   
   if(isset($_POST['Verify'])){
   
   if ($userdata['phonepe_connected']=="Yes"){
   
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "Merchant Already Connected !!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
               window.location.href = "connect_merchant"; 
           }
       });
   </script>';
   exit;
   
       }
   
       $no =sanitizeInput($_REQUEST['phonepe_mobile']);
   
        $sendotpresult=sentotp(1,$no,0,0,0);
   
                 $json0=json_decode($sendotpresult,1);
                // print_r($json0);
   $otpSended=$json0["otpSended"];
   $phoneNumber=$json0["phoneNumber"];
   $token=$json0["token"];
   $device=$json0["device"];
   echo "<script>alert(".$device.");</script>";
   
   if($otpSended == 'true'){
   echo '<script>
           Swal.fire({
           title: "Your OTP Has Been Sent!!",
           text: "Please click Ok button!!",
           icon: "success",
           confirmButtonText: "Ok",
           allowOutsideClick: false,
           allowEscapeKey: false
       }).then((result) => {
           if (result.isConfirmed) {
               showOtpForm();
           }
       });
   
           function showOtpForm() {
               Swal.fire({
                   title: "PhonePe UPI Settings",
                   html: `
                       <form id="phonepeForm" method="POST" action="phonepe_verify" class="mb-2">
                           <div class="row" id="merchant">
                               <div class="col-md-12 mb-2">
                                   <input type="number" name="otp" id="otp" placeholder="Enter OTP" class="form-control" required>
                               </div>
                               <input type="hidden" name="number" value="' . $no . '">
                              
                               <input type="hidden" name="user_token" value="' . $userdata['user_token'] . '">
   
                               <input type="hidden" name="no" value="' . $phoneNumber . '">
                               <input type="hidden" name="otp_toekn" value="' . $token . '">
                               <input type="hidden" name="device_data" value="' . $device . '">
                               <div class="col-md-12 mb-2">
                                   <button type="submit" name="verifyotp" class="btn btn-primary btn-block mt-2">Verify OTP</button>
                               </div>
                           </div>
                       </form>
                   `,
                   showCancelButton: false,
                   showConfirmButton: false,
                   customClass: {
                       popup: "swal2-custom-popup",
                       title: "swal2-title",
                       content: "swal2-content"
                   },
                   allowOutsideClick: false,
                   allowEscapeKey: false
               });
           }
       </script>';
       exit;
   
   }
   
   else{
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "OTP Error!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
               window.location.href = "connect_merchant"; 
           }
       });
   </script>';
   exit;
   } 
   
   } 
   else{
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "Form Not Submitted!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
               window.location.href = "connect_merchant"; 
           }
       });
   </script>';
   exit;
   }
   ?>
      </body>
</html>