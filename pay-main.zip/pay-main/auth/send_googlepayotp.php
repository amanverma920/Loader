<!DOCTYPE html>
<html>
   <head>
      <?php include 'header.php';
      

       include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body><?php
   define('ABSPATH', dirname(__FILE__) . '/'); 
   require_once(ABSPATH . 'header.php');
   
    include 'common_files/head.php';
   function sanitizeInput($input) {
       return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
   }
   
   if (isset($_POST['verifyotp'])) {
       $bbbyteuserid = $_SESSION['user_id'];
       $bbytepaytmuserid = $userdata['user_token'];
      // $bbytepaytmusermid = mysqli_real_escape_string($conn, sanitizeInput($_POST["MID"]));
       $bbytepaytmuserupiid = mysqli_real_escape_string($conn, sanitizeInput($_POST["UPI"]));
   
       $sqlUpdateUser = "UPDATE users SET googlepay_connected = 'Yes' WHERE user_token = '$bbytepaytmuserid'";
       $resultUpdateUser = mysqli_query($conn, $sqlUpdateUser);
   
       $sqlw = "UPDATE googlepay_tokens SET  Upiid = '$bbytepaytmuserupiid', status = 'Active', user_id = '$bbbyteuserid' WHERE user_token = '$bbytepaytmuserid'";
       $result = mysqli_query($conn, $sqlw);
   
       if ($result && $resultUpdateUser) {
            echo '<script>Swal.fire({
  title: "Merchant Verified!",
  text: "Congrats! Merchant added successfully!",
  icon: "success",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   window.location.href="connect_merchant";
    
  }
});
</script>';exit;
       }
   }
   
   if (isset($_POST['Verify'])) { 
       if ($userdata['googlepay_connected'] === "Yes") {
   echo '<script>Swal.fire({
  title: "Merchant Already Verified!",
  text: "Google Pay merchant already exists!",
  icon: "error",
  confirmButtonColor: "#3085d6",
  confirmButtonText: "Next"
}).then((result) => {
  if (result.isConfirmed) {
   window.location.href="connect_merchant";
    
  }
});
</script>';exit;
       } else {
          // $paytm_mobile = sanitizeInput($_POST["paytm_mobile"]);
       }
   }
           ?>

<div class="container d-flex justify-content-center align-items-center vh-100">
   <form id="paytmForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="w-100" style="max-width: 500px;">
      <div class="card p-4">
         <h5 class="text-center mb-4">VERIFY GOOGLE PAY MERCHANT</h5>
         <!-- <div class="mb-3">
            <label for="MID" class="form-label">Enter Merchant ID</label>
            <input type="text" name="MID" id="MID" placeholder="Enter Merchant ID" class="form-control " required>
         </div> -->
         <!-- <div class="mb-3">
            <label for="Number" class="form-label">Enter Number</label>
            <input type="number" name="Number" id="Number" placeholder="Enter Number" value="<?php echo $paytm_mobile; ?>" class="form-control" minlength="10" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');" required>
         </div> -->
         <div class="mb-3">
            <label for="UPI" class="form-label">Enter UPI</label>
            <input type="text" name="UPI" id="UPI" placeholder="Enter UPI" class="form-control" required value="">
         </div>
         <div class="d-grid mt-1">
            <button type="submit" name="verifyotp" class="btn btn-success">Verify Google Pay</button>
         </div>
      </div>
   </form>
</div>

</body>
</html>