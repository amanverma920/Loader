<?php 
include "header.php";

if (!isset($_SESSION["user_id"])) {
    header('Location:../');
}

$sql = "SELECT COUNT(*) AS count FROM reports WHERE mobile = '$mobile'";
   
   // Execute the query
   $result = $conn->query($sql);
   
   if ($result === false) {
       $rowCount = 0;
   } else {
       // Fetch the result
       $row = $result->fetch_assoc();
   
       // Get the count from the result
       $rowCount = $row['count'];
   }
   
   $expiryDate = $userdata['expiry'];
   $today = date('Y-m-d'); // Get today's date in 'YYYY-MM-DD' format
   
   if (strtotime($expiryDate) >= strtotime($today)) {
       $status = "Active";
   } else {
       $status = "Expired";
   }
?>

<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
.row > div .ibox {
  padding: 20px;
}.row > div .ibox-body div {
  color: #fff;
}.row > div .ibox-body h2{
   color:#fff
}
.row > div .ibox {
  padding: 20px;
}.row > div .ibox-body span {
  float: right;
  color: #fff;
}
.row > div {
  margin-bottom: 10px;
}
      </style>
      <title>Home</title>
      
   </head>
   <body data-bs-theme="light">
      <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>DASHBOARD</h4>
               <div class="mt-0 py-3">
                <!-------------------- BLACKBOX PLEASE BEAUTIFY THE BELOW CODE-------------------------->
                   <div class="row">
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-primary color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong"><?php echo $todayallpayment["amt"]; ?></h2>
               <div class="m-b-5">Today Total Requests</div>
               <span class=" widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-arrow-left-right" viewBox="0 0 16 16">
                     <path fill-rule="evenodd" d="M1 11.5a.5.5 0 0 0 .5.5h11.793l-3.147 3.146a.5.5 0 0 0 .708.708l4-4a.5.5 0 0 0 0-.708l-4-4a.5.5 0 0 0-.708.708L13.293 11H1.5a.5.5 0 0 0-.5.5m14-7a.5.5 0 0 1-.5.5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H14.5a.5.5 0 0 1 .5.5" />
                  </svg>
               </span>
               <div><small>100% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-success color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong">₹<?php echo number_format($todaysuccesspayment["amt"]) ?></h2>
               <div class="m-b-5">Today Success Transaction</div>
               <span class=" widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-send-check" viewBox="0 0 16 16">
                     <path d="M15.964.686a.5.5 0 0 0-.65-.65L.767 5.855a.75.75 0 0 0-.124 1.329l4.995 3.178 1.531 2.406a.5.5 0 0 0 .844-.536L6.637 10.07l7.494-7.494-1.895 4.738a.5.5 0 1 0 .928.372zm-2.54 1.183L5.93 9.363 1.591 6.602z" />
                     <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0m-1.993-1.679a.5.5 0 0 0-.686.172l-1.17 1.95-.547-.547a.5.5 0 0 0-.708.708l.774.773a.75.75 0 0 0 1.174-.144l1.335-2.226a.5.5 0 0 0-.172-.686" />
                  </svg>
               </span>
               <div><small>99.9% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-warning color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong">₹<?php echo number_format($todaypendingpayment["amt"], 2); ?></h2>
               <div class="m-b-5">Today Pending Payment</div>
               <span class=" widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-clock-history" viewBox="0 0 16 16">
                     <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022zm2.004.45a7 7 0 0 0-.985-.299l.219-.976q.576.129 1.126.342zm1.37.71a7 7 0 0 0-.439-.27l.493-.87a8 8 0 0 1 .979.654l-.615.789a7 7 0 0 0-.418-.302zm1.834 1.79a7 7 0 0 0-.653-.796l.724-.69q.406.429.747.91zm.744 1.352a7 7 0 0 0-.214-.468l.893-.45a8 8 0 0 1 .45 1.088l-.95.313a7 7 0 0 0-.179-.483m.53 2.507a7 7 0 0 0-.1-1.025l.985-.17q.1.58.116 1.17zm-.131 1.538q.05-.254.081-.51l.993.123a8 8 0 0 1-.23 1.155l-.964-.267q.069-.247.12-.501m-.952 2.379q.276-.436.486-.908l.914.405q-.24.54-.555 1.038zm-.964 1.205q.183-.183.35-.378l.758.653a8 8 0 0 1-.401.432z" />
                     <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0z" />
                     <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5" />
                  </svg>
               </span>
               <div><small>12% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-info color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong">₹<?php echo number_format($todaysuccesspayment["amt"], 2); ?></h2>
               <div class="m-b-5">Today Settlement</div>
               <span class="widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-send-dash" viewBox="0 0 16 16">
                     <path d="M15.964.686a.5.5 0 0 0-.65-.65L.767 5.855a.75.75 0 0 0-.124 1.329l4.995 3.178 1.531 2.406a.5.5 0 0 0 .844-.536L6.637 10.07l7.494-7.494-1.895 4.738a.5.5 0 1 0 .928.372zm-2.54 1.183L5.93 9.363 1.591 6.602z" />
                     <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0m-5.5 0a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5" />
                  </svg>
               </span>
               <div><small>99.9% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-success color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong"><?php echo htmlspecialchars($userdata['expiry'], ENT_QUOTES, 'UTF-8'); ?></h2>
               <div class="m-b-5">Plan Expire Date</div>
               <span class="widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-calendar2-check" viewBox="0 0 16 16">
                     <path d="M10.854 8.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L7.5 10.793l2.646-2.647a.5.5 0 0 1 .708 0" />
                     <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M2 2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1z" />
                     <path d="M2.5 4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H3a.5.5 0 0 1-.5-.5z" />
                  </svg>
               </span>
               <div><small>45% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-warning color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong"><?php echo $rowCount ?></h2>
               <div class="m-b-5">Successful Used Transaction</div>
               <span class="widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-hourglass-split" viewBox="0 0 16 16">
                     <path d="M2.5 15a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1zm2-13v1c0 .537.12 1.045.337 1.5h6.326c.216-.455.337-.963.337-1.5V2zm3 6.35c0 .701-.478 1.236-1.011 1.492A3.5 3.5 0 0 0 4.5 13s.866-1.299 3-1.48zm1 0v3.17c2.134.181 3 1.48 3 1.48a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351z" />
                  </svg>
               </span>
               <div><small>18% higher</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-info color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong"><?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?></h2>
               <div class="m-b-5">Account Status</div>
               <span class="widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                     <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4" />
                     <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z" />
                  </svg>
               </span>
               <div><small>Buy Subscription</small></div>
            </div>
         </div>
      </div>
      <div class="col-lg-3 col-md-6">
         <div class="ibox bg-danger color-white widget-stat">
            <div class="ibox-body">
               <h2 class="m-b-5 font-strong">₹<?php echo number_format($todayfail["amt"], 2); ?></h2>
               <div class="m-b-5">Today Faild Payment</div>
               <span class="widget-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" fill="currentColor" class="bi bi-send-exclamation" viewBox="0 0 16 16">
                     <path d="M15.964.686a.5.5 0 0 0-.65-.65L.767 5.855a.75.75 0 0 0-.124 1.329l4.995 3.178 1.531 2.406a.5.5 0 0 0 .844-.536L6.637 10.07l7.494-7.494-1.895 4.738a.5.5 0 1 0 .928.372zm-2.54 1.183L5.93 9.363 1.591 6.602z" />
                     <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1.5a.5.5 0 0 1-1 0V11a.5.5 0 0 1 1 0m0 3a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0" />
                  </svg>
               </span>
               <div><small>0 Transactions</small></div>
            </div>
         </div>
      </div>
   </div>
                <!---------------------------------------------->
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <?php include "common_files/footer.php";?>

   </body>
</html>

