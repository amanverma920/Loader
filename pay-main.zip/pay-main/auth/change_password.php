

           <!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>
<?php
include "header.php";
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}
if (isset($_REQUEST['update'])) {

    $sanitizedMobile =  $mobile;

    $current_password =  $_REQUEST['current_password'];
    $new_password =  $_REQUEST['new_password'];
    $confirm_password =  $_REQUEST['confirm_password'];

    $query = "SELECT `password` FROM `users` WHERE `mobile` = '$sanitizedMobile'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $hashedPasswordFromDB = $row['password'];

        if (password_verify($current_password, $hashedPasswordFromDB)) {
            if ($new_password === $confirm_password) {

                $newpass = password_hash($new_password, PASSWORD_DEFAULT);

                $passwor = "UPDATE `users` SET `password` = '$newpass' WHERE `mobile` = '$sanitizedMobile'";
                $up = mysqli_query($conn, $passwor);

                if ($up) {
        echo '<script>        
                        Swal.fire({
                            icon: "success",
                            title: "Password Changed Successfully",
                            text: "Your password has been updated.",
                            showConfirmButton: true,
                            confirmButtonText: "Ok",
                        }).then((result) => {
                            if (result.isConfirmed) {
                               // window.location.href = "changepassword.php";
                            }
                        });
                    </script>';
                    
                } else {
        echo '<script>        
                        Swal.fire({
                            icon: "error",
                            title: "Password Update Failed",
                            text: "Please try again later.",
                            showConfirmButton: true,
                            confirmButtonText: "Try Again",
                        }).then((result) => {
                            if (result.isConfirmed) {
                                //window.location.href = "changepassword.php";
                            }
                        });
                    </script>';
                    
                }
            } else {
      echo '<script>        
                    Swal.fire({
                        icon: "error",
                        title: "New Password and Confirm Password Do Not Match",
                        showConfirmButton: true,
                        confirmButtonText: "Try Again",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            //window.location.href = "changepassword.php";
                        }
                    });
                </script>';
                
            }
        } else {
        echo '<script>         
                Swal.fire({
                    icon: "error",
                    title: "Current Password Does Not Match",
                    showConfirmButton: true,
                    confirmButtonText: "Try Again",
                }).then((result) => {
                    if (result.isConfirmed) {
                       // window.location.href = "changepassword.php";
                    }
                });
            </script>';
            
        }
    } else {        echo '<script>        
            Swal.fire({
                icon: "error",
                title: "Please try again later.",
                text: "Please try again later.",
                showConfirmButton: true,
                confirmButtonText: "Try Again",
            }).then((result) => {
                if (result.isConfirmed) {
                    //window.location.href = "changepassword.php";
                }
            });
        </script>';
        
    }
}
?>
     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>PAYMENT LINKS</h4>
               <div class="bg-white mt-3 p-4">

                  <div class="mt-0">

                <form class="row mb-0" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                   <!--  <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">-->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Current Password</label>
                    <input type="password" name="current_password" placeholder="Current Password" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" placeholder="New Password" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <button type="submit" name="update" class="btn btn-primary btn-block">Change Password</button>
                </div>

              </form>

                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <?php include "common_files/footer.php";?>

   </body>
</html>