
           
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Site Settings</title>
   </head>
   <body>

      <?php
include "header.php";
include "function.php";

if (isset($_POST["create"])) {
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];

    $checkMobileQuery = "SELECT * FROM `users` WHERE `mobile` = '$mobile'";
    $checkMobileResult = mysqli_query($conn, $checkMobileQuery);

    $checkEmailQuery = "SELECT * FROM `users` WHERE `email` = '$email'";
    $checkEmailResult = mysqli_query($conn, $checkEmailQuery);

    if (mysqli_num_rows($checkMobileResult) > 0) {
       echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your mobile number already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
    } elseif (mysqli_num_rows($checkEmailResult) > 0) {
        echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your email ID already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
    } else {
        $password = $_POST["password"];
        $name = $_POST["name"];
        $company = $_POST["company"];
        $pin = $_POST["pin"];
        $pan = $_POST["pan"];
        $aadhaar = $_POST["aadhaar"];

        $checkpan = "SELECT * FROM `users` WHERE `pan` = '$pan'";
        $checkpanResult = mysqli_query($conn, $checkpan);

        $checkaadhar = "SELECT * FROM `users` WHERE `aadhaar` = '$aadhaar'";
        $checkAadharResult = mysqli_query($conn, $checkaadhar);

        if (mysqli_num_rows($checkpanResult) > 0) {
            echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your Pan Number already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        } elseif (mysqli_num_rows($checkAadharResult) > 0) {
           echo "<script>
Swal.fire({
title: 'Error!',
text: 'Your Aadhar ID already exists!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        } else {
            $location = $_POST["location"];
            $key = md5(rand(00000000, 99999999));
            $pass = password_hash($password, PASSWORD_BCRYPT);
            $today = date("Y-m-d", strtotime("+1 days"));

           

            $register = "INSERT INTO `users`(`name`, `mobile`, `role`, `password`, `email`, `company`, `pin`, `pan`, `aadhaar`, `location`, `user_token`, `expiry`) 
   VALUES ('$name', '$mobile', 'User', '$pass', '$email', '$company', '$pin', '$pan', '$aadhaar', '$location', '$key', '$today')";

            $result = mysqli_query($conn, $register);

            $msg = "Dear $name thanks For Registering Us
   Your Username = $mobile
   Your Password = $password
   Thanks & Regards";
            $encodedMsg = urlencode($msg);

            if ($result) {
                echo "<script>
Swal.fire({
title: 'Success!',
text: 'Account Creating Successful! Now please login!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
            } else {
                echo "<script>
Swal.fire({
title: 'Error!',
text: 'Some error Occured!',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
            }
        }
    }
}
?>




     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>ADD NEW USER</h4>
               <div class="bg-white mt-3 p-4">
                
                  <div class="mt-0">
                    
                       <form class="row mb-2" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <div class="col-md-6 mb-2">
  <label class="form-label">Mobile Number</label>
  <input type="text" name="mobile" placeholder="Enter Mobile Number" class="form-control"
         oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);" required />
</div>
    <div class="col-md-6 mb-2"><label class="form-label">Password</label> <input type="password" name="password" placeholder="Enter Password" class="form-control" required="" /></div>
  
    <div class="col-md-6 mb-2"><label class="form-label">Email Address</label> <input type="email" name="email" placeholder="Enter Email Address" class="form-control" required="" /></div>
    <div class="col-md-6 mb-2"><label class="form-label">Name</label> <input type="text" name="name" placeholder="Enter Name" class="form-control" required="" /></div>
    <div class="col-md-6 mb-2"><label class="form-label">Company</label> <input type="text" name="company" placeholder="Enter Company" class="form-control" required="" /></div>
    
    <div class="col-md-6 mb-2">
  <label class="form-label">Area Pin</label>
  <input type="text" name="pin" placeholder="Area Pin" class="form-control"
         oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);" required />
</div>

    <div class="col-md-6 mb-2"><label class="form-label">PAN Number</label> <input type="text" name="pan" placeholder="Enter PAN Number" class="form-control" onkeypress="if(this.value.length==10) return false;" required="" /></div>
    
    <div class="col-md-6 mb-2">
  <label class="form-label">Aadhaar Number</label>
  <input type="text" name="aadhaar" placeholder="Enter Aadhaar Number" class="form-control"
         oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 12);" required />
</div>
    <div class="col-md-12 mb-2"><label class="form-label">Location</label> <input type="text" name="location" placeholder="Enter Location" class="form-control" required="" /></div>
    <div class="my-2 col">
                        <button type="submit" name="create" class="btn btn-success">Add User</button>
                        </div>

</form>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <?php include "common_files/footer.php";?>
      
   </body>
</html>