
<!DOCTYPE html>
<html>
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>
<?php include "header.php"; 
if(!isset($_SESSION["user_id"])){
    header('Location:../');
}




if (isset($_SESSION['username'])) {
    $mobile = $_SESSION['username'];  

    $user_query = "SELECT * FROM users WHERE mobile = '$mobile'";
    $user_result = mysqli_query($conn, $user_query);

    if ($user_data = mysqli_fetch_array($user_result)) {
        $current_upi_id = $user_data['upi_id'];  

        if (isset($_POST['update_upi'])) {

            $new_upi_id = mysqli_real_escape_string($conn, $_POST['new_upi_id']);

            if (!empty($new_upi_id)) {

                $update_query = "UPDATE users SET upi_id = '$new_upi_id' WHERE mobile = '$mobile'";

                if (mysqli_query($conn, $update_query)) {
echo "<script>
Swal.fire({
title: 'Success!',
text: 'Phonepe UPI ID has been updated!',
icon: 'success',
confirmButtonText: 'OK'
});
  </script>";
                  
                } else {
                  echo "<script>
Swal.fire({
title: 'Error!',
text: 'Failed to update Phonepe UPI ID',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
                    
                }
            } else {
                echo "<script>
Swal.fire({
title: 'Error!',
text: 'Failed to update Phonepe UPI ID',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
            }
        }
    } else {
echo "<script>
Swal.fire({
title: 'Error!',
text: 'Failed to update Phonepe UPI ID',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
        
    }
} else {

  echo "<script>
Swal.fire({
title: 'Error!',
text: 'Failed to update Phonepe UPI ID',
icon: 'error',
confirmButtonText: 'OK'
});
  </script>";
}

?>




   <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>ADD PHONEPE UPI</h4>
               <div class="bg-white mt-3 p-4">
                  <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row">
                    
                     <div class="col d-flex flex-column">
                        <label for="">PhonePe Upi</label>
                        <input type="text" name="new_upi_id" class="form-control mt-2" placeholder="UPI ID"  value="<?php echo isset($current_upi_id) ? $current_upi_id : ''; ?>">
                     </div>
                     <div class="col d-flex justify-content-end flex-column">
                        <button class="btn btn-success mt-2" type="submit" name="update_upi">Add UPI</button>
                     </div>
                  </form>
              
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
      <script type="text/javascript" src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/2.2.2/js/dataTables.bootstrap5.min.js"></script>
      <script type="text/javascript" src="assets/js/app.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      
   </body>
</html>

