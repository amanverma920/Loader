

<!DOCTYPE html>
<html>
   <head>
      <?php include "header.php";include 'common_files/head.php';if(!isset($_SESSION["user_id"])){
    header('Location:../');
}?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>





     <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>EXAMPLE SDKS</h4>
               <div class="mt-0 p-4">
                
                  <div class="mt-0">
                    <div class="row">
                <!-- Android SDK -->
               

                <!-- PHP SDK -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">PHP SDK</h5>
                            <p class="card-text">Our PHP SDK for PHP-based web applications.</p>
                            <a href="sdk/php.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <!-- Add more SDKs for other programming languages -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Java SDK</h5>
                            <p class="card-text">Our Java SDK for Java applications.</p>
                            <a href="sdk/java.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Python SDK</h5>
                            <p class="card-text">Our Python SDK for Python applications.</p>
                            <a href="sdk/python.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">C# SDK</h5>
                            <p class="card-text">Our C# SDK for .NET applications.</p>
                            <a href="sdk/c#.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Ruby SDK</h5>
                            <p class="card-text">Our Ruby SDK for Ruby applications.</p>
                            <a href="sdk/ruby.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">JavaScript SDK</h5>
                            <p class="card-text">Our JavaScript SDK for web applications.</p>
                            <a href="sdk/javascript.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">C++ SDK</h5>
                            <p class="card-text">Our C++ SDK for web applications.</p>
                            <a href="sdk/c++.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">KOTLIN SDK</h5>
                            <p class="card-text">Our KOTLIN SDK for android applications.</p>
                            <a href="sdk/kotlin.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">TYPESCRIPT SDK</h5>
                            <p class="card-text">Our TYPESCRIPT SDK for web applications.</p>
                            <a href="sdk/typescript.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">WORDPRESS SDK</h5>
                            <p class="card-text">Our WORDPRESS SDK for Wordpress applications.</p>
                            <a href="sdk/upi-gateway.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Swift SDK</h5>
                            <p class="card-text">Our Swift SDK for iOS applications.</p>
                            <a href="sdk/swift.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">aMember SDK</h5>
                            <p class="card-text">Our aMemeber SDK latest update.</p>
                            <a href="sdk/iupi.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
            </div>
 <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Android SDK</h5>
                            <p class="card-text">Our Android SDK allows you to seamlessly integrate our services into your Android applications.</p>
                            <a href="sdk/android.zip"><button class="btn btn-success">Download</button></a>
                        </div>
                    </div>
                </div>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
       <?php include "common_files/footer.php";?>
      
   </body>
</html>