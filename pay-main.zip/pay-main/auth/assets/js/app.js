"use strict";
$(document).ready(function(){
    $(".toogle-side").click(function(){
        $(".d-none-").toggleClass("d-none d-block");
    });
});
