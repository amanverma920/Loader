<!DOCTYPE html>
<html>
   <head>
      <?php include 'header.php';
      

       include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body><?php

define('ABSPATH', dirname(__FILE__) . '/'); 
require_once(ABSPATH . 'header.php');

function sanitizeInput($input) {
    if (is_string($input)) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    } else {
        return $input;
    }
}

function bharatpe_trans($merchantId, $token, $cookie) {
    $fromDate = date('Y-m-d', strtotime('-2 days'));
    $toDate = date('Y-m-d');

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://payments-tesseract.bharatpe.in/api/v1/merchant/transactions?module=PAYMENT_QR&merchantId=' . $merchantId . '&sDate=' . $fromDate . '&eDate=' . $toDate,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 120,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'token: ' . $token,
            'user-agent: Mozilla/5.0',
            'Cookie: ' . $cookie
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    return json_decode($response, true);
}

if (isset($_POST['verifyotp'])) {
    $bbbyteuserid = $_SESSION['user_id'];
    $bbytebharatpeuserid = $userdata['user_token'];
    $bbytebharatpeusermid = $_POST["MID"];
    $bbytebharatpeusertoken = $_POST["token"];
    $bbytebharatpeusercookie = $_POST["cookie"];
    $bharatpeupiid = $_POST["upiid"];

    $response = bharatpe_trans($bbytebharatpeusermid, $bbytebharatpeusertoken, $bbytebharatpeusercookie);
    $bbytebharatpestatus = false;

    if (is_array($response) && isset($response['message']) && $response['message'] === 'SUCCESS' && isset($response['status']) && $response['status'] === true) {
        $bbytebharatpestatus = true;
    }

    if ($bbytebharatpestatus == true) {
        $sqlw = "UPDATE bharatpe_tokens SET merchantId='$bbytebharatpeusermid', token='$bbytebharatpeusertoken', status='Active', Upiid = '$bharatpeupiid', user_id=$bbbyteuserid, cookie='$bbytebharatpeusercookie' WHERE user_token='$bbytebharatpeuserid'";
        $result = mysqli_query($conn, $sqlw);
        $sqlUpdateUser = "UPDATE users SET bharatpe_connected='Yes' WHERE user_token='$bbytebharatpeuserid'";
        $resultUpdateUser = mysqli_query($conn, $sqlUpdateUser);

        if ($result) {
            echo "Congratulations! Your BharatPe has been connected successfully!";
            header("Refresh: 3; URL=connect_merchant");
            exit;
        } else {
            echo "Error while updating records. Please try again later.";
            header("Refresh: 3; URL=connect_merchant");
            exit;
        }
    } else {
        echo "Invalid BharatPe details. Please check and try again.";
        header("Refresh: 3; URL=connect_merchant");
        exit;
    }
}

if (isset($_POST['Verify'])) {
    $bharatpe_mobile = $_POST["bharatpe_mobile"];

    if ($userdata['bharatpe_connected'] == "Yes") {
        echo "Merchant already connected!";
        header("Refresh: 3; URL=connect_merchant");
        exit;
    }

    ?><div class="container d-flex justify-content-center align-items-center vh-100">
    <form id="paytmForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="w-100" style="max-width: 500px;">
          <div class="card p-4">
         <h5 class="text-center mb-4">VERIFY BHARAT MERCHANT</h5>
            <div class="mb-3">
                <label for="MID" class="form-label">Enter Merchant ID</label>
                <input type="text" name="MID" id="MID" placeholder="Enter Merchant ID" class="form-control" required>
            </div>
             <div class="mb-3">
                <label for="cookie" class="form-label">Enter BharatPe Cookie</label>
                <textarea name="cookie" id="cookie" placeholder="Enter BharatPe Cookie" class="form-control" required></textarea>
            </div>
             <div class="mb-3">
                <label for="token" class="form-label">Enter BharatPe Token</label>
                <input type="text" name="token" id="token" placeholder="Enter BharatPe Token" class="form-control" required>
            </div>
             <div class="mb-3">
                <label for="upiid" class="form-label">BharatPe UPI Id</label>
                <input type="text" name="upiid" id="upiid" placeholder="Enter BharatPe UPI Id" class="form-control" required>
            </div>
            <div class="mb-3">
                <button type="submit" name="verifyotp" class="btn btn-success">Verify BharatPe</button>
            </div>
        </div>
    </form></div>
    <?php
} else {
    echo "Congratulations! Your BharatPe has been connected successfully!";
    header("Refresh: 3; URL=connect_merchant");
    exit;
}
?>
</body>
</html>