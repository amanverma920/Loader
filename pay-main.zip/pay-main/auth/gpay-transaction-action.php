<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set to 1 in development if needed
header('Content-Type: application/json');

include 'config.php'; // This should define $conn (mysqli connection)

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!$input || !isset($input['id']) || !isset($input['action'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$id = intval($input['id']);
$action = $input['action'];

if (!in_array($action, ['approve', 'reject'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}

$status = $action === 'approve' ? 'SUCCESS' : 'REJECTED';

// 1. Update the order status
$update_sql = "UPDATE orders SET status = ? WHERE id = ?";
$update_stmt = $conn->prepare($update_sql);
if (!$update_stmt) {
    echo json_encode(['success' => false, 'message' => 'DB Error: ' . $conn->error]);
    exit;
}

$update_stmt->bind_param('si', $status, $id);

if ($update_stmt->execute()) {

    // 2. Fetch order details for report insertion
    $order_sql = "SELECT id, order_id, user_token, status, amount, utr, plan_id, customer_name, customer_mobile, redirect_url, remark1, remark2, gateway_txn, method, HDFC_TXNID, upiLink, description, byteTransactionId, create_date, paytm_txn_ref, user_id FROM orders WHERE id = ?";
    $order_stmt = $conn->prepare($order_sql);
    $order_id = null;
    if ($order_stmt) {
        $order_stmt->bind_param('i', $id);
        $order_stmt->execute();
        $result = $order_stmt->get_result();
        $order = $result->fetch_assoc();
        $order_id = $order['order_id'];
        $order_stmt->close();

        if ($order) {
            // 3. Insert into reports
            $report_sql = "
                INSERT INTO reports (
                    transactionId, status, order_id, vpa, paymentApp, amount, user_token, UTR,
                    description, date, mobile, user_name, merchantTransactionId, transactionNote, user_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?)
            ";

            $report_stmt = $conn->prepare($report_sql);
            if ($report_stmt) {
                $vpa = 'VPA'; // Replace with actual value if available
                $paymentApp = 'UPI APP'; // Replace with actual app if available
                $report_stmt->bind_param(
                    'ssssdsssssisss',
                    $order['byteTransactionId'],
                    $status,
                    $order['order_id'],
                    $vpa,
                    $paymentApp,
                    $order['amount'],
                    $order['user_token'],
                    $order['utr'],
                    $order['description'],
                    $order['customer_mobile'],
                    $order['customer_name'],
                    $order['gateway_txn'],
                    $order['description'],
                    $order['user_id']
                );

                $report_stmt->execute();
                $report_stmt->close();
            }
        }
    }
    
   
    /*************************************************************************************/
 
$webhook_data = [
    'order_id'=> $order_id,
    'status'=> "SUCCESS",
    'remark1'=>$cxrremark1,
 ];


if (!empty($callback_url)) {
    $json_data = json_encode($webhook_data);

    $ch = curl_init($callback_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($json_data)
    ]);

    $webhook_response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log("Webhook curl error: " . curl_error($ch));
    }

    curl_close($ch);
}

    /*************************************************************************************/
    /*************************************************************************************/
    echo json_encode(['success' => true, 'message' => 'Transaction status updated']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update transaction status']);
}

$update_stmt->close();
$conn->close();
?>
