<?php

include 'function.php'; // Custom functions if any



session_start(); // Start the PHP session
include "config.php"; // Include your database connection
include 'function.php'; // Custom functions if any


if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE mobile = '$username'";
    $run = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($run);

    if (mysqli_num_rows($run) > 0) {
        $hashFromDatabase = $row['password'];
        
        $byteuserid = $row['id'];
        $email = $row['email'];


        if (password_verify($password, $hashFromDatabase)) {
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $byteuserid;

      
          
                header("Location:dashboard");exit();
              

        } else {
           

            echo '<script>alert("Inavlid Credentials!");</script>';
        }
    } else {
        echo '<script>alert("Inavlid Credentials!");</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <!-- Bootstrap CSS -->
  <?php include "common_files/head.php";?>
  <style>
    /* Full height and image background */
    html, body {
      height: 100%;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      background: url('https://wallpapers.com/images/hd/microsoft-background-a4a8kqppml9z8cz8.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    /* Black overlay */
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.2); /* Black overlay with opacity */
    }


   
  </style>
</head>
<body>

  <!-- Black overlay -->
  <div class="overlay"></div>

  <form style="max-width: 95%;width: 400px"  method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="card p-4">
                    <h5 class="">Login</h5>
                    <p>Login Quickly!</p>
                    
                    <div class="mb-3">
                        <label for="MID" class="form-label">Mobile Number</label>
                        <input type="text" name="username" id="MID" placeholder="Mobile Number" class="form-control " required value="9876543210">
                    </div>

                    

                    <div class="mb-3">
                        <label for="UPI" class="form-label">Password</label>
                        <input type="text" name="password" id="UPI" placeholder="Password" class="form-control" required value="9876543210">
                    </div>

                    <div class="d-grid mt-1">
                        <button type="submit" name="submit" class="btn btn-success">Login Now</button>
                    </div>
                    <p class="text-muted text-center mt-4 bold">Don't have an account? <a href="../Register">Signup Here</a></p>
                </div>

            </form>

  <!-- Bootstrap JS (Optional) -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
