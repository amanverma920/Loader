
<!DOCTYPE html>
<html >
   <head>
      <?php include 'common_files/head.php';?>
      <style>
      </style>
      <title>Home</title>
   </head>
   <body>
    <?php
   include "header.php";
   if(!isset($_SESSION["user_id"])){
    header('Location:../');
}
   if(isset($_POST['get_api_token'])){
   
       $bbbyteuserid=$_SESSION['user_id'];
   
       $sanitizedMobile = mysqli_real_escape_string($conn, $mobile);
   
       $uniqueNumber = mt_rand(1000000000, 9999999999);
       $uniqueNumber = str_pad($uniqueNumber, 10, '0', STR_PAD_LEFT); 
   
       $key = md5($uniqueNumber);
       $keyquery = "UPDATE `users` SET user_token='$key' WHERE mobile = '$sanitizedMobile'";
       $queryres = mysqli_query($conn, $keyquery);
   
       $keyqueryorders = "UPDATE `orders` SET user_token='$key' WHERE user_id = $bbbyteuserid";
       $queryorders = mysqli_query($conn, $keyqueryorders);
   
       $keyqueryordersreports = "UPDATE `reports` SET user_token='$key' WHERE user_id = $bbbyteuserid";
       $queryordersreports = mysqli_query($conn, $keyqueryordersreports);
   
       $keyqueryhdfc = "UPDATE `hdfc` SET user_token='$key' WHERE user_id = $bbbyteuserid";
       $queryreshdfc = mysqli_query($conn, $keyqueryhdfc);
   
       $keyquerybharatpe = "UPDATE `bharatpe_tokens` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryresbharatpe = mysqli_query($conn, $keyquerybharatpe);
   
       $keyqueryphonepetoken = "UPDATE `phonepe_tokens` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryresphonepetoken = mysqli_query($conn, $keyqueryphonepetoken);
   
       $keyqueryphonepetoken2 = "UPDATE `store_id` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryresphonepetoken2 = mysqli_query($conn, $keyqueryphonepetoken2);
   
       $keyquerypaytm2 = "UPDATE `paytm_tokens` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryrespaytm = mysqli_query($conn, $keyquerypaytm2);
   
       $keyquerygooglepay = "UPDATE `googlepay_transactions` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryresgooglepay = mysqli_query($conn, $keyquerygooglepay);
   
        $keyquerygooglepay1 = "UPDATE `googlepay_tokens` SET user_token='$key' WHERE user_id = '$bbbyteuserid'";
       $queryresgooglepay1 = mysqli_query($conn, $keyquerygooglepay1);
   
       if($queryres && $queryreshdfc){
   
   echo '<script>
       Swal.fire({
           icon: "success",
           title: "New API Key generated!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
              // window.location.href = "apidetails"; 
           }
       });
   </script>';
   
       
   
       } else {
   
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "API Key Generating Failed!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
             //  window.location.href = "apidetails"; 
           }
       });
   </script>';

       }
   }
   ?>
<?php
   function isValidUrl($url) {
       $parsed_url = parse_url($url);
       return isset($parsed_url['host']) && preg_match("/\.\w+$/", $parsed_url['host']);
   }
   
   if(isset($_POST['update_webhook'])){
   
       $bytecallbackurl=mysqli_real_escape_string($conn,$_POST['webhook_url']);
   
       if (!isValidUrl($bytecallbackurl)) {
   
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "Invalid webhook url!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
             //  window.location.href = "apidetails"; 
           }
       });
   </script>';
   
           
       }
   
       $sanitizedMobile = mysqli_real_escape_string($conn, $mobile);
   
       $key = md5($uniqueNumber);
       $keyquery = "UPDATE `users` SET  callback_url='$bytecallbackurl' WHERE mobile = '$sanitizedMobile'";
       $queryres = mysqli_query($conn, $keyquery);
       if($queryres){
   
   echo '<script>
       Swal.fire({
           icon: "success",
           title: "Webhook Updated Successfully",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
               //window.location.href = "apidetails"; 
           }
       });
   </script>';
   
       
   
       } else {
   
   echo '<script>
       Swal.fire({
           icon: "error",
           title: "Error Updating Webhook Try again Later!!",
           showConfirmButton: true, 
           confirmButtonText: "Ok!", 
           allowOutsideClick: false, 
           allowEscapeKey: false 
       }).then((result) => {
           if (result.isConfirmed) {
               //window.location.href = "apidetails"; 
           }
       });
   </script>';
  
       }
   }
   ?>
      <div class="container-fluid row p-0 m-0">
         <?php include "common_files/sidebar.php";?>
         <div class="col p-0">
            <?php include "common_files/header.php";?>
            <!--------------------------------->
            <div class="p-4">
               <h4>PAYMENT LINKS</h4>
               <div class="bg-white mt-3 p-4">
                  <div class="mt-0">
                     <div class="col-md-12">
                        <form class="row mb-4" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                          <!-- <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">-->
                           <div class="col-md-8 mb-2">
                              <label class="form-label">Api Token</label>
                              <input type="text" placeholder="Click Generate Button for API Token" value="<?php echo htmlspecialchars($userdata['user_token'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" readonly>
                           </div>
                           <div class="col-md-4 mb-2 d-flex justify-content-end flex-column">
                              
                              <button type="submit" name="get_api_token" class="btn btn-primary btn-block">Generate Api Token</button>
                           </div>
                        </form>
                     </div>
                     <div class="col-md-12">
                        <form class="row mb-4" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                          <!--  <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">-->
                           <div class="col-md-8 mb-2">
                              <label class="form-label">Webhook URL</label>
                              <input type="url" name="webhook_url" placeholder="Enter Your Webhook URL" value="<?php echo htmlspecialchars($userdata['callback_url'], ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required pattern="https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/?[a-zA-Z0-9.-]*\??[a-zA-Z0-9.-]*" title="Enter a valid URL">
                              
                           </div>
                           <div class="col d-flex justify-content-end flex-column">
                           
                              <button type="submit" name="update_webhook" class="btn btn-primary btn-block">Update URL</button>
                           </div>
                          
                        </form>

                     </div>
                     <b style="color:red">Note: URL must include protocol (http / https)</b>
                     <div class="col-md-12">
                        <h6 class="mb-3"><b>Create Order API</b></h6>
                        <form class="row mb-4" method="POST" action="">
                           <div class="col-md-12 mb-2">
                              <label class="form-label">URL</label>
                              <input type="text" placeholder="URL" value="<?php echo htmlspecialchars($root, ENT_QUOTES, 'UTF-8'); ?>api/create-order" class="form-control" readonly>
                              <b style="color:red">Order Timeout 30 Minutes. Order Will Be Automatically Failed After 30 Minutes.</b>
                           </div>
                           <div class="col-md-12 mb-2">
                              <label class="form-label">Form-Encoded Payload (application/x-www-form-urlencoded)</label>
                              <textarea type="text" placeholder="Form-Encoded Payload (Parameter)" class="form-control" style="height: 190px;" readonly>
                                {
                              "customer_mobile": "8877332212",
                              "user_token": "<?php echo htmlspecialchars($userdata['user_token'], ENT_QUOTES, 'UTF-8'); ?>",
                              "amount": "1",
                              "order_id": "8787772321800",
                              "redirect_url": https:
                              "remark1" : "testremark",
                              "remark2 : "testremark2,
                              }</textarea>
                           </div>
                           <div class="col-md-6 mb-2">
                              <label class="form-label">Success Response</label>
                              <textarea type="text" placeholder="Success Response" class="form-control" style="height: 230px;" readonly>
                              {
                              "status": true,
                              "message": "Order Created Successfully",
                              "result": {
                              "orderId": "1234561705047510",
                              "payment_url": "https://onkarjha.com/payment/pay.php?data=MTIzNDU2MTcwNTA0NzUxMkyNTIy"
                              }
                              }
                              </textarea>
                           </div>
                           <div class="col-md-6 mb-2">
                              <label class="form-label">Failed Response</label>
                              <textarea type="text" placeholder="Failed Response" class="form-control" style="height: 140px;" readonly>{
                              "status": "false",
                              "message": "Order_id Already Exist"
                              }</textarea> 
                           </div>
                        </form>
                     </div>
                     <div class="col-md-12 mb-4">
                        <hr>
                     </div>
                     <div class="col-md-12">
                        <h6 class="mb-3"><b>Check Order Status API</b></h6>
                        <form class="row mb-4" method="POST" action="">
                           <div class="col-md-12 mb-2">
                              <label class="form-label">URL</label>
                              <input type="text" placeholder="URL" value="https://<?php echo htmlspecialchars($server, ENT_QUOTES, 'UTF-8'); ?>/api/check-order-status" class="form-control" readonly>
                           </div>
                           <div class="col-md-12 mb-2">
                              <label class="form-label">Form-Encoded Payload (application/x-www-form-urlencoded)</label>
                              <textarea type="text" placeholder="Post Data into Form Header into Form Header (Parameter)" class="form-control" style="height: 120px;" readonly>{
                              "user_token": "2048f66bef68633fa3262d7a398ab577",
                              "order_id": "8052313697"
                              }</textarea> 
                           </div>
                           <div class="col-md-6 mb-2">
                              <label class="form-label">Success Response</label>
                              <textarea type="text" placeholder="Success Response" class="form-control" style="height: 190px;" readonly>
                              {
                              "status": "COMPLETED",
                              "message": "Transaction Successfully",
                              "result": {
                              "txnStatus": "COMPLETED",
                              "resultInfo": "Transaction Success",
                              "orderId": "784525sdD",
                              "status": "SUCCESS",
                              "amount": "1",
                              "date": "2024-01-12 13:22:08",
                              "utr": "454525454245"
                              }
                              }
                              </textarea>
                           </div>
                           <div class="col-md-6 mb-2">
                              <label class="form-label">Failed Response</label>
                              <textarea type="text" placeholder="Failed Response" class="form-control" style="height: 140px;" readonly>{
                              "status": ERROR,
                              "message": "Error Massege",
                              }</textarea> 
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            <!---------------------------->
         </div>
      </div>
    <?php include "common_files/footer.php";?>
   </body>
</html>