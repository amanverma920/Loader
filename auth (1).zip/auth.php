<?php 

$dbhost = 'localhost';
$dbuser = 'unikeyge_lucky';
$dbpass = 'unikeyge_lucky';
$db = 'unikeyge_lucky';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass , $db) or die($conn); 

date_default_timezone_set('Asia/Jakarta');

if (mysqli_connect_error()){
	echo "Koneksi database gagal :". mysqli_connect_error();
}

?>

