<?php
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');

function connect_database() {
	$fetchType = "array";
	$dbHost = "localhost";
	$dbLogin = "aalyan_uchiha";
	$dbPwd = "aalyan_uchiha";
	$dbName = "aalyan_uchiha";
	$con = mysqli_connect($dbHost, $dbLogin, $dbPwd, $dbName);
	if (!$con) {
		die("Database Connection failed: " . mysqli_connect_errno());
	}
	return ($con);
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'aalyan_uchiha');
define('DB_PASSWORD', 'aalyan_uchiha');
define('DB_NAME', 'aalyan_uchiha');
?>