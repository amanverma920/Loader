<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection - using the same credentials as config.php
$conn = new mysqli('localhost', 'aalyan_uchiha', 'aalyan_uchiha', 'aalyan_uchiha');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'] ?? null;
$user_token = '';
$user_mobile = '';

if ($user_id) {
    // Fetch user data from users table
    $result = mysqli_query($conn, "SELECT user_token, mobile FROM users WHERE id = '$user_id' LIMIT 1");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $user_token = $row['user_token'];
        $user_mobile = $row['mobile'];
    }
}

// CSRF token setup
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// API Key Regeneration
if (isset($_POST['get_api_token'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "CSRF token verification failed!";
        exit();
    }

    $bbbyteuserid = $_SESSION['user_id'];
    $sanitizedMobile = mysqli_real_escape_string($conn, $user_mobile);

    $uniqueNumber = mt_rand(1000000000, 9999999999);
    $uniqueNumber = str_pad($uniqueNumber, 10, '0', STR_PAD_LEFT);
    $key = md5($uniqueNumber);
    
    // Update user_token in all relevant tables based on the SQL structure
    $tables = [
        "users" => "mobile = '$sanitizedMobile'",
        "orders" => "user_id = $bbbyteuserid",
        "reports" => "user_id = $bbbyteuserid",
        "hdfc" => "user_id = $bbbyteuserid",
        "bharatpe_tokens" => "user_id = '$bbbyteuserid'",
        "phonepe_tokens" => "user_id = '$bbbyteuserid'",
        "store_id" => "user_id = '$bbbyteuserid'",
        "paytm_tokens" => "user_id = '$bbbyteuserid'",
        "googlepay_transactions" => "user_id = '$bbbyteuserid'",
        "googlepay_tokens" => "user_id = '$bbbyteuserid'",
    ];
    
    $success = true;
    foreach ($tables as $table => $where) {
        $q = "UPDATE `$table` SET user_token='$key' WHERE $where";
        if (!mysqli_query($conn, $q)) {
            $success = false;
        }
    }

    if ($success) {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
        echo '<script>
            Swal.fire({
                icon: "success",
                title: "New API Key generated!!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "upisettings";
                }
            });
        </script>';
        exit;
    } else {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
        echo '<script>
            Swal.fire({
                icon: "error",
                title: "API Key Generating Failed!!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "upisettings";
                }
            });
        </script>';
        exit;
    }
}

// Webhook URL update
function isValidUrl($url) {
    $parsed_url = parse_url($url);
    return isset($parsed_url['host']) && preg_match("/\.\w+$/", $parsed_url['host']);
}

if (isset($_POST['update_webhook'])) {
    $bytecallbackurl = mysqli_real_escape_string($conn, $_POST['webhook_url']);
    if (!isValidUrl($bytecallbackurl)) {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
        echo '<script>
            Swal.fire({
                icon: "error",
                title: "Invalid webhook url!!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "upisettings";
                }
            });
        </script>';
        exit();
    }
    
    $sanitizedMobile = mysqli_real_escape_string($conn, $user_mobile);
    $keyquery = "UPDATE `users` SET callback_url='$bytecallbackurl' WHERE mobile = '$sanitizedMobile'";
    $queryres = mysqli_query($conn, $keyquery);
    
    if ($queryres) {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
        echo '<script>
            Swal.fire({
                icon: "success",
                title: "Webhook Updated Successfully",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "upisettings";
                }
            });
        </script>';
        exit;
    } else {
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';
        echo '<script>
            Swal.fire({
                icon: "error",
                title: "Error Updating Webhook Try again Later!!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "upisettings";
                }
            });
        </script>';
        exit;
    }
}

echo '<div style="background:#fffbe6;border:1px solid #ffe58f;padding:10px;margin:10px 0;">DEBUG SESSION: <pre>' . print_r($_SESSION,1) . '</pre>USER_ID: ' . ($user_id ?? 'NOT SET') . '<br>USER_TOKEN: ' . htmlspecialchars($user_token) . '<br>USER_MOBILE: ' . htmlspecialchars($user_mobile) . '</div>';
?>

<!doctype html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UPI Settings - User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">API Token Management</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            
                            <div class="mb-3">
                                <label for="user_token" class="form-label">User Token (API Key)</label>
                                <input type="text" class="form-control" id="user_token" value="<?php echo htmlspecialchars($user_token); ?>" readonly>
                                <div class="form-text">This is your unique API key for authentication</div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" name="get_api_token" class="btn btn-primary">
                                    Generate New API Token
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
</body>
</html>
