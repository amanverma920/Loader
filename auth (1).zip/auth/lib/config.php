<?php

//for plans

$token = '3b5a65c28184fb285ab2751307c8908c'; 


?>