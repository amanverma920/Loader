<?php

// Dene the absolute path to the functions.php file
define('ABSPATH', dirname(__FILE__) . '/'); // Adjust the path as needed
// Include the database connection file
require_once(ABSPATH . 'header.php');


?>


<?php


// Function to sanitize user input
function sanitizeInput($input) {
    if (is_string($input)) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    } else {
        // Handle non-string input here (e.g., arrays, objects, etc.) if needed.
        return $input;
    }
}

if(isset($_POST['verifyotp'])) {
  

    $bbbyteuserid = $_SESSION['user_id'];
    $bbytepaytmuserid = $userdata['user_token'];
    $bbytepaytmusermid = ($_POST["MID"]);
    $bbytepaytmuserupiid = ($_POST["UPI"]);

    $sqlUpdateUser = "UPDATE users SET paytm_connected='Yes' WHERE user_token='$bbytepaytmuserid'";
    $resultUpdateUser = mysqli_query($conn, $sqlUpdateUser);

    $sqlw = "UPDATE paytm_tokens SET MID='$bbytepaytmusermid', Upiid='$bbytepaytmuserupiid', status='Active', user_id=$bbbyteuserid WHERE user_token='$bbytepaytmuserid'";
    $result = mysqli_query($conn, $sqlw);

    if ($result) {
        // Show SweetAlert2 success message
       
       echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
            Swal.fire({
                icon: "success",
                title: "Congratulations! Your Paytm Has been Connected Successfully!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "connect_merchant";
                }
            });
        </script>';
        exit();
    } else {
        // Show SweetAlert2 error message
       
       echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
            Swal.fire({
                icon: "error",
                title: "Please Try Again Later!!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "connect_merchant";
                }
            });
        </script>';
        exit();
    }
}

if(isset($_POST['Verify'])) { ///to open this page from last
  

    if ($userdata['paytm_connected'] == "Yes") {
        // Show SweetAlert2 error message
       
       echo '<script src="js/jquery-3.2.1.min.js"></script>';echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>';echo '<script>$("#loading_ajax").hide();
            Swal.fire({
                icon: "error",
                title: "Merchant Already Connected !!",
                showConfirmButton: true,
                confirmButtonText: "Ok!",
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "connect_merchant";
                }
            });
        </script>';
        exit();
    }

    $paytm_mobile = ($_POST["paytm_mobile"]);
    ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18"></script>
    <script>
    Swal.fire({
        title: 'Paytm UPI Settings',
        html: `
            <form id="paytmForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="mb-2">
                <div class="mb-3">
                    <label for="MID" class="form-label">Merchant ID</label>
                    <input type="text" name="MID" id="MID" class="form-control form-control-lg" placeholder="Enter Merchant ID" required>
                </div>
                <div class="mb-3">
                    <label for="Number" class="form-label">Mobile Number</label>
                    <input type="number" name="Number" id="Number" class="form-control form-control-lg" placeholder="Enter Number" value="<?php echo $paytm_mobile; ?>" minlength="10" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');" required>
                </div>
                <div class="mb-3">
                    <label for="UPI" class="form-label">UPI ID</label>
                    <input type="text" name="UPI" id="UPI" class="form-control form-control-lg" placeholder="Enter UPI" value="dummy@Paytm" required>
                </div>
                <button type="submit" name="verifyotp" class="btn btn-primary btn-lg w-100 mt-2">Verify Paytm</button>
            </form>
        `,
        showCancelButton: false,
        showConfirmButton: false,
        customClass: {
            popup: 'swal2-modern-popup',
            title: 'swal2-modern-title',
            htmlContainer: 'swal2-modern-content'
        },
        allowOutsideClick: false,
        allowEscapeKey: false
    });
    </script>
    <style>
    .swal2-modern-popup {
        max-width: 420px !important;
        padding: 2.5em 2em 2em 2em !important;
        border-radius: 18px !important;
        box-shadow: 0 8px 32px rgba(0,0,0,0.12) !important;
        background: #fff !important;
    }
    .swal2-modern-title {
        font-size: 2rem !important;
        font-weight: 700 !important;
        color: #212529 !important;
        margin-bottom: 1.2em !important;
    }
    .swal2-modern-content {
        text-align: left !important;
        padding: 0 !important;
    }
    .swal2-modern-content label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 0.3em;
    }
    .swal2-modern-content input.form-control {
        border-radius: 8px;
        font-size: 1.1rem;
        padding: 0.75em 1em;
        margin-bottom: 0.5em;
        border: 1px solid #ced4da;
        background: #f8f9fa;
    }
    .swal2-modern-content .btn-primary {
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 600;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        transition: background 0.2s;
    }
    .swal2-modern-content .btn-primary:hover {
        background: #0056b3;
    }
    </style>
    <?php
} //iset from last page if(isset($_POST['Verify'])) {

else{
    
echo '<script>
    Swal.fire({
        icon: "error",
        title: "Form Not Submitted!!",
        showConfirmButton: true, // Show the confirm button
        confirmButtonText: "Ok!", // Set text for the confirm button
        allowOutsideClick: false, // Prevent the user from closing the popup by clicking outside
        allowEscapeKey: false // Prevent the user from closing the popup by pressing Escape key
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "connect_merchant"; // Redirect to "connect_merchant" when the user clicks the confirm button
        }
    });
</script>';
exit;
}
?>

<!--bootstrap js-->
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!--plugins-->
  <script src="assets/js/jquery.min.js"></script>
  <!--plugins-->
  <script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
  <script src="assets/plugins/metismenu/metisMenu.min.js"></script>
  <script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
  <script src="assets/js/main.js"></script>


</body>

</html>