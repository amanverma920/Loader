<?php
// common.php
$pageTitle = "DESHI_SERVER MOD VIP KEY";
$contactAdminUrl = "https://telegram.me/brosorry012";
$joinTelegramChannelUrl = "https://telegram.me/deshi_server";
?>